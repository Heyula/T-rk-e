<?php

declare(strict_types=1);


namespace XoopsModules\Servisler;

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * Servisler module for xoops
 *
 * @copyright      2021 XOOPS Project (https://xoops.org)
 * @license        GPL 2.0 or later
 * @package        servisler
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         B.Heyula - Email:<eren@aymak.net> - Website:<http://erenyumak.com>
 */

use XoopsModules\Servisler;

\defined('XOOPS_ROOT_PATH') || die('Restricted access');

/**
 * Class Object Articles
 */
class Articles extends \XoopsObject
{
    /**
     * @var int
     */
    public $start = 0;

    /**
     * @var int
     */
    public $limit = 0;

    /**
     * Constructor
     *
     * @param null
     */
    public function __construct()
    {
        $this->initVar('art_id', \XOBJ_DTYPE_INT);
        $this->initVar('art_cat', \XOBJ_DTYPE_INT);
        $this->initVar('art_title', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_field1', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_field2', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_field3', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_field4', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_field5', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_field6', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('artc_descr', \XOBJ_DTYPE_OTHER);
        $this->initVar('art_images', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_images2', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_file', \XOBJ_DTYPE_TXTBOX);
        $this->initVar('art_submitter', \XOBJ_DTYPE_INT);
        $this->initVar('art_online', \XOBJ_DTYPE_INT);
        $this->initVar('art_created', \XOBJ_DTYPE_INT);
        $this->initVar('artc_read', \XOBJ_DTYPE_INT);
        $this->initVar('artc_ratings', \XOBJ_DTYPE_DECIMAL);
        $this->initVar('artc_votes', \XOBJ_DTYPE_INT);
    }

    /**
     * @static function &getInstance
     *
     * @param null
     */
    public static function getInstance()
    {
        static $instance = false;
        if (!$instance) {
            $instance = new self();
        }
    }

    /**
     * The new inserted $Id
     * @return inserted id
     */
    public function getNewInsertedIdArticles()
    {
        $newInsertedId = $GLOBALS['xoopsDB']->getInsertId();
        return $newInsertedId;
    }

    /**
     * @public function getForm
     * @param bool $action
     * @return \XoopsThemeForm
     */
    public function getFormArticles($action = false)
    {
        $helper = \XoopsModules\Servisler\Helper::getInstance();
        if (!$action) {
            $action = $_SERVER['REQUEST_URI'];
        }
        $isAdmin = $GLOBALS['xoopsUser']->isAdmin($GLOBALS['xoopsModule']->mid());
        // Permissions for uploader
        $grouppermHandler = \xoops_getHandler('groupperm');
        $groups = \is_object($GLOBALS['xoopsUser']) ? $GLOBALS['xoopsUser']->getGroups() : \XOOPS_GROUP_ANONYMOUS;
        $permissionUpload = $grouppermHandler->checkRight('upload_groups', 32, $groups, $GLOBALS['xoopsModule']->getVar('mid')) ? true : false;
        // Title
        $title = $this->isNew() ? \sprintf(\_AM_SERVISLER_ARTICLE_ADD) : \sprintf(\_AM_SERVISLER_ARTICLE_EDIT);
        // Get Theme Form
        \xoops_load('XoopsFormLoader');
        $form = new \XoopsThemeForm($title, 'form', $action, 'post', true);
        $form->setExtra('enctype="multipart/form-data"');
        // Use tag module
        $dirTag = \is_dir(\XOOPS_ROOT_PATH . '/modules/tag') ? true : false;
        if (($helper->getConfig('usetag') == 1) && $dirTag) {
            $tagId = $this->isNew() ? 0 : $this->getVar('art_id');
            require_once \XOOPS_ROOT_PATH . '/modules/tag/include/formtag.php';
            $form->addElement(new \XoopsFormTag('tag', 60, 255, $tagId, 0), true);
        }
        // Form Table categories
        $categoriesHandler = $helper->getHandler('Categories');
        $artCatSelect = new \XoopsFormSelect(\_AM_SERVISLER_ARTICLE_CAT, 'art_cat', $this->getVar('art_cat'));
        $artCatSelect->addOptionArray($categoriesHandler->getList());
        $form->addElement($artCatSelect, true);
        // Form Text artTitle
        $form->addElement(new \XoopsFormText(\_AM_SERVISLER_ARTICLE_TITLE, 'art_title', 50, 255, $this->getVar('art_title')), true);
        // Form Text artField1
        $form->addElement(new \XoopsFormText(\_AM_SERVISLER_ARTICLE_FIELD1, 'art_field1', 50, 255, $this->getVar('art_field1')));
        // Form Text artField2
        $form->addElement(new \XoopsFormText(\_AM_SERVISLER_ARTICLE_FIELD2, 'art_field2', 50, 255, $this->getVar('art_field2')));
        // Form Text artField3
        $form->addElement(new \XoopsFormText(\_AM_SERVISLER_ARTICLE_FIELD3, 'art_field3', 50, 255, $this->getVar('art_field3')));
        // Form Text artField4
        $form->addElement(new \XoopsFormText(\_AM_SERVISLER_ARTICLE_FIELD4, 'art_field4', 50, 255, $this->getVar('art_field4')));
        // Form Text artField5
        $form->addElement(new \XoopsFormText(\_AM_SERVISLER_ARTICLE_FIELD5, 'art_field5', 50, 255, $this->getVar('art_field5')));
        // Form Text artField6
        $form->addElement(new \XoopsFormText(\_AM_SERVISLER_ARTICLE_FIELD6, 'art_field6', 50, 255, $this->getVar('art_field6')));
        // Form Editor DhtmlTextArea artcDescr
        $editorConfigs = [];
        if ($isAdmin) {
            $editor = $helper->getConfig('editor_admin');
        } else {
            $editor = $helper->getConfig('editor_user');
        }
        $editorConfigs['name'] = 'artc_descr';
        $editorConfigs['value'] = $this->getVar('artc_descr', 'e');
        $editorConfigs['rows'] = 5;
        $editorConfigs['cols'] = 40;
        $editorConfigs['width'] = '100%';
        $editorConfigs['height'] = '400px';
        $editorConfigs['editor'] = $editor;
        $form->addElement(new \XoopsFormEditor(\_AM_SERVISLER_ARTICLE_DESCR, 'artc_descr', $editorConfigs), true);
        // Form Image artImages
        // Form Image artImages: Select Uploaded Image 
        $getArtImages = $this->getVar('art_images');
        $artImages = $getArtImages ?: 'blank.gif';
        $imageDirectory = '/uploads/servisler/images/articles';
        $imageTray = new \XoopsFormElementTray(\_AM_SERVISLER_ARTICLE_IMAGES, '<br>');
        $imageSelect = new \XoopsFormSelect(\sprintf(\_AM_SERVISLER_ARTICLE_IMAGES_UPLOADS, ".{$imageDirectory}/"), 'art_images', $artImages, 5);
        $imageArray = \XoopsLists::getImgListAsArray( \XOOPS_ROOT_PATH . $imageDirectory );
        foreach ($imageArray as $image1) {
            $imageSelect->addOption(($image1), $image1);
        }
        $imageSelect->setExtra("onchange='showImgSelected(\"imglabel_art_images\", \"art_images\", \"" . $imageDirectory . '", "", "' . \XOOPS_URL . "\")'");
        $imageTray->addElement($imageSelect, false);
        $imageTray->addElement(new \XoopsFormLabel('', "<br><img src='" . \XOOPS_URL . '/' . $imageDirectory . '/' . $artImages . "' id='imglabel_art_images' alt='' style='max-width:100px' >"));
        // Form Image artImages: Upload new image
        if ($permissionUpload) {
            $maxsize = $helper->getConfig('maxsize_image');
            $imageTray->addElement(new \XoopsFormFile('<br>' . \_AM_SERVISLER_FORM_UPLOAD_NEW, 'art_images', $maxsize));
            $imageTray->addElement(new \XoopsFormLabel(\_AM_SERVISLER_FORM_UPLOAD_SIZE, ($maxsize / 1048576) . ' '  . \_AM_SERVISLER_FORM_UPLOAD_SIZE_MB));
            $imageTray->addElement(new \XoopsFormLabel(\_AM_SERVISLER_FORM_UPLOAD_IMG_WIDTH, $helper->getConfig('maxwidth_image') . ' px'));
            $imageTray->addElement(new \XoopsFormLabel(\_AM_SERVISLER_FORM_UPLOAD_IMG_HEIGHT, $helper->getConfig('maxheight_image') . ' px'));
        } else {
            $imageTray->addElement(new \XoopsFormHidden('art_images', $artImages));
        }
        $form->addElement($imageTray);
        // Form Image artImages2
        // Form Image artImages2: Select Uploaded Image 
        $getArtImages2 = $this->getVar('art_images2');
        $artImages2 = $getArtImages2 ?: 'blank.gif';
        $imageDirectory = '/uploads/servisler/images/articles';
        $imageTray = new \XoopsFormElementTray(\_AM_SERVISLER_ARTICLE_IMAGES2, '<br>');
        $imageSelect = new \XoopsFormSelect(\sprintf(\_AM_SERVISLER_ARTICLE_IMAGES2_UPLOADS, ".{$imageDirectory}/"), 'art_images2', $artImages2, 5);
        $imageArray = \XoopsLists::getImgListAsArray( \XOOPS_ROOT_PATH . $imageDirectory );
        foreach ($imageArray as $image1) {
            $imageSelect->addOption(($image1), $image1);
        }
        $imageSelect->setExtra("onchange='showImgSelected(\"imglabel_art_images2\", \"art_images2\", \"" . $imageDirectory . '", "", "' . \XOOPS_URL . "\")'");
        $imageTray->addElement($imageSelect, false);
        $imageTray->addElement(new \XoopsFormLabel('', "<br><img src='" . \XOOPS_URL . '/' . $imageDirectory . '/' . $artImages2 . "' id='imglabel_art_images2' alt='' style='max-width:100px' >"));
        // Form Image artImages2: Upload new image
        if ($permissionUpload) {
            $maxsize = $helper->getConfig('maxsize_image');
            $imageTray->addElement(new \XoopsFormFile('<br>' . \_AM_SERVISLER_FORM_UPLOAD_NEW, 'art_images2', $maxsize));
            $imageTray->addElement(new \XoopsFormLabel(\_AM_SERVISLER_FORM_UPLOAD_SIZE, ($maxsize / 1048576) . ' '  . \_AM_SERVISLER_FORM_UPLOAD_SIZE_MB));
            $imageTray->addElement(new \XoopsFormLabel(\_AM_SERVISLER_FORM_UPLOAD_IMG_WIDTH, $helper->getConfig('maxwidth_image') . ' px'));
            $imageTray->addElement(new \XoopsFormLabel(\_AM_SERVISLER_FORM_UPLOAD_IMG_HEIGHT, $helper->getConfig('maxheight_image') . ' px'));
        } else {
            $imageTray->addElement(new \XoopsFormHidden('art_images2', $artImages2));
        }
        $form->addElement($imageTray);
        // Form File: Upload artFile
        $artFile = $this->isNew() ? '' : $this->getVar('art_file');
        if ($permissionUpload) {
            $fileUploadTray = new \XoopsFormElementTray(\_AM_SERVISLER_ARTICLE_FILE, '<br>');
            $fileDirectory = '/uploads/servisler/files/articles';
            if (!$this->isNew()) {
                $fileUploadTray->addElement(new \XoopsFormLabel(\sprintf(\_AM_SERVISLER_ARTICLE_FILE_UPLOADS, ".{$fileDirectory}/"), $artFile));
            }
            $maxsize = $helper->getConfig('maxsize_file');
            $fileUploadTray->addElement(new \XoopsFormFile('', 'art_file', $maxsize));
            $fileUploadTray->addElement(new \XoopsFormLabel(\_AM_SERVISLER_FORM_UPLOAD_SIZE, ($maxsize / 1048576) . ' '  . \_AM_SERVISLER_FORM_UPLOAD_SIZE_MB));
            $form->addElement($fileUploadTray);
        } else {
            $form->addElement(new \XoopsFormHidden('art_file', $artFile));
        }
        // Form Select Status artSubmitter
        $permissionsHandler = $helper->getHandler('Permissions');
        $artSubmitterSelect = new \XoopsFormSelect(\_AM_SERVISLER_ARTICLE_SUBMITTER, 'art_submitter', $this->getVar('art_submitter'));
        $artSubmitterSelect->addOption(Constants::STATUS_NONE, \_AM_SERVISLER_STATUS_NONE);
        $artSubmitterSelect->addOption(Constants::STATUS_OFFLINE, \_AM_SERVISLER_STATUS_OFFLINE);
        $artSubmitterSelect->addOption(Constants::STATUS_SUBMITTED, \_AM_SERVISLER_STATUS_SUBMITTED);
        if ($permissionsHandler->getPermGlobalApprove()) {
            $artSubmitterSelect->addOption(Constants::STATUS_APPROVED, \_AM_SERVISLER_STATUS_APPROVED);
        }
        $artSubmitterSelect->addOption(Constants::STATUS_BROKEN, \_AM_SERVISLER_STATUS_BROKEN);
        $form->addElement($artSubmitterSelect);
        // Form Select Status artOnline
        $permissionsHandler = $helper->getHandler('Permissions');
        $artOnlineSelect = new \XoopsFormSelect(\_AM_SERVISLER_ARTICLE_ONLINE, 'art_online', $this->getVar('art_online'));
        $artOnlineSelect->addOption(Constants::STATUS_NONE, \_AM_SERVISLER_STATUS_NONE);
        $artOnlineSelect->addOption(Constants::STATUS_OFFLINE, \_AM_SERVISLER_STATUS_OFFLINE);
        $artOnlineSelect->addOption(Constants::STATUS_SUBMITTED, \_AM_SERVISLER_STATUS_SUBMITTED);
        if ($permissionsHandler->getPermGlobalApprove()) {
            $artOnlineSelect->addOption(Constants::STATUS_APPROVED, \_AM_SERVISLER_STATUS_APPROVED);
        }
        $artOnlineSelect->addOption(Constants::STATUS_BROKEN, \_AM_SERVISLER_STATUS_BROKEN);
        $form->addElement($artOnlineSelect, true);
        // Form Text Date Select artCreated
        $artCreated = $this->isNew() ? \time() : $this->getVar('art_created');
        $form->addElement(new \XoopsFormTextDateSelect(\_AM_SERVISLER_ARTICLE_CREATED, 'art_created', '', $artCreated));
        // Permissions
        $memberHandler = \xoops_getHandler('member');
        $groupList = $memberHandler->getGroupList();
        $grouppermHandler = \xoops_getHandler('groupperm');
        $fullList[] = \array_keys($groupList);
        if ($this->isNew()) {
            $groupsCanApproveCheckbox = new \XoopsFormCheckBox(\_AM_SERVISLER_PERMISSIONS_APPROVE, 'groups_approve_articles[]', $fullList);
            $groupsCanSubmitCheckbox = new \XoopsFormCheckBox(\_AM_SERVISLER_PERMISSIONS_SUBMIT, 'groups_submit_articles[]', $fullList);
            $groupsCanViewCheckbox = new \XoopsFormCheckBox(\_AM_SERVISLER_PERMISSIONS_VIEW, 'groups_view_articles[]', $fullList);
        } else {
            $groupsIdsApprove = $grouppermHandler->getGroupIds('servisler_approve_articles', $this->getVar('art_id'), $GLOBALS['xoopsModule']->getVar('mid'));
            $groupsIdsApprove[] = \array_values($groupsIdsApprove);
            $groupsCanApproveCheckbox = new \XoopsFormCheckBox(\_AM_SERVISLER_PERMISSIONS_APPROVE, 'groups_approve_articles[]', $groupsIdsApprove);
            $groupsIdsSubmit = $grouppermHandler->getGroupIds('servisler_submit_articles', $this->getVar('art_id'), $GLOBALS['xoopsModule']->getVar('mid'));
            $groupsIdsSubmit[] = \array_values($groupsIdsSubmit);
            $groupsCanSubmitCheckbox = new \XoopsFormCheckBox(\_AM_SERVISLER_PERMISSIONS_SUBMIT, 'groups_submit_articles[]', $groupsIdsSubmit);
            $groupsIdsView = $grouppermHandler->getGroupIds('servisler_view_articles', $this->getVar('art_id'), $GLOBALS['xoopsModule']->getVar('mid'));
            $groupsIdsView[] = \array_values($groupsIdsView);
            $groupsCanViewCheckbox = new \XoopsFormCheckBox(\_AM_SERVISLER_PERMISSIONS_VIEW, 'groups_view_articles[]', $groupsIdsView);
        }
        // To Approve
        $groupsCanApproveCheckbox->addOptionArray($groupList);
        $form->addElement($groupsCanApproveCheckbox);
        // To Submit
        $groupsCanSubmitCheckbox->addOptionArray($groupList);
        $form->addElement($groupsCanSubmitCheckbox);
        // To View
        $groupsCanViewCheckbox->addOptionArray($groupList);
        $form->addElement($groupsCanViewCheckbox);
        // To Save
        $form->addElement(new \XoopsFormHidden('op', 'save'));
        $form->addElement(new \XoopsFormHidden('start', $this->start));
        $form->addElement(new \XoopsFormHidden('limit', $this->limit));
        $form->addElement(new \XoopsFormButtonTray('', \_SUBMIT, 'submit', '', false));
        return $form;
    }

    /**
     * Get Values
     * @param null $keys
     * @param null $format
     * @param null $maxDepth
     * @return array
     */
    public function getValuesArticles($keys = null, $format = null, $maxDepth = null)
    {
        $helper  = \XoopsModules\Servisler\Helper::getInstance();
        $utility = new \XoopsModules\Servisler\Utility();
        $ret = $this->getValues($keys, $format, $maxDepth);
        $ret['id']          = $this->getVar('art_id');
        $categoriesHandler = $helper->getHandler('Categories');
        $categoriesObj = $categoriesHandler->get($this->getVar('art_cat'));
        $ret['cat']         = $categoriesObj->getVar('cat_name');
        $ret['title']       = $this->getVar('art_title');
        $ret['field1']      = $this->getVar('art_field1');
        $ret['field2']      = $this->getVar('art_field2');
        $ret['field3']      = $this->getVar('art_field3');
        $ret['field4']      = $this->getVar('art_field4');
        $ret['field5']      = $this->getVar('art_field5');
        $ret['field6']      = $this->getVar('art_field6');
        $ret['descr']       = $this->getVar('artc_descr', 'e');
        $editorMaxchar = $helper->getConfig('editor_maxchar');
        $ret['descr_short'] = $utility::truncateHtml($ret['descr'], $editorMaxchar);
        $ret['images']      = $this->getVar('art_images');
        $ret['images2']     = $this->getVar('art_images2');
        $ret['file']        = $this->getVar('art_file');
        $status             = $this->getVar('art_submitter');
        $ret['status']      = $status;
        switch ($status) {
            case Constants::STATUS_NONE:
            default:
                $status_text = \_AM_SERVISLER_STATUS_NONE;
                break;
            case Constants::STATUS_OFFLINE:
                $status_text = \_AM_SERVISLER_STATUS_OFFLINE;
                break;
            case Constants::STATUS_SUBMITTED:
                $status_text = \_AM_SERVISLER_STATUS_SUBMITTED;
                break;
            case Constants::STATUS_APPROVED:
                $status_text = \_AM_SERVISLER_STATUS_APPROVED;
                break;
            case Constants::STATUS_BROKEN:
                $status_text = \_AM_SERVISLER_STATUS_BROKEN;
                break;
        }
        $ret['status_text'] = $status_text;
        $status             = $this->getVar('art_online');
        $ret['status']      = $status;
        switch ($status) {
            case Constants::STATUS_NONE:
            default:
                $status_text = \_AM_SERVISLER_STATUS_NONE;
                break;
            case Constants::STATUS_OFFLINE:
                $status_text = \_AM_SERVISLER_STATUS_OFFLINE;
                break;
            case Constants::STATUS_SUBMITTED:
                $status_text = \_AM_SERVISLER_STATUS_SUBMITTED;
                break;
            case Constants::STATUS_APPROVED:
                $status_text = \_AM_SERVISLER_STATUS_APPROVED;
                break;
            case Constants::STATUS_BROKEN:
                $status_text = \_AM_SERVISLER_STATUS_BROKEN;
                break;
        }
        $ret['status_text'] = $status_text;
        $ret['created']     = \formatTimestamp($this->getVar('art_created'), 's');
        $ret['read']        = $this->getVar('artc_read');
        $ret['ratings']     = $this->getVar('artc_ratings');
        $ret['votes']       = $this->getVar('artc_votes');
        return $ret;
    }

    /**
     * Returns an array representation of the object
     *
     * @return array
     */
    public function toArrayArticles()
    {
        $ret = [];
        $vars = $this->getVars();
        foreach (\array_keys($vars) as $var) {
            $ret[$var] = $this->getVar($var);
        }
        return $ret;
    }
}
