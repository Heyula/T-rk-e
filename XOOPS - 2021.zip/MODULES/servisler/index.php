<?php

declare(strict_types=1);

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * Servisler module for xoops
 *
 * @copyright      2021 XOOPS Project (https://xoops.org)
 * @license        GPL 2.0 or later
 * @package        servisler
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         B.Heyula - Email:<eren@aymak.net> - Website:<http://erenyumak.com>
 */

use Xmf\Request;
use XoopsModules\Servisler;
use XoopsModules\Servisler\Constants;

require __DIR__ . '/header.php';
$GLOBALS['xoopsOption']['template_main'] = 'servisler_index.tpl';
require_once \XOOPS_ROOT_PATH . '/header.php';
// Define Stylesheet
$GLOBALS['xoTheme']->addStylesheet($style, null);
// Keywords
$keywords = [];
// Breadcrumbs
$xoBreadcrumbs[] = ['title' => \_MA_SERVISLER_INDEX];
// Paths
$GLOBALS['xoopsTpl']->assign('xoops_icons32_url', \XOOPS_ICONS32_URL);
$GLOBALS['xoopsTpl']->assign('servisler_url', \SERVISLER_URL);
// Tables
$articlesCount = $articlesHandler->getCountArticles();
$GLOBALS['xoopsTpl']->assign('articlesCount', $articlesCount);
$count = 1;
if ($articlesCount > 0) {
    $start = Request::getInt('start', 0);
    $limit = Request::getInt('limit', $helper->getConfig('userpager'));
    $articlesAll = $articlesHandler->getAllArticles($start, $limit);
    // Get All Articles
    $articles = [];
    foreach (\array_keys($articlesAll) as $i) {
        $article = $articlesAll[$i]->getValuesArticles();
        $acount = ['count', $count];
        $articles[] = \array_merge($article, $acount);
        $keywords[] = $articlesAll[$i]->getVar('art_title');
        ++$count;
    }
    $GLOBALS['xoopsTpl']->assign('articles', $articles);
    unset($articles);
    // Display Navigation
    if ($articlesCount > $limit) {
        require_once \XOOPS_ROOT_PATH . '/class/pagenav.php';
        $pagenav = new \XoopsPageNav($articlesCount, $limit, $start, 'start', 'op=list&limit=' . $limit);
        $GLOBALS['xoopsTpl']->assign('pagenav', $pagenav->renderNav(4));
    }
    $GLOBALS['xoopsTpl']->assign('lang_thereare', \sprintf(\_MA_SERVISLER_INDEX_THEREARE, $articlesCount));
    $GLOBALS['xoopsTpl']->assign('divideby', $helper->getConfig('divideby'));
    $GLOBALS['xoopsTpl']->assign('numb_col', $helper->getConfig('numb_col'));
}
unset($count);
$GLOBALS['xoopsTpl']->assign('table_type', $helper->getConfig('table_type'));
// Keywords
servislerMetaKeywords($helper->getConfig('keywords') . ', ' . \implode(',', $keywords));
unset($keywords);
// Description
servislerMetaDescription(\_MA_SERVISLER_INDEX_DESC);
$GLOBALS['xoopsTpl']->assign('xoops_mpageurl', \SERVISLER_URL.'/index.php');
$GLOBALS['xoopsTpl']->assign('xoops_icons32_url', \XOOPS_ICONS32_URL);
$GLOBALS['xoopsTpl']->assign('servisler_upload_url', \SERVISLER_UPLOAD_URL);
require __DIR__ . '/footer.php';
