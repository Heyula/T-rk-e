# SQL Dump for servisler module
# PhpMyAdmin Version: 4.0.4
# http://www.phpmyadmin.net
#
# Host: turkish.erenyumak.com
# Generated on: Fri Nov 12, 2021 to 09:02:16
# Server version: 5.5.5-10.2.40-MariaDB
# PHP Version: 7.4.21

#
# Structure table for `servisler_categories` 4
#

CREATE TABLE `servisler_categories` (
  `cat_id` INT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cat_name` VARCHAR(255) NOT NULL DEFAULT '',
  `cat_created` INT(11) NOT NULL DEFAULT '0',
  `cat_submitter` INT(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB;

#
# Structure table for `servisler_articles` 19
#

CREATE TABLE `servisler_articles` (
  `art_id` INT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `art_cat` INT(10) NOT NULL DEFAULT '0',
  `art_title` VARCHAR(255) NOT NULL DEFAULT '',
  `art_field1` VARCHAR(255) NOT NULL DEFAULT '',
  `art_field2` VARCHAR(255) NOT NULL DEFAULT '',
  `art_field3` VARCHAR(255) NOT NULL DEFAULT '',
  `art_field4` VARCHAR(255) NOT NULL DEFAULT '',
  `art_field5` VARCHAR(255) NOT NULL DEFAULT '',
  `art_field6` VARCHAR(255) NOT NULL DEFAULT '',
  `artc_descr` MEDIUMTEXT NOT NULL ,
  `art_images` VARCHAR(255) NOT NULL DEFAULT '',
  `art_images2` VARCHAR(255) NOT NULL DEFAULT '',
  `art_file` VARCHAR(255) NOT NULL DEFAULT '',
  `art_submitter` INT(1) NOT NULL DEFAULT '0',
  `art_online` INT(1) NOT NULL DEFAULT '0',
  `art_created` INT(11) NOT NULL DEFAULT '0',
  `artc_read` INT(10) NOT NULL DEFAULT '0',
  `artc_ratings` DOUBLE(10, 2) NOT NULL DEFAULT '0.00',
  `artc_votes` INT(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`art_id`)
) ENGINE=InnoDB;

#
# Structure table for `servisler_ratings` 6
#

CREATE TABLE `servisler_ratings` (
  `rate_id` INT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rate_itemid` INT(8) NOT NULL DEFAULT '0',
  `rate_source` INT(8) NOT NULL DEFAULT '0',
  `rate_value` INT(1) NOT NULL DEFAULT '0',
  `rate_uid` INT(8) NOT NULL DEFAULT '0',
  `rate_ip` VARCHAR(60) NOT NULL DEFAULT '',
  `rate_date` INT(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_id`)
) ENGINE=InnoDB;

