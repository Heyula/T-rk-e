<?php

declare(strict_types=1);

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * Servisler module for xoops
 *
 * @copyright      2021 XOOPS Project (https://xoops.org)
 * @license        GPL 2.0 or later
 * @package        servisler
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         B.Heyula - Email:<eren@aymak.net> - Website:<http://erenyumak.com>
 */

use Xmf\Request;

require __DIR__ . '/header.php';

$cid = Request::getInt('cid', 0, 'GET');
require_once \XOOPS_ROOT_PATH.'/class/template.php';
if (\function_exists('mb_http_output')) {
    mb_http_output('pass');
}
//header ('Content-Type:text/xml; charset=UTF-8');
$xoopsModuleConfig['utf8'] = false;

$tpl = new \XoopsTpl();
$tpl->xoops_setCaching(2); //1 = Cache global, 2 = Cache individual (for template)
$tpl->xoops_setCacheTime($helper->getConfig('timecacherss')*60); // Time of the cache on seconds
$categories = servislerMyGetItemIds('servisler_view', 'servisler');
$criteria = new \CriteriaCompo();

$criteria->add(new \Criteria('cat_status', 0, '!='));
$criteria->add(new \Criteria('cid', '(' . \implode(',', $categories) . ')','IN'));
if (0 != $cid){
    $criteria->add(new \Criteria('cid', $cid));
    $articles = $articlesHandler->get($cid);
    $title = $xoopsConfig['sitename'] . ' - ' . $xoopsModule->getVar('name') . ' - ' . $articles->getVar('artc_votes');
} else {
    $title = $xoopsConfig['sitename'] . ' - ' . $xoopsModule->getVar('name');
}
$criteria->setLimit($helper->getConfig('perpagerss'));
$criteria->setSort('date');
$criteria->setOrder('DESC');
$articlesArr = $articlesHandler->getAll($criteria);
unset($criteria);

if (!$tpl->is_cached('db:servisler_rss.tpl', $cid)) {
    $tpl->assign('channel_title', \htmlspecialchars($title, ENT_QUOTES));
    $tpl->assign('channel_link', \XOOPS_URL.'/');
    $tpl->assign('channel_desc', \htmlspecialchars($xoopsConfig['slogan'], ENT_QUOTES));
    $tpl->assign('channel_lastbuild', \formatTimestamp(    ime(), 'rss'));
    $tpl->assign('channel_webmaster', $xoopsConfig['adminmail']);
    $tpl->assign('channel_editor', $xoopsConfig['adminmail']);
    $tpl->assign('channel_category', 'Event');
    $tpl->assign('channel_generator', 'XOOPS - ' . \htmlspecialchars($xoopsModule->getVar('artc_votes'), ENT_QUOTES));
    $tpl->assign('channel_language', _LANGCODE);
    if ( 'fr' == _LANGCODE ) {
        $tpl->assign('docs', 'http://www.scriptol.fr/rss/RSS-2.0.html');
    } else {
        $tpl->assign('docs', 'http://cyber.law.harvard.edu/rss/rss.html');
    }
    $tpl->assign('image_url', \XOOPS_URL . $xoopsModuleConfig['logorss']);
    $dimention = \getimagesize(\XOOPS_ROOT_PATH . $xoopsModuleConfig['logorss']);
    if (empty($dimention[0])) {
        $width = 88;
    } else {
       $width = ($dimention[0] > 144) ? 144 : $dimention[0];
    }
    if (empty($dimention[1])) {
        $height = 31;
    } else {
        $height = ($dimention[1] > 400) ? 400 : $dimention[1];
    }
    $tpl->assign('image_width', $width);
    $tpl->assign('image_height', $height);
    foreach (\array_keys($articlesArr) as $i) {
        $description = $articlesArr[$i]->getVar('description');
        //permet d'afficher uniquement la description courte
        if (false == \strpos($description,'[pagebreak]')){
            $description_short = $description;
        } else {
            $description_short = \substr($description,0,\strpos($description,'[pagebreak]'));
        }
        $tpl->append('items', ['title' => \htmlspecialchars($articlesArr[$i]->getVar('artc_votes'), ENT_QUOTES),
                                    'link' => \XOOPS_URL . '/modules/servisler/single.php?cid=' . $articlesArr[$i]->getVar('cid') . '&amp;art_id=' . $articlesArr[$i]->getVar('art_id'),
                                    'guid' => \XOOPS_URL . '/modules/servisler/single.php?cid=' . $articlesArr[$i]->getVar('cid') . '&amp;art_id=' . $articlesArr[$i]->getVar('art_id'),
                                    'pubdate' => \formatTimestamp($articlesArr[$i]->getVar('date'), 'rss'),
                                    'description' => \htmlspecialchars($description_short, ENT_QUOTES)
                                ]);
    }
}
header('Content-Type:text/xml; charset=' . _CHARSET);
$tpl->display('db:servisler_rss.tpl', $cid);
