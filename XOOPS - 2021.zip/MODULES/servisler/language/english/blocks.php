<?php

declare(strict_types=1);

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * Servisler module for xoops
 *
 * @copyright      2021 XOOPS Project (https://xoops.org)
 * @license        GPL 2.0 or later
 * @package        servisler
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         B.Heyula - Email:<eren@aymak.net> - Website:<http://erenyumak.com>
 */
// Admin Edit
\define('_MB_SERVISLER_DISPLAY', 'How Many Tables to Display');
\define('_MB_SERVISLER_TITLE_LENGTH', 'Title Length');
\define('_MB_SERVISLER_CATTODISPLAY', 'Categories to Display');
\define('_MB_SERVISLER_ALLCAT', 'All Categories');
// Articles
\define('_MB_SERVISLER_ARTICLES_TO_DISPLAY', 'Articles to Display');
\define('_MB_SERVISLER_ALL_ARTICLES', 'All Articles');
\define('_MB_SERVISLER_ART_CAT', 'Cat');
\define('_MB_SERVISLER_ART_TITLE', 'Title');
\define('_MB_SERVISLER_ART_FIELD1', 'Field1');
\define('_MB_SERVISLER_ART_FIELD2', 'Field2');
\define('_MB_SERVISLER_ART_FIELD3', 'Field3');
\define('_MB_SERVISLER_ART_FIELD4', 'Field4');
\define('_MB_SERVISLER_ART_FIELD5', 'Field5');
\define('_MB_SERVISLER_ART_FIELD6', 'Field6');
\define('_MB_SERVISLER_ARTC_DESCR', 'Descr');
\define('_MB_SERVISLER_ART_IMAGES', 'Images');
\define('_MB_SERVISLER_ART_IMAGES2', 'Images2');
\define('_MB_SERVISLER_ART_FILE', 'File');
\define('_MB_SERVISLER_ART_SUBMITTER', 'Submitter');
\define('_MB_SERVISLER_ART_ONLINE', 'Online');
\define('_MB_SERVISLER_ART_CREATED', 'Created');
\define('_MB_SERVISLER_ARTC_READ', 'Read');
\define('_MB_SERVISLER_ARTICLE_GOTO', 'Goto Article');
// ---------------- End ----------------
