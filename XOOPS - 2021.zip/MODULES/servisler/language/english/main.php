<?php

declare(strict_types=1);

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * Servisler module for xoops
 *
 * @copyright      2021 XOOPS Project (https://xoops.org)
 * @license        GPL 2.0 or later
 * @package        servisler
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         B.Heyula - Email:<eren@aymak.net> - Website:<http://erenyumak.com>
 */

require_once __DIR__ . '/admin.php';

// ---------------- Main ----------------
\define('_MA_SERVISLER_INDEX', 'Overview Servisler');
\define('_MA_SERVISLER_TITLE', 'Servisler');
\define('_MA_SERVISLER_DESC', 'Sunulan servisler veya hizmetlerin yayınlana bileceği modül.');
\define('_MA_SERVISLER_INDEX_DESC', "Welcome to the homepage of your new module Servisler!<br>
As you can see, you have created a page with a list of links at the top to navigate between the pages of your module. This description is only visible on the homepage of this module, the other pages you will see the content you created when you built this module with the module ModuleBuilder, and after creating new content in admin of this module. In order to expand this module with other resources, just add the code you need to extend the functionality of the same. The files are grouped by type, from the header to the footer to see how divided the source code.<br><br>If you see this message, it is because you have not created content for this module. Once you have created any type of content, you will not see this message.<br><br>If you liked the module ModuleBuilder and thanks to the long process for giving the opportunity to the new module to be created in a moment, consider making a donation to keep the module ModuleBuilder and make a donation using this button <a href='https://xoops.org/modules/xdonations/index.php' title='Donation To Txmod Xoops'><img src='https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif' alt='Button Donations' ></a><br>Thanks!<br><br>Use the link below to go to the admin and create content.");
\define('_MA_SERVISLER_NO_PDF_LIBRARY', 'Libraries TCPDF not there yet, upload them in root/Frameworks');
\define('_MA_SERVISLER_NO', 'No');
\define('_MA_SERVISLER_DETAILS', 'Show details');
\define('_MA_SERVISLER_BROKEN', 'Notify broken');
// ---------------- Contents ----------------
// Article
\define('_MA_SERVISLER_ARTICLE', 'Article');
\define('_MA_SERVISLER_ARTICLE_ADD', 'Add Article');
\define('_MA_SERVISLER_ARTICLE_EDIT', 'Edit Article');
\define('_MA_SERVISLER_ARTICLE_DELETE', 'Delete Article');
\define('_MA_SERVISLER_ARTICLE_CLONE', 'Clone Article');
\define('_MA_SERVISLER_ARTICLES', 'Articles');
\define('_MA_SERVISLER_ARTICLES_LIST', 'List of Articles');
\define('_MA_SERVISLER_ARTICLES_TITLE', 'Articles title');
\define('_MA_SERVISLER_ARTICLES_DESC', 'Articles description');
// Caption of Article
\define('_MA_SERVISLER_ARTICLE_ID', 'Id');
\define('_MA_SERVISLER_ARTICLE_CAT', 'Cat');
\define('_MA_SERVISLER_ARTICLE_TITLE', 'Title');
\define('_MA_SERVISLER_ARTICLE_FIELD1', 'Field1');
\define('_MA_SERVISLER_ARTICLE_FIELD2', 'Field2');
\define('_MA_SERVISLER_ARTICLE_FIELD3', 'Field3');
\define('_MA_SERVISLER_ARTICLE_FIELD4', 'Field4');
\define('_MA_SERVISLER_ARTICLE_FIELD5', 'Field5');
\define('_MA_SERVISLER_ARTICLE_FIELD6', 'Field6');
\define('_MA_SERVISLER_ARTICLE_DESCR', 'Descr');
\define('_MA_SERVISLER_ARTICLE_IMAGES', 'Images');
\define('_MA_SERVISLER_ARTICLE_IMAGES2', 'Images2');
\define('_MA_SERVISLER_ARTICLE_FILE', 'File');
\define('_MA_SERVISLER_ARTICLE_SUBMITTER', 'Submitter');
\define('_MA_SERVISLER_ARTICLE_ONLINE', 'Online');
\define('_MA_SERVISLER_ARTICLE_CREATED', 'Created');
\define('_MA_SERVISLER_ARTICLE_READ', 'Read');
\define('_MA_SERVISLER_ARTICLE_RATINGS', 'Ratings');
\define('_MA_SERVISLER_ARTICLE_VOTES', 'Votes');
\define('_MA_SERVISLER_INDEX_THEREARE', 'There are %s Articles');
\define('_MA_SERVISLER_INDEX_LATEST_LIST', 'Last Servisler');
// Submit
\define('_MA_SERVISLER_SUBMIT', 'Submit');
// Form
\define('_MA_SERVISLER_FORM_OK', 'Successfully saved');
\define('_MA_SERVISLER_FORM_DELETE_OK', 'Successfully deleted');
\define('_MA_SERVISLER_FORM_SURE_DELETE', "Are you sure to delete: <b><span style='color : Red;'>%s </span></b>");
\define('_MA_SERVISLER_FORM_SURE_RENEW', "Are you sure to update: <b><span style='color : Red;'>%s </span></b>");
\define('_MA_SERVISLER_FORM_SURE_BROKEN', "Are you sure to notify as broken: <b><span style='color : Red;'>%s </span></b>");
\define('_MA_SERVISLER_INVALID_PARAM', 'Invalid parameter');
// ---------------- Ratings ----------------
\define('_MA_SERVISLER_RATING_CURRENT_1', 'Rating: %c / %m (%t rating totally)');
\define('_MA_SERVISLER_RATING_CURRENT_X', 'Rating: %c / %m (%t ratings totally)');
\define('_MA_SERVISLER_RATING_CURRENT_SHORT_1', '%c (%t rating)');
\define('_MA_SERVISLER_RATING_CURRENT_SHORT_X', '%c (%t ratings)');
\define('_MA_SERVISLER_RATING1', '1 of 5');
\define('_MA_SERVISLER_RATING2', '2 of 5');
\define('_MA_SERVISLER_RATING3', '3 of 5');
\define('_MA_SERVISLER_RATING4', '4 of 5');
\define('_MA_SERVISLER_RATING5', '5 of 5');
\define('_MA_SERVISLER_RATING_10_1', '1 of 10');
\define('_MA_SERVISLER_RATING_10_2', '2 of 10');
\define('_MA_SERVISLER_RATING_10_3', '3 of 10');
\define('_MA_SERVISLER_RATING_10_4', '4 of 10');
\define('_MA_SERVISLER_RATING_10_5', '5 of 10');
\define('_MA_SERVISLER_RATING_10_6', '6 of 10');
\define('_MA_SERVISLER_RATING_10_7', '7 of 10');
\define('_MA_SERVISLER_RATING_10_8', '8 of 10');
\define('_MA_SERVISLER_RATING_10_9', '9 of 10');
\define('_MA_SERVISLER_RATING_10_10', '10 of 10');
\define('_MA_SERVISLER_RATING_VOTE_BAD', 'Invalid vote');
\define('_MA_SERVISLER_RATING_VOTE_ALREADY', 'You have already voted');
\define('_MA_SERVISLER_RATING_VOTE_THANKS', 'Thank you for rating');
\define('_MA_SERVISLER_RATING_NOPERM', "Sorry, you don't have permission to rate items");
\define('_MA_SERVISLER_RATING_LIKE', 'Like');
\define('_MA_SERVISLER_RATING_DISLIKE', 'Dislike');
\define('_MA_SERVISLER_RATING_ERROR1', 'Error: update base table failed!');
// ---------------- Print ----------------
\define('_MA_SERVISLER_PRINT', 'Print');
// Admin link
\define('_MA_SERVISLER_ADMIN', 'Admin');
// ---------------- End ----------------
