<?php

declare(strict_types=1);

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * Servisler module for xoops
 *
 * @copyright      2021 XOOPS Project (https://xoops.org)
 * @license        GPL 2.0 or later
 * @package        servisler
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         B.Heyula - Email:<eren@aymak.net> - Website:<http://erenyumak.com>
 */
if (!\defined('XOOPS_ICONS32_PATH')) {
    \define('XOOPS_ICONS32_PATH', \XOOPS_ROOT_PATH . '/Frameworks/moduleclasses/icons/32');
}
if (!\defined('XOOPS_ICONS32_URL')) {
    \define('XOOPS_ICONS32_URL', \XOOPS_URL . '/Frameworks/moduleclasses/icons/32');
}
\define('SERVISLER_DIRNAME', 'servisler');
\define('SERVISLER_PATH', \XOOPS_ROOT_PATH . '/modules/' . \SERVISLER_DIRNAME);
\define('SERVISLER_URL', \XOOPS_URL . '/modules/' . \SERVISLER_DIRNAME);
\define('SERVISLER_ICONS_PATH', \SERVISLER_PATH . '/assets/icons');
\define('SERVISLER_ICONS_URL', \SERVISLER_URL . '/assets/icons');
\define('SERVISLER_IMAGE_PATH', \SERVISLER_PATH . '/assets/images');
\define('SERVISLER_IMAGE_URL', \SERVISLER_URL . '/assets/images');
\define('SERVISLER_UPLOAD_PATH', \XOOPS_UPLOAD_PATH . '/' . \SERVISLER_DIRNAME);
\define('SERVISLER_UPLOAD_URL', \XOOPS_UPLOAD_URL . '/' . \SERVISLER_DIRNAME);
\define('SERVISLER_UPLOAD_FILES_PATH', \SERVISLER_UPLOAD_PATH . '/files');
\define('SERVISLER_UPLOAD_FILES_URL', \SERVISLER_UPLOAD_URL . '/files');
\define('SERVISLER_UPLOAD_IMAGE_PATH', \SERVISLER_UPLOAD_PATH . '/images');
\define('SERVISLER_UPLOAD_IMAGE_URL', \SERVISLER_UPLOAD_URL . '/images');
\define('SERVISLER_UPLOAD_SHOTS_PATH', \SERVISLER_UPLOAD_PATH . '/images/shots');
\define('SERVISLER_UPLOAD_SHOTS_URL', \SERVISLER_UPLOAD_URL . '/images/shots');
\define('SERVISLER_ADMIN', \SERVISLER_URL . '/admin/index.php');
$localLogo = \SERVISLER_IMAGE_URL . '/b.heyula_logo.png';
// Module Information
$copyright = "<a href='http://erenyumak.com' title='XOOPS Project' target='_blank'><img src='" . $localLogo . "' alt='XOOPS Project' ></a>";
require_once \XOOPS_ROOT_PATH . '/class/xoopsrequest.php';
require_once \SERVISLER_PATH . '/include/functions.php';
