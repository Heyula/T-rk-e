<?php

declare(strict_types=1);

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * Servisler module for xoops
 *
 * @copyright      2021 XOOPS Project (https://xoops.org)
 * @license        GPL 2.0 or later
 * @package        servisler
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         B.Heyula - Email:<eren@aymak.net> - Website:<http://erenyumak.com>
 */

use Xmf\Request;
use XoopsModules\Servisler;
use XoopsModules\Servisler\Constants;

require __DIR__ . '/header.php';

// Define Stylesheet
$GLOBALS['xoTheme']->addStylesheet($style, null);
$templateMain = 'servisler_admin_broken.tpl';
$GLOBALS['xoopsTpl']->assign('navigation', $adminObject->displayNavigation('broken.php'));

// Check table articles
$start = Request::getInt('startArticles', 0);
$limit = Request::getInt('limitArticles', $helper->getConfig('adminpager'));
$crArticles = new \CriteriaCompo();
$crArticles->add(new \Criteria('art_online', Constants::STATUS_BROKEN));
$articlesCount = $articlesHandler->getCount($crArticles);
$GLOBALS['xoopsTpl']->assign('articles_count', $articlesCount);
$GLOBALS['xoopsTpl']->assign('articles_result', \sprintf(\_AM_SERVISLER_BROKEN_RESULT, 'Articles'));
$crArticles->setStart($start);
$crArticles->setLimit($limit);
if ($articlesCount > 0) {
    $articlesAll = $articlesHandler->getAll($crArticles);
    foreach (\array_keys($articlesAll) as $i) {
        $article['table'] = 'Articles';
        $article['key'] = 'art_id';
        $article['keyval'] = $articlesAll[$i]->getVar('art_id');
        $article['main'] = $articlesAll[$i]->getVar('art_title');
        $GLOBALS['xoopsTpl']->append('articles_list', $article);
    }
    // Display Navigation
    if ($articlesCount > $limit) {
        require_once \XOOPS_ROOT_PATH . '/class/pagenav.php';
        $pagenav = new \XoopsPageNav($articlesCount, $limit, $start, 'startArticles', 'op=list&limitArticles=' . $limit);
        $GLOBALS['xoopsTpl']->assign('pagenav', $pagenav->renderNav(4));
    }
} else {
    $GLOBALS['xoopsTpl']->assign('nodataArticles', \sprintf(\_AM_SERVISLER_BROKEN_NODATA, 'Articles'));
}
unset($crArticles);

require __DIR__ . '/footer.php';
