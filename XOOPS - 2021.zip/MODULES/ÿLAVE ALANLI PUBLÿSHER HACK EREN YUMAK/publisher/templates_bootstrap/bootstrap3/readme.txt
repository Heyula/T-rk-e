Readme

1. Move publisher folder to your bootstrap3 theme modules folder to use this templates 
root/themes/yourtheme/modules/

2. Clean your cache folders in maintenance section in the XOOPS admin