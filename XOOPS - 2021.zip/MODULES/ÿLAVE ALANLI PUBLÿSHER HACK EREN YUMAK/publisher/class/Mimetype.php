<?php

declare(strict_types=1);

namespace XoopsModules\Publisher;

/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 *  Publisher class
 *
 * @copyright       The XUUPS Project http://sourceforge.net/projects/xuups/
 * @license         http://www.fsf.org/copyleft/gpl.html GNU public license
 * @since           1.0
 * @author          trabis <lusopoemas@gmail.com>
 * @author          The SmartFactory <www.smartfactory.ca>
 */

require_once \dirname(__DIR__) . '/include/common.php';

/**
 * Mimetype class
 *
 * @author  Eric Juden <ericj@epcusa.com>
 */
class Mimetype extends \XoopsObject
{
    /**
     * @param null|int|array $id
     */
    public function __construct($id = null)
    {
        $this->initVar('mime_id', \XOBJ_DTYPE_INT, null, false);
        $this->initVar('mime_ext', \XOBJ_DTYPE_TXTBOX, null, true, 60);
        $this->initVar('mime_types', \XOBJ_DTYPE_TXTAREA, null, false, 1024);
        $this->initVar('mime_name', \XOBJ_DTYPE_TXTBOX, null, true, 255);
        $this->initVar('mime_admin', \XOBJ_DTYPE_INT, null, false);
        $this->initVar('mime_user', \XOBJ_DTYPE_INT, null, false);
        if (isset($id)) {
            if (\is_array($id)) {
                $this->assignVars($id);
            }
        } else {
            $this->setNew();
        }
    }
}
