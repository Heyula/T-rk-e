<?php

declare(strict_types=1);

define('_MI_PUBLISHER_ADMENU1', 'Özet');
define('_MI_PUBLISHER_ADMENU2', 'Kategoriler');
define('_MI_PUBLISHER_ADMENU3', 'Makaleler');
define('_MI_PUBLISHER_ADMENU4', 'İzinler');
define('_MI_PUBLISHER_ADMENU6', 'Uzantı Türleri');
define('_MI_PUBLISHER_ADMINHITS', 'Yönetici sayacı okumaları?');
define('_MI_PUBLISHER_ADMINHITSDSC', 'Sayaç istatistikleri için yönetici okuma sayısına izin ver?');
define('_MI_PUBLISHER_ALLOWSUBMIT', 'Kullanıcı gönderimleri ?');
define('_MI_PUBLISHER_ALLOWSUBMITDSC', 'Kullanıcıların web sitenize makale göndermesine izin verin?');
define('_MI_PUBLISHER_ANONPOST', 'Anonim gönderiye izin ver?');
define('_MI_PUBLISHER_ANONPOSTDSC', 'Anonim kullanıcıların makale göndermesine izin ver?');
define('_MI_PUBLISHER_AUTHOR_INFO', 'Geliştirici');
define('_MI_PUBLISHER_AUTHOR_WORD', 'Yazarın Sözü');
define('_MI_PUBLISHER_AUTOAPP', 'Gönderilen makaleleri otomatik onayla?');
define('_MI_PUBLISHER_AUTOAPPDSC', 'Yönetici müdahalesi olmadan gönderilen makaleleri otomatik olarak onaylansınmı?');
define('_MI_PUBLISHER_BCRUMB', 'Modül adını breadcrumb da göster?');
define('_MI_PUBLISHER_BCRUMBDSC', " | EVET | seçerseniz içerik haritası 'Publisher > category name > article name'. <br>Aksi takdirde, yalnızca 'category name > article name' gösterilecek.");
define('_MI_PUBLISHER_BOTH_FOOTERS', 'Her iki altbilgi');
define('_MI_PUBLISHER_BY', 'by');
define('_MI_PUBLISHER_CATEGORY_ITEM_NOTIFY', 'Kategori Öğeleri');
define('_MI_PUBLISHER_CATEGORY_ITEM_NOTIFY_DSC', 'Mevcut kategori için geçerli olan bildirim seçenekleri.');
define('_MI_PUBLISHER_CATEGORY_ITEM_PUBLISHED_NOTIFY', 'Yeni makale yayınlandı');
define('_MI_PUBLISHER_CATEGORY_ITEM_PUBLISHED_NOTIFY_CAP', 'Mevcut kategoride yeni bir makale yayınlandığında bana haber ver.');
define('_MI_PUBLISHER_CATEGORY_ITEM_PUBLISHED_NOTIFY_DSC', 'Mevcut kategoride yeni bir makale yayınlandığında bildirim alın.');
define('_MI_PUBLISHER_CATEGORY_ITEM_PUBLISHED_NOTIFY_SBJ', '[{X_SITENAME}] {X_MODULE} otomatik bildir: Kategoride yayınlanan yeni makale');
define('_MI_PUBLISHER_CATEGORY_ITEM_SUBMITTED_NOTIFY', 'Makale gönderildi');
define('_MI_PUBLISHER_CATEGORY_ITEM_SUBMITTED_NOTIFY_CAP', 'Mevcut kategoride yeni bir makale gönderildiğinde bana haber ver.');
define('_MI_PUBLISHER_CATEGORY_ITEM_SUBMITTED_NOTIFY_DSC', 'Mevcut kategoride yeni bir makale gönderildiğinde bildirim alın.');
define('_MI_PUBLISHER_CATEGORY_ITEM_SUBMITTED_NOTIFY_SBJ', '[{X_SITENAME}] {X_MODULE} otomatik bildir: Kategoriye gönderilen yeni makale');
define('_MI_PUBLISHER_CATLIST_IMG_W', 'Kategori listesi görüntü genişliği');
define('_MI_PUBLISHER_CATLIST_IMG_WDSC', 'Kategorileri listelerken kategori resimlerinin genişliğini belirtin.');
define('_MI_PUBLISHER_CATMAINIMG_W', 'Kategori ana resim genişliği');
define('_MI_PUBLISHER_CATMAINIMG_WDSC', 'Kategori ana resminin genişliğini belirtin.');
define('_MI_PUBLISHER_CATPERPAGE', 'Sayfa başına maksimum Kategori (Kullanıcı tarafı)?');
define('_MI_PUBLISHER_CATPERPAGEDSC', 'Kullanıcı tarafında bir kerede görüntülenecek sayfa başına maksimum kategori sayısı?');
define('_MI_PUBLISHER_CLONE', 'Makale çoğaltmasına izin verilsin mi?');
define('_MI_PUBLISHER_CLONEDSC', 'Uygun izinlere sahip kullanıcıların bir makaleyi kopyalamasına izin vermek için "Evet"i seçin.');
define('_MI_PUBLISHER_COLLHEAD', 'Daralan çubuğu görüntüle?');
define('_MI_PUBLISHER_COLLHEADDSC', 'Bu seçeneği “Evet” olarak ayarlarsanız, makalelerin yanı sıra kategori özeti de daraltılabilir bir çubukta görüntülenecektir. Bu seçeneği “Hayır” olarak ayarlarsanız, daraltılabilir çubuk görüntülenmez.');
define('_MI_PUBLISHER_COMMENTS', 'Yorumları makale düzeyinde kontrol ediyor musunuz?');
define('_MI_PUBLISHER_COMMENTSDSC', 'bu seçeneği "Evet" olarak ayarlarsanız, yalnızca yorum onay kutusu işaretli öğelerdeki yorumları görürsünüz. <br><br>Seçiminiz “Hayır” ise yorumların küresel düzeyde yönetilmesini sağlamak için (aşağıya \'Yorum kuralları\' etiketinin altına bakın.');
define('_MI_PUBLISHER_DATEFORMAT', 'Tarih formatı:');
define('_MI_PUBLISHER_DATEFORMATDSC', "Bir görüntüleme stili seçin. Örnek: 'd-M-Y H:i' Çevirir '30-Mar-2004 22:35'<br><a href='http://php.net/manual/en/function.date.php/' target='_blank'>Daha fazla görüntüleme seçeneği için PHP kılavuzuna bakın.</a>");
define('_MI_PUBLISHER_DEMO_SITE', 'SmartFactory Demo Sitesi');
define('_MI_PUBLISHER_DEVELOPER_CONTRIBUTOR', 'Katkıda Bulunanlar');
define('_MI_PUBLISHER_DEVELOPER_CREDITS', 'Kredi');
define('_MI_PUBLISHER_DEVELOPER_EMAIL', 'Email');
define('_MI_PUBLISHER_DEVELOPER_LEAD', 'Baş geliştirici(ler)');
define('_MI_PUBLISHER_DEVELOPER_WEBSITE', 'Website');
define('_MI_PUBLISHER_DISCOM', 'Yorum sayısı gösterilsin mi?');
define('_MI_PUBLISHER_DISCOMDSC', 'Her bir makaledeki yorum sayısını görüntülemek için “Evet” olarak ayarlayın.');
define('_MI_PUBLISHER_DISDATECOL', 'Gösterilsinmi \'Yayınlanma tarihi\' sütunu?');
define('_MI_PUBLISHER_DISDATECOLDSC', 'Dizin ve Kategori sayfasındaki öğeler tablosunda "Yayınlanma tarihi"ni görüntülemek için "Evet"i seçin.');
define('_MI_PUBLISHER_DCS', 'Kategori özeti görüntülensin mi?');
define('_MI_PUBLISHER_DCS_DSC', 'Alt kategorisi olmayan bir kategori sayfasında kategori özetini görüntülememek için “Hayır” seçin');
define('_MI_PUBLISHER_DISPLAYTYPE_FULL', 'Full View');
define('_MI_PUBLISHER_DISPLAYTYPE_LIST', 'Bullet list');
define('_MI_PUBLISHER_DISPLAYTYPE_WFSECTION', 'WFSection style');
define('_MI_PUBLISHER_DISPLAYTYPE_SUMMARY', 'Summary View');
define('_MI_PUBLISHER_DISSBCATDSC', 'Alt kategori açıklamaları görüntülensin mi?');
define('_MI_PUBLISHER_DISSBCATDSCDSC', 'İndeks ve kategori sayfasında alt kategorilerin açıklamasını görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_DISTYPE', 'Makaleleri görüntüleme türü:');
define('_MI_PUBLISHER_DISTYPEDSC', 'Dizin ve Kategori sayfasında kullanılacak şablonu seçin.');
define('_MI_PUBLISHER_FOOTERPRINT', 'Sayfa alt bilgisini yazdır');
define('_MI_PUBLISHER_FOOTERPRINTDSC', 'Her makale için yazdırılacak altbilgi');
define('_MI_PUBLISHER_GLOBAL_ITEM_CATEGORY_CREATED_NOTIFY', 'Yeni kategori');
define('_MI_PUBLISHER_GLOBAL_ITEM_CATEGORY_CREATED_NOTIFY_CAP', 'Yeni bir kategori oluşturulduğunda bana haber ver.');
define('_MI_PUBLISHER_GLOBAL_ITEM_CATEGORY_CREATED_NOTIFY_DSC', 'Yeni bir kategori oluşturulduğunda bildirim alın.');
define('_MI_PUBLISHER_GLOBAL_ITEM_CATEGORY_CREATED_NOTIFY_SBJ', '[{X_SITENAME}] {X_MODULE} otomatik bildir: Yeni kategori');
define('_MI_PUBLISHER_GLOBAL_ITEM_NOTIFY', 'Tüm Makaleler');
define('_MI_PUBLISHER_GLOBAL_ITEM_NOTIFY_DSC', 'Tüm makaleler için geçerli olan bildirim seçenekleri.');
define('_MI_PUBLISHER_GLOBAL_ITEM_PUBLISHED_NOTIFY', 'Yeni makale yayınlandı');
define('_MI_PUBLISHER_GLOBAL_ITEM_PUBLISHED_NOTIFY_CAP', 'Herhangi bir yeni makale yayınlandığında bana haber ver.');
define('_MI_PUBLISHER_GLOBAL_ITEM_PUBLISHED_NOTIFY_DSC', 'Herhangi bir yeni makale yayınlandığında bildirim alın.');
define('_MI_PUBLISHER_GLOBAL_ITEM_PUBLISHED_NOTIFY_SBJ', '[{X_SITENAME}] {X_MODULE} auto-notify: Yeni makale yayınlandı');
define('_MI_PUBLISHER_GLOBAL_ITEM_SUBMITTED_NOTIFY', 'Makale gönderildi');
define('_MI_PUBLISHER_GLOBAL_ITEM_SUBMITTED_NOTIFY_CAP', 'Herhangi bir makale gönderildiğinde ve onay beklediğinde bana haber ver.');
define('_MI_PUBLISHER_GLOBAL_ITEM_SUBMITTED_NOTIFY_DSC', 'Herhangi bir makale gönderildiğinde ve onay beklediğinde bildirim alın.');
define('_MI_PUBLISHER_GLOBAL_ITEM_SUBMITTED_NOTIFY_SBJ', '[{X_SITENAME}] {X_MODULE} auto-notify: Yeni makale gönderildi');
define('_MI_PUBLISHER_HEADERPRINT', 'Sayfa başlığını yazdır');
define('_MI_PUBLISHER_HEADERPRINTDSC', 'Her makale için yazdırılacak başlık');
define('_MI_PUBLISHER_HITSCOL', '"Hit" sütunu görüntülensin mi?');
define('_MI_PUBLISHER_HITSCOLDSC', 'Dizin ve kategori sayfasındaki öğeler tablosundaki “Hit” sütununu görüntülemek için “Evet” i seçin. ');
define('_MI_PUBLISHER_HLCOLOR', 'Anahtar kelimeler için vurgu rengi');
define('_MI_PUBLISHER_HLCOLORDSC', 'Arama işlevi için vurgulanan anahtar kelimelerin rengi.');
define('_MI_PUBLISHER_IMAGENAV', 'Sayfa Gezinme resmini kullanın:');
define('_MI_PUBLISHER_IMAGENAVDSC', 'Bu seçeneği “Evet” olarak ayarlarsanız, Sayfa Gezinti görüntülerle birlikte görüntülenecektir, aksi takdirde orijinal Sayfa Gezintisi kullanılacaktır.');
define('_MI_PUBLISHER_INDEXFOOTER', 'Dizin Altbilgisi');
define('_MI_PUBLISHER_INDEXFOOTER_SEL', 'Dizin Altbilgisi');
define('_MI_PUBLISHER_INDEXFOOTERDSC', 'Modülün dizin sayfasında görüntülenecek olan altbilgi.');
define('_MI_PUBLISHER_INDEXMSG', 'Dizin sayfası karşılama mesajı:');
define('_MI_PUBLISHER_INDEXMSGDEF', '');
define('_MI_PUBLISHER_INDEXMSGDSC', 'Modülün dizin sayfasında görüntülenecek hoş geldiniz mesajı.');
define('_MI_PUBLISHER_ITEM_APPROVED_NOTIFY', 'Makale onaylandı');
define('_MI_PUBLISHER_ITEM_APPROVED_NOTIFY_CAP', 'Bu makale onaylandığında bana haber ver.');
define('_MI_PUBLISHER_ITEM_APPROVED_NOTIFY_DSC', 'Bu makale onaylandığında bildirim alın.');
define('_MI_PUBLISHER_ITEM_APPROVED_NOTIFY_SBJ', '[{X_SITENAME}] {X_MODULE} otomatik bildir: makale onaylandı');
define('_MI_PUBLISHER_ITEM_NOTIFY', 'Makale');
define('_MI_PUBLISHER_ITEM_NOTIFY_DSC', 'Mevcut makale için geçerli olan bildirim seçenekleri.');
define('_MI_PUBLISHER_ITEM_REJECTED_NOTIFY', 'Makale reddedildi');
define('_MI_PUBLISHER_ITEM_REJECTED_NOTIFY_CAP', 'Bu makale reddedilirse bana haber ver.');
define('_MI_PUBLISHER_ITEM_REJECTED_NOTIFY_DSC', 'Bu makale reddedilirse bildirim alın.');
define('_MI_PUBLISHER_ITEM_REJECTED_NOTIFY_SBJ', '[{X_SITENAME}] {X_MODULE} otomatik bildir: makale reddedildi');
define('_MI_PUBLISHER_ITEMFOOTER', 'Öğe altbilgisi');
define('_MI_PUBLISHER_ITEMFOOTER_SEL', 'Öğe altbilgisi');
define('_MI_PUBLISHER_ITEMFOOTERDSC', 'Her makale için görüntülenecek altbilgi.');
define('_MI_PUBLISHER_ITEMSMENU', 'Kategoriler Menü bloğu');
//bd tree block hack
define('_MI_PUBLISHER_ITEMSTREE', 'Ağaç bloğu');
//--/bd
define('_MI_PUBLISHER_ITEMSNEW', 'Yeni Makaleler Listesi');
define('_MI_PUBLISHER_ITEMSPOT', 'Spotlight! içinde');
define('_MI_PUBLISHER_ITEMSRANDOM_ITEM', 'Rastgele öğe!');
define('_MI_PUBLISHER_LASTITEM', 'Son öğe sütununu görüntüle?');
define('_MI_PUBLISHER_LASTITEMDSC', 'Dizin ve kategori sayfasındaki her kategorideki son öğeyi görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_LASTITEMS', 'Yeni yayınlanan makalelerin listesi görüntülensin mi?');
define('_MI_PUBLISHER_LASTITEMSDSC', 'Listenin modülün indeks ve kategori sayfasının en altında olması için “Evet”i seçin.');
define('_MI_PUBLISHER_LASTITSIZE', 'Son öğe boyutu:');
define('_MI_PUBLISHER_LASTITSIZEDSC', 'Son öğe sütununda başlığın maksimum boyutunu ayarlayın.');
define('_MI_PUBLISHER_LINKPATH', 'Geçerli yoldaki bağlantıları etkinleştir:');
define('_MI_PUBLISHER_LINKPATHDSC', 'Bu seçenek, kullanıcının sayfanın üstünde görüntülenen mevcut yolun bir öğesini tıklatarak geri izlemesini sağlar.');
define('_MI_PUBLISHER_MAX_HEIGHT', 'Maksimum yüklenen resim yüksekliği');
define('_MI_PUBLISHER_MAX_HEIGHTDSC', 'Bir resim dosyasının yüklenebilecek maksimum yüksekliği.');
define('_MI_PUBLISHER_MAX_SIZE', 'Maksimum dosya boyutu');
define('_MI_PUBLISHER_MAX_SIZEDSC', 'Yüklenebilecek bir dosyanın maksimum boyutu (bayt cinsinden).');
define('_MI_PUBLISHER_MAX_WIDTH', 'Maksimum yüklenen resim genişliği');
define('_MI_PUBLISHER_MAX_WIDTHDSC', 'Yüklenebilecek bir resim dosyasının maksimum genişliği.');
define('_MI_PUBLISHER_MD_DESC', 'XOOPS Siteniz için Yayıncılık Çözümü');
define('_MI_PUBLISHER_MD_NAME', 'Yayımcı');
define('_MI_PUBLISHER_MODULE_BUG', 'Bu modül için bir hata bildir');
define('_MI_PUBLISHER_MODULE_DEMO', 'Demo Site');
define('_MI_PUBLISHER_MODULE_DISCLAIMER', 'Sorumluluk reddi');
define('_MI_PUBLISHER_MODULE_FEATURE', 'Bu modül için yeni bir özellik önerin');
define('_MI_PUBLISHER_MODULE_INFO', 'Modül Geliştirme ayrıntıları');
define('_MI_PUBLISHER_MODULE_RELEASE_DATE', 'Yayın tarihi');
define('_MI_PUBLISHER_MODULE_STATUS', 'Durum');
define('_MI_PUBLISHER_MODULE_SUBMIT_BUG', 'Hata gönder');
define('_MI_PUBLISHER_MODULE_SUBMIT_FEATURE', 'Bir özellik isteği gönderin');
define('_MI_PUBLISHER_MODULE_SUPPORT', 'Resmi destek sitesi');
define('_MI_PUBLISHER_NO_FOOTERS', 'Hiçbiri');
define('_MI_PUBLISHER_ORDERBY', 'Sıralama düzeni');
define('_MI_PUBLISHER_ORDERBY_DATE', 'Tarih DESC');
define('_MI_PUBLISHER_ORDERBY_TITLE', 'Başlık ASC');
define('_MI_PUBLISHER_ORDERBY_WEIGHT', 'Sıralam ASC');
define('_MI_PUBLISHER_ORDERBYDSC', 'Modül boyunca öğelerin sıralama düzenini seçin.');
define('_MI_PUBLISHER_OTHER_ITEMS_TYPE_ALL', 'Tüm Makaleler');
define('_MI_PUBLISHER_OTHER_ITEMS_TYPE_NONE', 'Hiçbiri');
define('_MI_PUBLISHER_OTHER_ITEMS_TYPE_PREVIOUS_NEXT', 'Önceki ve sonraki makale');
define('_MI_PUBLISHER_OTHERITEMS', 'Diğer makaleler görüntüleme türü');
define('_MI_PUBLISHER_OTHERITEMSDSC', 'Makale sayfasında kategorinin diğer makalelerini nasıl görüntülemek istediğinizi seçin.');
define('_MI_PUBLISHER_PERPAGE', 'Sayfa başına maksimum makale (Yönetici tarafı):');
define('_MI_PUBLISHER_PERPAGEDSC', 'Yönetici tarafında bir kerede görüntülenecek sayfa başına maksimum makale sayısı.');
define('_MI_PUBLISHER_PERPAGEINDEX', 'Sayfa başına maksimum makale (Kullanıcı tarafı):');
define('_MI_PUBLISHER_PERPAGEINDEXDSC', 'Kullanıcı tarafında birlikte görüntülenecek sayfa başına maksimum makale sayısı.');
define('_MI_PUBLISHER_PRINTLOGOURL', 'Logo yazdırma URL si');
define('_MI_PUBLISHER_PRINTLOGOURLDSC', 'Sayfanın üst kısmına yazdırılacak logonun URL si.');
define('_MI_PUBLISHER_RECENTITEMS', 'Son Makaleler (Detay)');
define('_MI_PUBLISHER_SHOW_RSS', 'RSS beslemesi için bağlantıyı göster');
define('_MI_PUBLISHER_SHOW_RSSDSC', '');
define('_MI_PUBLISHER_SHOW_SUBCATS', 'Alt kategorileri görüntüle');
define('_MI_PUBLISHER_SHOW_SUBCATS_ALL', 'Tüm alt kategorileri göster');
define('_MI_PUBLISHER_SHOW_SUBCATS_DSC', 'Modülün indeks ve kategori sayfasının kategoriler listesindeki alt kategorileri görüntülemek isteyip istemediğinizi seçin.');
define('_MI_PUBLISHER_SHOW_SUBCATS_NO', 'Alt kategorileri gösterme');
define('_MI_PUBLISHER_SHOW_SUBCATS_NOMAIN', 'Alt kategorileri indeks sayfasında gösterme, sadece kategori sayfasında gösterme');
define('_MI_PUBLISHER_SHOW_SUBCATS_NOTEMPTY', 'Boş olmayan alt kategorileri göster');
define('_MI_PUBLISHER_SUB_SMNAME1', 'Makale Gönder');
define('_MI_PUBLISHER_SUBMITMSG', 'Sayfa tanıtım mesajını gönderin:');
define('_MI_PUBLISHER_SUBMITMSGDEF', '');
define('_MI_PUBLISHER_SUBMITMSGDSC', 'Modülün gönderim sayfasında görüntülenecek tanıtım mesajı.');
define('_MI_PUBLISHER_TITLE_SIZE', 'Başlık boyutu:');
define('_MI_PUBLISHER_TITLE_SIZEDSC', 'Tek öğe görüntüleme sayfasında başlığın maksimum boyutunu ayarlayın.');
define('_MI_PUBLISHER_UPLOAD', 'Kullanıcı dosya yükleme?');
define('_MI_PUBLISHER_UPLOADDSC', 'Kullanıcıların web sitenizdeki makalelere bağlı dosyaları yüklemesine izin verilsin mi?');
define('_MI_PUBLISHER_USEREALNAME', 'Kullanıcıların Gerçek Adını Kullanın');
define('_MI_PUBLISHER_USEREALNAMEDSC', 'Bir kullanıcı adını görüntülerken, gerçek adını ayarlamışsa, o kullanıcının gerçek adını kullanın..');
define('_MI_PUBLISHER_VERSION_HISTORY', 'Sürüm Geçmişi');
define('_MI_PUBLISHER_WELCOME', 'Karşılama başlığını ve mesajını görüntüleyin:');
define('_MI_PUBLISHER_WELCOMEDSC', 'Bu seçenek “Evet” olarak ayarlanırsa, modül dizin sayfası aşağıda tanımlanan Hoş Geldiniz mesajı başlığını görüntüler. Bu seçenek “Hayır” olarak ayarlanırsa Hoş Geldiniz mesajlarından hiçbiri görüntülenmez.');
define('_MI_PUBLISHER_WHOWHEN', 'Posteri ve tarihi göster?');
define('_MI_PUBLISHER_WHOWHENDSC', 'Makalede poster ve tarih bilgilerini görüntülemek için “Evet” olarak ayarlayın.');
define('_MI_PUBLISHER_PV_TEXT', 'Kısmi görünüm mesajı');
define('_MI_PUBLISHER_PV_TEXTDSC', 'Yalnızca kısmi görüntülemeye izin veren makaleler için mesaj.');
define('_MI_PUBLISHER_PV_TEXT_DEF', 'Makalenin tamamını görüntülemek için kayıt olmalısınız.');
define('_MI_PUBLISHER_SEOMODNAME', 'URL Yeniden Yazma modülü adı');
define('_MI_PUBLISHER_SEOMODNAMEDSC', 'Modül için URL Yeniden Yazma etkinse, kullanılacak modülün adı budur. Örneğin: http://yoursite.com/publisher/...');
define('_MI_PUBLISHER_ARTCOUNT', 'Makaleyi görüntüle');
define('_MI_PUBLISHER_ARTCOUNTDSC', 'Kategori özet tablosunda her kategorideki makale sayısını görüntülemek için “Evet”i seçin. Modülün şu anda yalnızca her kategorideki makaleleri saydığını ve alt kategorilerde sayılmadığını lütfen unutmayın.');
define('_MI_PUBLISHER_LATESTFILES', 'En son yüklenen dosyalar');
define('_MI_PUBLISHER_PATHSEARCH', 'Arama sonuçlarında kategori yolunu göster');
define('_MI_PUBLISHER_PATHSEARCHDSC', '');
define('_MI_PUBLISHER_DISPBREAD', 'Breadcrumb göster');
define('_MI_PUBLISHER_DISPBREADDSC', 'Breadcrumb navigasyonu, site yapısı içinde geçerli sayfanın içeriğini görüntüler..');
define('_MI_PUBLISHER_DATE_TO_DATE', 'Tarihten bugüne makaleler');
//added in publisher
define('_MI_PUBLISHER_FORM_STATUS', 'Gönderilen makale için varsayılan durumu seçin');
define('_MI_PUBLISHER_FORM_STATUS_DSC', '');
define('_MI_PUBLISHER_PUBLISHED', 'Yayına Al');
define('_MI_PUBLISHER_OFFLINE', 'Çevrimdışı');
define('_MI_PUBLISHER_SUBMITTED', 'Gönderildi');
define('_MI_PUBLISHER_REJECTED', 'Reddedildi');
define('_MI_PUBLISHER_FORM_ALLOWCOMMENTS', '“Yorumlara izin ver” set to TRUE');
define('_MI_PUBLISHER_FORM_ALLOWCOMMENTS_DSC', '');
define('_MI_PUBLISHER_FORM_DOHTML', '“HTML etiketlerini etkinleştir” set to TRUE');
define('_MI_PUBLISHER_FORM_DOHTML_DSC', '');
define('_MI_PUBLISHER_FORM_DOSMILEY', '“Gülen yüz simgelerini etkinleştir” set to TRUE');
define('_MI_PUBLISHER_FORM_DOSMILEY_DSC', '');
define('_MI_PUBLISHER_FORM_DOXCODE', '“XOOPS kodlarını etkinleştir” set to TRUE');
define('_MI_PUBLISHER_FORM_DOXCODE_DSC', '');
define('_MI_PUBLISHER_FORM_DOIMAGE', '“Resimleri etkinleştir” set to TRUE');
define('_MI_PUBLISHER_FORM_DOIMAGE_DSC', '');
define('_MI_PUBLISHER_FORM_DOBR', '“Satır sonunu etkinleştir” set to TRUE');
define('_MI_PUBLISHER_FORM_DOBR_DSC', '');
define('_MI_PUBLISHER_EDITOR', 'Varsayılan Editör türü');
define('_MI_PUBLISHER_EDITOR_DSC', 'Varsayılan olarak ne tür bir editör kullanmak istersiniz? Gönderenlerin izinler menüsünde editörleri seçmesine de izin verebilirsiniz. ');
define('_MI_PUBLISHER_EDITOR_ROWS', 'Editör satır sayısı');
define('_MI_PUBLISHER_EDITOR_ROWS_DSC', '');
define('_MI_PUBLISHER_EDITOR_COLS', 'Editör satır sayısı');
define('_MI_PUBLISHER_EDITOR_COLS_DSC', '');
define('_MI_PUBLISHER_EDITOR_WIDTH', 'Editör Genişlik');
define('_MI_PUBLISHER_EDITOR_WIDTH_DSC', '');
define('_MI_PUBLISHER_EDITOR_HEIGHT', 'Editör Yükseklik');
define('_MI_PUBLISHER_EDITOR_HEIGHT_DSC', '');
//blocks descriptions
define('_MI_PUBLISHER_ITEMSNEW_DSC', 'Yeni öğeleri gösterir');
define('_MI_PUBLISHER_RECENTITEMS_DSC', 'Son öğeleri gösterir');
define('_MI_PUBLISHER_ITEMSPOT_DSC', 'Son öğeyi gösterir');
define('_MI_PUBLISHER_ITEMSRANDOM_ITEM_DSC', 'Rastgele bir \'item\' öğesini gösterir');
define('_MI_PUBLISHER_ITEMSMENU_DSC', 'Kategorileri gösteren menü');
define('_MI_PUBLISHER_LATESTFILES_DSC', 'En son yüklenen dosyaların listesi');
define('_MI_PUBLISHER_DATE_TO_DATE_DSC', 'Seçilen bir tarihten diğerine makaleyi listele');
define('_MI_PUBLISHER_ITEMSTREE_DSC', 'Kategori ve öğe ağacını görüntüle');
//templates descriptions
define('_MI_PUBLISHER_HEADER_DSC', 'Ekran başlığı');
define('_MI_PUBLISHER_FOOTER_DSC', 'Altbilgiyi göster');
define('_MI_PUBLISHER_SINGLEITEM_DSC', 'Tek bir öğe göster');
define('_MI_PUBLISHER_CATEGORIES_TABLE_DSC', 'Diğer şablonlarda kullanılan kategori listesi tablosunu görüntüleyin');
define('_MI_PUBLISHER_DISPLAY_LIST_DSC', 'Madde işareti görüntüleme türüyle dizini ve kategoriyi görüntüle');
define('_MI_PUBLISHER_DISPLAY_SUMMARY_DSC', 'Özet görüntüleme türüyle dizin ve kategoriyi görüntüleyin');
define('_MI_PUBLISHER_DISPLAY_FULL_DSC', 'Tam ekran tipi ile ekran indeksi ve kategori');
define('_MI_PUBLISHER_DISPLAY_WFSECTION_DSC', 'Dizini ve kategoriyi WF-Bölümü benzeri bir tarzda görüntüle');
define('_MI_PUBLISHER_ITEM_DSC', 'Öğeyi görüntüle');
define('_MI_PUBLISHER_ARCHIVE_DSC', 'Makale Arşivleri');
define('_MI_PUBLISHER_SUBMIT_DSC', 'Öğe gönderme formu');
define('_MI_PUBLISHER_SINGLEITEM_BLOCK_DSC', 'Bir blokta tek bir öğe göster');
define('_MI_PUBLISHER_PRINT_DSC', 'Sayfa şablonunu yazdır');
define('_MI_PUBLISHER_RSS_DSC', 'Yayıncı RSS beslemesini görüntüle');
define('_MI_PUBLISHER_ADDFILE_DSC', 'Bir makaleye dosya ekleme formu');
define(
    '_MI_PUBLISHER_WARNING_ALPHA',
    'Bu modül, herhangi bir garanti olmaksızın olduğu gibi gelir. Bu modül ALPHA dır, yani hala aktif geliştirme aşamasındadır. Bu sürüm, <strong>sadece test amaçlı</strong> ve biz <strong>şiddetle</strong> canlı bir web sitesinde veya üretim ortamında kullanmamanızı tavsiye etmiyoruz...'
);
define('_MI_PUBLISHER_PEOPLE_DEVELOPERS', 'Geliştiriciler');
define('_MI_PUBLISHER_PEOPLE_TESTERS', 'Test kullanıcıları');
define('_MI_PUBLISHER_PEOPLE_DOCUMENTERS', 'Belgeleyiciler');
define('_MI_PUBLISHER_PEOPLE_TRANSLATERS', 'Çeviriciler');
define('_MI_PUBLISHER_PEOPLE_OTHER', 'Diğer katkıda bulunanlar');
define('_MI_PUBLISHER_URL_REWRITE', 'URL yeniden yazma yöntemi');
define('_MI_PUBLISHER_URL_REWRITE_DSC', 'htaccess i seçerseniz, koymayı unutmayın “.htaccess” kök klasörünüzün altındaki dosya');
define('_MI_PUBLISHER_URL_REWRITE_NONE', 'Hiçbiri');
define('_MI_PUBLISHER_URL_REWRITE_PATHINFO', 'Path-info');
define('_MI_PUBLISHER_URL_REWRITE_HTACCESS', 'Htaccess');
define('_MI_PUBLISHER_COLUMNS', 'Sütunlar');
define('_MI_PUBLISHER_COLUMNS_DSC', '');
define('_MI_PUBLISHER_ALLOWRATING', 'Derecelendirme özelliğine izin ver');
define('_MI_PUBLISHER_ALLOWRATING_DSC', 'İzinler sekmesinde kimlerin oy verebileceğini seçebilirsiniz');
define('_MI_PUBLISHER_ALLOWSEARCH', 'Genişletilmiş arama özelliğine izin ver');
define('_MI_PUBLISHER_ALLOWSEARCH_DSC', 'İzinler sekmesinde kimlerin arama yapabileceğini seçebilirsiniz');
define('_MI_PUBLISHER_SUB_SMNAME3', 'Arama');
define('_MI_PUBLISHER_LATEST_NEWS', 'Son Haberler');
define('_MI_PUBLISHER_LATEST_NEWS_DSC', '');
define('_MI_PUBLISHER_SEARCH', 'Arama bloğu');
define('_MI_PUBLISHER_SEARCH_DSC', 'Gelişmiş arama sayfası');
define('_MI_PUBLISHER_CATEGORY_ITEMS_SEL', 'Kategoride Makaleler seç');
define('_MI_PUBLISHER_CATEGORY_ITEMS_SEL_DSC', 'Kategoriye göre gruplandırılmış öğeleri içeren bir açılır seçim kutusu gösterir');
define('_MI_PUBLISHER_SEO_METAKEYWORDS', 'Anahtar Kelimeler');
define('_MI_PUBLISHER_SEO_METAKEYWORDS_DSC', 'Bu anahtar kelimeler, makaleler tarafından belirlenen anahtar kelimelerle birleştirilecektir. Kullanma yöntemi \', \' işaretleriyle ayırın.');
define('_MI_PUBLISHER_SUB_ARCHIVE', 'Arşiv');
define('_MI_PUBLISHER_ALLOW_AUTHOR_ITEMS', 'Yazarın diğer makaleleri özelliğine izin ver');
define('_MI_PUBLISHER_ALLOW_AUTHOR_ITEMS_DSC', '');
define('_MI_PUBLISHER_AUTHOR_ITEMS_DSC', 'Aynı yazara ait makaleleri göster');
define('_MI_PUBLISHER_DISP_BLOCK_SUM', 'Makaleler sayfasında blok özetini görüntüle?');
define('_MI_PUBLISHER_DISP_BLOCK_SUM_DSC', '');
define('_MI_PUBLISHER_ADMENU0', 'Anasayfa');
define('_MI_PUBLISHER_DISP_INDEX_SUB', 'Makale alt başlıkları dizin sayfasında gösterilsin mi?');
define('_MI_PUBLISHER_DISP_INDEX_SUB_DSC', '');
define('_MI_PUBLISHER_DISP_CAT_SUB', 'Kategori sayfalarında makale alt başlıkları gösterilsin mi?');
define('_MI_PUBLISHER_DISP_CAT_SUB_DSC', '');
define('_MI_PUBLISHER_DISP_ITEM_SUB', 'Öğe sayfasında makale alt başlığı gösterilsin mi?');
define('_MI_PUBLISHER_DISP_ITEM_SUB_DSC', '');
//30/04/2012
define('_MI_PUBLISHER_ALLOWEDIT', 'Kullanıcı kendi makalesini düzenleme yetkisi?');
define('_MI_PUBLISHER_ALLOWEDITDSC', 'Kullanıcıların kendi makalelerini düzenlemesine izin verilsin mi?');
define('_MI_PUBLISHER_ALLOWDELETE', 'Kullanıcı makalesi silme?');
define('_MI_PUBLISHER_ALLOWDELETEDSC', 'Kullanıcıların kendi makalelerini silmelerine izin verilsin mi?');

//1.02 Beta 2
define('_MI_PUBLISHER_DISPLAY_PDF', 'PDF Simgesini Görüntüle');
define('_MI_PUBLISHER_DISPLAY_PDF_DSC', 'PDF simgesini göstermek ve kullanıcıların PDF dosyaları oluşturmasına izin vermek için Evet i seçin <br>TCPDF kitaplığının kurulu olduğundan emin olun. lütfen okuyun "readme.txt" file in /nasıl edinileceği hakkında bilgi için docs klasörü.');

//1.02 RC2
define('_MI_PUBLISHER_ORDERBY_RATING', 'Derecelendirme DESC');
define('_MI_PUBLISHER_ORDERBY_VOTES', 'Oylar DESC');
define('_MI_PUBLISHER_ORDERBY_COMMENTS', 'Yorumlar DESC');
define('_MI_PUBLISHER_ORDERBY_HITS', 'Hit DESC');

// The name of this module
define('_MI_PUBLISHER_NAME', 'Yayımcı');
define('_MI_PUBLISHER_DIRNAME', basename(dirname(__DIR__, 2)));
define('_MI_PUBLISHER_HELP_HEADER', __DIR__ . '/help/helpheader.tpl');
define('_MI_PUBLISHER_BACK_2_ADMIN', 'Yönetimine Geri Dön ');

//help
define('_MI_PUBLISHER_HELP_OVERVIEW', 'Genel bakış');

//help multi-page
define('_MI_PUBLISHER_DISCLAIMER', 'Sorumluluk reddi');
define('_MI_PUBLISHER_LICENSE', 'Lisans');
define('_MI_PUBLISHER_SUPPORT', 'Destek');

define('_MI_PUBLISHER_IMPORT', 'İçe aktar');
define('_MI_PUBLISHER_ABOUT', 'Hakkında');
define('_MI_PUBLISHER_MENU_CLONE', 'Modül Klonlama');

define('_MI_PUBLISHER_SHOW_SAMPLE_BUTTON', 'Örnek Veri Butonları Düğmesini Göster?');
define('_MI_PUBLISHER_SHOW_SAMPLE_BUTTON_DESC', 'Evet ise, "Örnek Veri Ekle" düğmesi Yönetici tarafından görülecektir. İlk kurulum için varsayılan olarak Evet tir.');

define('_MI_PUBLISHER_MENU_HISTORY', 'Tarih');

//Categories:
define('_MI_PUBLISHER_CONF_GROUP_SEO', 'SEO');
define('_MI_PUBLISHER_CONF_GROUP_SEO_DSC', 'Yeniden yazma yöntemleri, meta veriler vb. için tercihler');
define('_MI_PUBLISHER_CONF_GROUP_INDEXCAT', 'Dizin ve kategori sayfaları');
define('_MI_PUBLISHER_CONF_GROUP_INDEXCAT_DSC', '');
define('_MI_PUBLISHER_CONF_GROUP_CATEGORY', 'Kategori sayfası');
define('_MI_PUBLISHER_CONF_GROUP_CATEGORY_DSC', '');
define('_MI_PUBLISHER_CONF_GROUP_ITEM', 'Makale Sayfası');
define('_MI_PUBLISHER_CONF_GROUP_ITEM_DSC', '');
define('_MI_PUBLISHER_CONF_GROUP_FORMAT', 'Format');
define('_MI_PUBLISHER_CONF_GROUP_FORMAT_DSC', '');
define('_MI_PUBLISHER_CONF_GROUP_PRINT', 'Sayfayı yazdır');
define('_MI_PUBLISHER_CONF_GROUP_PRINT_DSC', '');
define('_MI_PUBLISHER_CONF_GROUP_OTHERS', 'Diğerleri');
define('_MI_PUBLISHER_CONF_GROUP_OTHERS_DSC', '');
define('_MI_PUBLISHER_CONF_GROUP_PERMISSIONS', 'İzinler');
define('_MI_PUBLISHER_CONF_GROUP_PERMISSIONS_DSC', '');

define('_MI_PUBLISHER_CONF_GROUP_INDEX', 'Ana Sayfa');
define('_MI_PUBLISHER_CONF_GROUP_INDEX_DSC', '');
define('_MI_PUBLISHER_CONF_GROUP_SUBMIT', 'Makale Gönder');
define('_MI_PUBLISHER_CONF_GROUP_SUBMIT_DSC', 'Makale düzenini gönderin ve varsayılan değerler oluşturun');
define('_MI_PUBLISHER_CONF_GROUP_SEARCH', 'Arama sayfası');
define('_MI_PUBLISHER_CONF_GROUP_SEARCH_DSC', '');

define('_MI_PUBLISHER_CONF_GROUP_RATING_VOTING', 'Derecelendirme/Oylama');
define('_MI_PUBLISHER_CONF_GROUP_RATING_VOTING_DSC', 'Makaleler için tercih edilen Derecelendirme/Oylama türünü ayarlayın');

define('_MI_PUBLISHER_ADMENU5', 'Blok Yöneticisi');

// 2019-05-31 Goffy
define('_MI_PUBLISHER_IMGCAT_ALL', 'Tüm Kategoriler');
define('_MI_PUBLISHER_IMGCAT', 'Resim kategorileri');
define('_MI_PUBLISHER_IMGCAT_DSC', 'Lütfen makalelerinize resim eklemek için XOOPS Resim Yöneticisin den hangi kategorilerin kullanılması gerektiğini seçin.');

//Config Categories Styling:
define('_MI_PUBLISHER_CONFIG_STYLING_START', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;"> :: ');
define('_MI_PUBLISHER_CONFIG_STYLING_END', ' ::</span> ');

define('_MI_PUBLISHER_CONFIG_STYLING_DESC_START', '<span style="color: #FF0000; font-size: Small;">');
define('_MI_PUBLISHER_CONFIG_STYLING_DESC_END', '</span> ');

//Styled Group Headings in Preferences
define('_MI_PUBLISHER_CONFCAT_SEO', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_SEO . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_SEO_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_SEO_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_INDEXCAT', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_INDEXCAT . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_INDEXCAT_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_INDEXCAT_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_CATEGORY', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_CATEGORY . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_CATEGORY_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_CATEGORY_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_ITEM', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_ITEM . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_ITEM_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_ITEM_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_FORMAT', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_FORMAT . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_FORMAT_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_FORMAT_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_PRINT', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_PRINT . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_PRINT_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_PRINT_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_OTHERS', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_OTHERS . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_OTHERS_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_OTHERS_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_PERMISSIONS', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_PERMISSIONS . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_PERMISSIONS_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_PERMISSIONS_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);

define('_MI_PUBLISHER_CONFCAT_INDEX', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_INDEX . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_INDEX_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_INDEX_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_SUBMIT', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_SUBMIT . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_SUBMIT_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_SUBMIT_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_SEARCH', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_SEARCH . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_CONFCAT_SEARCH_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_SEARCH_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);
//Rating/Voting
define('_MI_PUBLISHER_RATING_VOTING', _MI_PUBLISHER_CONFIG_STYLING_START . _MI_PUBLISHER_CONF_GROUP_RATING_VOTING . _MI_PUBLISHER_CONFIG_STYLING_END);
define('_MI_PUBLISHER_RATING_VOTING_DSC', _MI_PUBLISHER_CONFIG_STYLING_DESC_START . _MI_PUBLISHER_CONF_GROUP_RATING_VOTING_DSC . _MI_PUBLISHER_CONFIG_STYLING_END);

// Lio-MJ
define('_MI_PUBLISHER_WHO', 'Posteri göster?');
define('_MI_PUBLISHER_WHODSC', 'Bireysel makaledeki poster bilgilerini görüntülemek için “Evet” olarak ayarlayın.');
define('_MI_PUBLISHER_WHEN', 'Tarih gösterilsin mi?');
define('_MI_PUBLISHER_WHENDSC', 'Ayrı makaledeki tarih bilgilerini görüntülemek için “Evet” olarak ayarlayın.');
define('_MI_PUBLISHER_HITS', 'Hit leri Göster?');
define('_MI_PUBLISHER_HITSDSC', 'Tek makaledeki isabet bilgilerini görüntülemek için “Evet” olarak ayarlayın.');
define('_MI_PUBLISHER_PRINT', 'Yazdır Düğmesi Görüntülensin mi?');
define('_MI_PUBLISHER_PRINTDSC', 'Tek makaledeki yazdır düğmesi bilgilerini görüntülemek için “Evet” olarak ayarlayın.');
define('_MI_PUBLISHER_ITEMCATEGORY', 'Makalenin kategorisi gösterilsin mi?');
define('_MI_PUBLISHER_ITEMCATEGORYDSC', 'Ayrı makaledeki kategori bilgilerini görüntülemek için “Evet” olarak ayarlayın.');
define('_MI_PUBLISHER_MAINIMAGE', 'Ana Resmi Görüntüle?');
define('_MI_PUBLISHER_MAINIMAGEDSC', 'Ana Resmi indeks ve kategori sayfasındaki öğeler tablosunda görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_DEFAULTIMAGE', 'Hiçbir resim seçilmediğinde varsayılan resmi göster');
define('_MI_PUBLISHER_DEFAULTIMAGEDSC', 'Hiçbir resim seçilmediğinde makale sayfasında Varsayılan Resmi görüntülemek için “Evet”i seçin.');

define('_MI_PUBLISHER_SUMMARY', 'Makale Özetini Görüntüle');
define('_MI_PUBLISHER_SUMMARYDSC', 'Makale Özetini dizin ve kategori sayfasında görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_READMORE', 'Tüm Makaleyi Oku Bağlantısını Görüntüle');
define('_MI_PUBLISHER_READMOREDSC', 'Dizin ve kategori sayfasında Tam Makaleyi Oku Bağlantısını görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_ARTICLECATEGORY', 'Makalenin kategorisi gösterilsin mi?');
define('_MI_PUBLISHER_ARTICLECATEGORYDSC', 'Makalenin kategorisini dizin ve kategori sayfasında görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_POSTER', 'Posteri Görüntüle');
define('_MI_PUBLISHER_POSTERDSC', 'Makalenin afişini dizin ve kategori sayfasında görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_COMMENTLINK', 'Yorum sayısı gösterilsin mi?');
define('_MI_PUBLISHER_COMMENTLINKDSC', 'İndeks ve kategori sayfasında yorum sayısını görüntülemek için “Evet”i seçin.');

define('_MI_PUBLISHER_EMAILLINK', 'E-posta Bağlantısını Görüntüle');
define('_MI_PUBLISHER_CONFCAT_INDEXCATTEMPLATE', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">---Dizin ve Kategori Sayfasında En Son Yayınlanan Makaleler ---</span> ');
define('_MI_PUBLISHER_CONFCAT_INDEXCATTEMPLATEDSC', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">--- ---</span> ');
define('_MI_PUBLISHER_ITEM_ALLARTICLE', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">---Makale Sayfasında Tüm Son Yayınlanan Makaleler ---</span> ');
define('_MI_PUBLISHER_ITEM_ALLARTICLEDSC', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">--- ---</span> ');
define('_MI_PUBLISHER_ITEM_DISDATECOLDSC', 'Makale sayfasında en son yayınlanan öğelerde tarihi görüntülemek için "Evet"i seçin.');
define('_MI_PUBLISHER_ITEM_HITSCOLDSC', 'Makale sayfasında en son yayınlanan öğelerde "İsabetler" sütununu görüntülemek için "Evet"i seçin.');
define('_MI_PUBLISHER_ITEM_MAINIMAGEDSC', 'Makale sayfasında en son yayınlanan öğelerde Ana Resmi görüntülemek için "Evet"i seçin.');
define('_MI_PUBLISHER_ITEM_SUMMARYDSC', 'Makale sayfasında en son yayınlanan öğelerde Makale Özetini görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_ITEM_READMOREDSC', 'Makale sayfasındaki en son yayınlanan öğelerde Tam Makaleyi Oku Bağlantısını görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_ITEM_ARTICLECATEGORYDSC', 'Makale sayfasındaki en son yayınlanan öğelerde makalenin kategorisini görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_ITEM_POSTERDSC', 'Makale sayfasındaki en son yayınlanan öğelerde makalenin posterini görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_ITEM_COMMENTLINKDSC', 'Makale sayfasında en son yayınlanan öğelerdeki yorum sayısını görüntülemek için "Evet"i seçin.');

define('_MI_PUBLISHER_CONFCAT_ARCHIVE', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">---Arşiv Sayfası ---<span> ');
define('_MI_PUBLISHER_CONFCAT_ARCHIVEDSC', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">--- ---</span> ');
define('_MI_PUBLISHER_ARCHIVE_EMAILLINKDSC', 'Bağlantıyı arşiv sayfasında görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_ARCHIVE_DISDATECOLDSC', 'Arşiv sayfasında tarihi görüntülemek için “Evet”i seçin');
define('_MI_PUBLISHER_ARCHIVE_HITSCOLDSC', 'Arşiv sayfasındaki "İsabetler" sütununu görüntülemek için "Evet"i seçin');
define('_MI_PUBLISHER_ARCHIVE_ARTICLECATEGORYDSC', 'Makalenin kategorisini arşiv sayfasında görüntülemek için “Evet”i seçin');
define('_MI_PUBLISHER_ARCHIVE_POSTERDSC', 'Makalenin posterini arşiv sayfasında görüntülemek için “Evet”i seçin');
define('_MI_PUBLISHER_ARCHIVE_COMMENTDSC', 'Arşiv sayfasında yorum sayısını görüntülemek için “Evet”i seçin');
define('_MI_PUBLISHER_ARCHIVE_PRINTLINKDSC', 'Arşiv sayfasında yazdır düğmesini görüntülemek için “Evet”i seçin');
define('_MI_PUBLISHER_ARCHIVE_PDFLINKDSC', 'Arşiv sayfasında pdf simgesini görüntülemek için “Evet”i seçin<br>TCPDF kitaplığının kurulu olduğundan emin olun. lütfen okuyun "readme.txt" file in /nasıl edinileceği hakkında bilgi için docs klasörü.');
define('_MI_PUBLISHER_ARCHIVE_SUMMARYDSC', 'Arşiv sayfasında makale özetini görüntülemek için “Evet”i seçin');
define('_MI_PUBLISHER_ARCHIVE_MAINIMAGEDSC', 'Makale ana görüntüsünü arşiv sayfasında görüntülemek için “Evet”i seçin');

define('_MI_PUBLISHER_CONFCAT_AUTHORPAGE', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">---Aynı Yazar Sayfasına Göre Öğe ---<span> ');
define('_MI_PUBLISHER_CONFCAT_AUTHORPAGEDSC', '<span style="color: #FF0000; font-size: Small;  font-weight: bold;">--- ---</span> ');
define('_MI_PUBLISHER_AUTHORPAGE_HITSDSC', 'Aynı Yazara Göre Öğe sayfasında "İsabetler"i görüntülemek için "Evet"i seçin');
define('_MI_PUBLISHER_AUTHORPAGE_IMAGEDSC', 'Makalenin ana resmini Aynı Yazara Göre Öğe sayfasında görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_AUTHORPAGE_COMMENTDSC', 'Aynı Yazara Göre Öğe sayfasındaki yorum sayısını görüntülemek için “Evet”i seçin.');
define('_MI_PUBLISHER_AUTHORPAGE_SUMMARYDSC', 'Makale özetini Aynı Yazara Göre Öğe sayfasında görüntülemek için "Evet"i seçin');
define('_MI_PUBLISHER_DISPRATING', 'Derecelendirmeyi Görüntüle');
define('_MI_PUBLISHER_AUTHORPAGE_RATINGDSC', 'Aynı Yazara Göre Öğe sayfasında derecelendirmeyi görüntülemek için "Evet"i seçin');

define('_MI_PUBLISHER_ADMENU7', 'Trello');
define('_MI_PUBLISHER_TRELLO_DSC', 'Trello Yönetimi');

// Rating bars
\define('_MI_PUBLISHER_RATINGBAR_GROUPS', 'Derecelendirme haklarına sahip gruplar');
\define('_MI_PUBLISHER_RATINGBAR_GROUPS_DESC', 'Derecelendirme hakkına sahip olması gereken grupları seçin');
\define('_MI_PUBLISHER_RATINGBARS', 'Derecelendirme/oylama türünü seçin');
\define('_MI_PUBLISHER_RATINGBARS_DESC', 'Derecelendirmenin mümkün olup olmayacağını ve hangi derecelendirme türünün kullanılması gerektiğini tanımlayın');
\define('_MI_PUBLISHER_RATING_NONE', 'Derecelendirmeyi kullanma');
\define('_MI_PUBLISHER_RATING_5STARS', '5 yıldız ile derecelendirme');
\define('_MI_PUBLISHER_RATING_10STARS', '10 yıldızla derecelendirme');
\define('_MI_PUBLISHER_RATING_LIKES', 'Beğenenler ve beğenmeyenler ile derecelendirme');
\define('_MI_PUBLISHER_RATING_10NUM', '10 puanla derecelendirme');
\define('_MI_PUBLISHER_RATING_REACTION', 'Tepkilerle Derecelendirme');

// Config
\define('_MI_PUBLISHER_EDITOR_ADMIN', 'Editör yöneticisi');
\define('_MI_PUBLISHER_EDITOR_ADMIN_DESC', 'Metin alanı alanları için yönetici alanında kullanılması gereken düzenleyiciyi seçin');
\define('_MI_PUBLISHER_EDITOR_USER', 'Kullanıcı Editörü');
\define('_MI_PUBLISHER_EDITOR_USER_DESC', 'Metin alanı alanları için kullanıcı alanında kullanılması gereken düzenleyiciyi seçin');
\define('_MI_PUBLISHER_EDITOR_MAXCHAR', 'Metin maksimum karakter');
\define('_MI_PUBLISHER_EDITOR_MAXCHAR_DESC', 'Yönetici alanında bir metin alanının veya düzenleyici alanının metnini göstermek için maksimum karakter');
\define('_MI_PUBLISHER_KEYWORDS', 'Anahtar kelimeler');
\define('_MI_PUBLISHER_KEYWORDS_DESC', 'Anahtar kelimeleri buraya ekleyin (virgülle ayırın)');
\define('_MI_PUBLISHER_SIZE_MB', 'MB');
\define('_MI_PUBLISHER_MAXSIZE_IMAGE', 'Maksimum Resim Boyutu');
\define('_MI_PUBLISHER_MAXSIZE_IMAGE_DESC', 'Görüntüleri yüklemek için maksimum boyutu tanımlayın');
\define('_MI_PUBLISHER_MIMETYPES_IMAGE', 'MIME türleri resmi');
\define('_MI_PUBLISHER_MIMETYPES_IMAGE_DESC', 'Görüntüleri yüklemek için izin verilen mime türlerini tanımlayın');
\define('_MI_PUBLISHER_MAXWIDTH_IMAGE', 'Maksimum Resim Genişliği');
\define('_MI_PUBLISHER_MAXWIDTH_IMAGE_DESC', 'Yüklenen resimlerin ölçeklendirileceği maksimum genişliği ayarlayın (in pixel)<br>0 anlamına geliyor, bu görüntüler orijinal boyutunu korur. <br>Bir görüntü maksimum değerden küçükse, görüntü büyütülmez, orijinal genişliğinde kaydedilir.');
\define('_MI_PUBLISHER_MAXHEIGHT_IMAGE', 'Maksimum Resim Yüksekliği');
\define('_MI_PUBLISHER_MAXHEIGHT_IMAGE_DESC', 'Yüklenen resimlerin ölçeklendirileceği maksimum yüksekliği ayarlayın (in pixel)<br>0 anlamına geliyor, bu görüntüler orijinal boyutunu korur. <br>Bir görüntü maksimum değerden küçükse, görüntü büyütülmez, orijinal yüksekliğinde kaydedilir');
\define('_MI_PUBLISHER_USE_TAG', 'ETİKET KULLAN');
\define('_MI_PUBLISHER_USE_TAG_DESC', 'Etiket modülü kullanıyorsanız, evet için bu seçeneği işaretleyin.');
\define('_MI_PUBLISHER_NUMB_COL', 'Sayı Sütunları');
\define('_MI_PUBLISHER_NUMB_COL_DESC', 'Görüntülenecek Sütun Sayısı.');
\define('_MI_PUBLISHER_DIVIDEBY', 'Bölünür');
\define('_MI_PUBLISHER_DIVIDEBY_DESC', 'Sütun sayısına göre bölme.');
\define('_MI_PUBLISHER_TABLE_TYPE', 'Tablo Tipi');
\define('_MI_PUBLISHER_TABLE_TYPE_DESC', 'Tablo Türü, önyükleme html tablosudur.');
\define('_MI_PUBLISHER_PANEL_TYPE', 'Panel Tipi');
\define('_MI_PUBLISHER_PANEL_TYPE_DESC', 'Panel Türü, önyükleme html div idir.');
\define('_MI_PUBLISHER_IDPAYPAL', 'Paypal ID');
\define('_MI_PUBLISHER_IDPAYPAL_DESC', 'Bağışlar için PayPal Kimliğinizi buraya girin.');
\define('_MI_PUBLISHER_ADVERTISE', 'Reklam Kodu');
\define('_MI_PUBLISHER_ADVERTISE_DESC', 'Buraya reklam kodunu girin');
\define('_MI_PUBLISHER_MAINTAINEDBY', 'Bakımı Yapan');
\define('_MI_PUBLISHER_MAINTAINEDBY_DESC', 'Destek sitesi veya topluluğunun URL sine izin ver');
\define('_MI_PUBLISHER_BOOKMARKS', 'Sosyal Yer İmleri');
\define('_MI_PUBLISHER_BOOKMARKS_DESC', 'Sosyal Yer İmlerini tek sayfada göster');
\define('_MI_PUBLISHER_FACEBOOK_COMMENTS', 'Facebook yorumları');
\define('_MI_PUBLISHER_FACEBOOK_COMMENTS_DESC', 'Tek sayfada Facebook yorumlarına izin ver');
\define('_MI_PUBLISHER_DISQUS_COMMENTS', 'Disqus yorumları');
\define('_MI_PUBLISHER_DISQUS_COMMENTS_DESC', 'Tek sayfada Disqus yorumlarına izin ver');

//VOTING
\define('_MI_PUBLISHER_ALLOW_REPEAT_RATING', 'Tekrar derecelendirmesine izin ver');
\define('_MI_PUBLISHER_ALLOW_REPEAT_RATING_DSC', 'Bir kullanıcı defalarca mı yoksa yalnızca bir kez mi oy vermelidir?');
