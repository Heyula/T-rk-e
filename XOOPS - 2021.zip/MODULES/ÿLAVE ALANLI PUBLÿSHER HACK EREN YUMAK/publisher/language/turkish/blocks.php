<?php

declare(strict_types=1);
/**
 * Module: Publisher
 * Author: The SmartFactory <www.smartfactory.ca>
 * Licence: GNU
 */

// Blocks
define('_MB_PUBLISHER_ALLCAT', 'Tüm Kategoriler');
define('_MB_PUBLISHER_AUTO_LAST_ITEMS', 'Son öğeleri otomatik olarak göster?');
define('_MB_PUBLISHER_CATEGORY', 'Kategori');
define('_MB_PUBLISHER_CHARS', 'Başlığın uzunluğu');
define('_MB_PUBLISHER_COMMENTS', 'Yorum(lar)');
define('_MB_PUBLISHER_DATE', 'Yayınlanma tarihi');
define('_MB_PUBLISHER_FIRST', 'Önce Hariç Tut');
define('_MB_PUBLISHER_DISP', 'Görüntüle');
define('_MB_PUBLISHER_DISPLAY_COMMENTS', 'Yorum sayısı gösterilsin mi?');
define('_MB_PUBLISHER_DISPLAY_TYPE', 'Ekran tipi:');
define('_MB_PUBLISHER_DISPLAY_TYPE_BLOCK', 'İçerik sağa hizalı');
define('_MB_PUBLISHER_DISPLAY_TYPE_BULLET', 'İçerik sola hizalı');
define('_MB_PUBLISHER_DISPLAY_WHO_AND_WHEN', 'Poster ve tarih gösterilsin mi?');
define('_MB_PUBLISHER_FULLITEM', 'Devamını Okuyun');
define('_MB_PUBLISHER_HITS', 'Okunma sayısınına göre');
define('_MB_PUBLISHER_ITEMS', 'Makaleler');
define('_MB_PUBLISHER_LAST_ITEMS_COUNT', '“Evet” ise, kaç öğe gösterilecek?');
define('_MB_PUBLISHER_ORDER', 'Görüntüleme sırası');
define('_MB_PUBLISHER_ORDER_SHOW', 'Blokta sırayı göster');
define('_MB_PUBLISHER_POSTEDBY', 'Tarafından by');
define('_MB_PUBLISHER_READMORE', 'Devamını Oku...');
define('_MB_PUBLISHER_READS', 'Okunma');
define('_MB_PUBLISHER_SELECT_ITEMS', '“Hayır” ise, görüntülenecek makaleleri seçin:');
define('_MB_PUBLISHER_SELECTCAT', 'Görüntülenecek kategoriyi seçin:');
define('_MB_PUBLISHER_VISITITEM', 'Ziyaret edin');
define('_MB_PUBLISHER_WEIGHT', 'Ağırlığa göre listele');
define('_MB_PUBLISHER_WHO_WHEN', 'Tarafından yayınlandı %s üzerinde %s');
//bd tree block hack
define('_MB_PUBLISHER_LEVELS', 'Seviyeler');
define('_MB_PUBLISHER_CURRENTCATEGORY', 'Mevcut Kategori');
define('_MB_PUBLISHER_ASC', 'ASC');
define('_MB_PUBLISHER_DESC', 'DESC');
define('_MB_PUBLISHER_SHOWITEMS', 'Öğeleri Göster');
//--/bd
define('_MB_PUBLISHER_FILES', 'Dosyalar');
define('_MB_PUBLISHER_DIRECTDOWNLOAD', 'Makaleye bir bağlantı yerine dosyayı indirmek için doğrudan bağlantı?');
define('_MB_PUBLISHER_FROM', 'Makaleleri seçin <br>itibaren ');
define('_MB_PUBLISHER_UNTIL', '&nbsp;&nbsp;ile');
define('_MB_PUBLISHER_DATE_FORMAT', 'Tarih biçimi olmalıdır mm/dd/yyy');
define('_MB_PUBLISHER_ARTICLES_FROM_TO', 'arasında yayınlanan makaleler  %s  ve  %s ');
define('_MB_PUBLISHER_TRUNCATE', 'Verilen değerle özet metni kısalt (0 bu özelliği devre dışı bırakır) :');
define('_MB_PUBLISHER_DISPLAY_CATIMAGE', 'Kategori resmi görüntülensin mi (bir kategori seçiliyse)?');
define('_MB_PUBLISHER_MORE', 'Daha:');
define('_MB_PUBLISHER_NUMBER_COLUMN_VIEW', 'Gösterilecek sütun sayısı');
define('_MB_PUBLISHER_NUMBER_ITEMS_CAT', 'Her kategorideki öğe sayısı');
define('_MB_PUBLISHER_IMAGE_TO_DISPLAY', 'Görüntülemek için bir resim seçin');
define('_MB_PUBLISHER_IMAGE_ARTICLE', 'Makale resmi');
define('_MB_PUBLISHER_IMAGE_CATEGORY', 'Kategori resmi');
define('_MB_PUBLISHER_IMAGE_AVATAR', 'Kullanıcı avatarı');
//latest news  block
define('_MB_PUBLISHER_SP', ' : ');
define('_MB_PUBLISHER_NO_COMMENTS', 'Yorum yok');
define('_MB_PUBLISHER_MORE_ITEMS', 'Diğer Makaleler');
define('_MB_PUBLISHER_POSTER', 'Tarafından gönderildi ');
define('_MB_PUBLISHER_COLUMNS', 'Sütun sayısı');
define('_MB_PUBLISHER_COLUMN', 'Sütun');
define('_MB_PUBLISHER_TEXTLENGTH', 'Harf Sayısı');
define('_MB_PUBLISHER_LETTER', 'Harf');
define('_MB_PUBLISHER_IMGWIDTH', 'Resim Genişliği');
define('_MB_PUBLISHER_IMGHEIGHT', 'Resim Yüksekliği');
define('_MB_PUBLISHER_PIXEL', 'pixel');
define('_MB_PUBLISHER_BORDER', 'Resim Kenarlığı Boyutu');
define('_MB_PUBLISHER_BORDERCOLOR', 'Görüntü Kenarlığı Rengi');
define('_MB_PUBLISHER_IMGPOSITION', 'Resim kounumu');
define('_MB_PUBLISHER_DISPLAY_MORELINK', 'Görüntüle \'Daha Fazla Makale\'?');
define('_MB_PUBLISHER_DISPLAY_TOPICLINK', 'Görüntüle \'Konular\'?');
define('_MB_PUBLISHER_DISPLAY_ARCHIVELINK', 'Görüntüle \'Arşivler\'?');
define('_MB_PUBLISHER_DISPLAY_SUBMITLINK', 'Görüntüle \'Gönderen\'?');
define('_MB_PUBLISHER_DISPLAY_POSTEDBY', 'Görüntüle \'Tarafından By\'?');
define('_MB_PUBLISHER_DISPLAY_POSTTIME', 'Görüntüle \'Tarih\'?');
define('_MB_PUBLISHER_DISPLAY_COMMENT', 'Görüntüle \'Yorum(lar)\'?');
define('_MB_PUBLISHER_DISPLAY_TOPICTITLE', 'Görüntüle \'Makale Başlığı\'?');
define('_MB_PUBLISHER_DISPLAY_READ', 'Görüntüle \'Okunma Sayısı\'?');
define('_MB_PUBLISHER_DISPLAY_PRINT', 'Görüntüle yazıcı ikonu?');
define('_MB_PUBLISHER_DISPLAY_PDF', 'Görüntüle pdf ikonu?');
define('_MB_PUBLISHER_DISPLAY_EMAIL', 'Görüntüle email ikonu?');
define('_MB_PUBLISHER_TOPICSDISPLAY', 'Konuları Görüntüle');
define('_MB_PUBLISHER_SCROLL', 'Kayan haber özelliğini etkinleştir');
define('_MB_PUBLISHER_SCROLLHEIGHT', 'Kaydırma Yüksekliği');
define('_MB_PUBLISHER_SCROLLSPEED', 'Kaydırma hızı');
define('_MB_PUBLISHER_SCROLLDIR', 'Kaydırma Yönü');
define('_MB_PUBLISHER_SCROLL_RIGHT', 'Sağ');
define('_MB_PUBLISHER_SCROLL_LEFT', 'Sol');
define('_MB_PUBLISHER_SCROLL_UP', 'Yukarı');
define('_MB_PUBLISHER_SCROLL_DOWN', 'Aşağı');
define('_MB_PUBLISHER_SELECTEDSTORIES', 'Makale kimliklerini ayarlayın (ör.: 3,8,23,46) not: tümünü göstermek için 0 olarak ayarlayın');
define('_MB_PUBLISHER_IMGDISPLAY', 'Makale Resmini Göster');
define('_MB_PUBLISHER_GENERALCONFIG', '<strong>Genel seçenekler</strong>');
define('_MB_PUBLISHER_PHOTOSCONFIG', '<strong>Görüntü Seçenekleri</strong>');
define('_MB_PUBLISHER_LINKSCONFIG', '<strong>Bağlantı Seçenekleri</strong>');
define('_MB_PUBLISHER_TOPICSCONFIG', '<strong>Konu Seçenekleri</strong>');
define('_MB_PUBLISHER_TEMPLATESCONFIG', '<strong>Şablon Seçenekleri</strong>');
define('_MB_PUBLISHER_SUBMITNEWS', 'Makale gönder');
define('_MB_PUBLISHER_TEMPLATE', 'Şablon');
define('_MB_PUBLISHER_TEMPLATE_NORMAL', 'Normal');
define('_MB_PUBLISHER_TEMPLATE_EXTENDED', 'Genişletilmiş');
define('_MB_PUBLISHER_TEMPLATE_TICKER', 'Ticker');
define('_MB_PUBLISHER_TEMPLATE_SLIDER1', 'Fade-in Slider');
define('_MB_PUBLISHER_TEMPLATE_SLIDER2', 'Tabbed Slider');
define('_MB_PUBLISHER_ARCHIVE', 'Arşiv');
//25-11-2012
define('_MB_PUBLISHER_ONECOMMENT', '1 yorum');
//Lio-MJ
define('_MB_PUBLISHER_DISPLAY_READ_FULLITEM', 'Görüntüle \'Makalenin Tamamını Oku\'?');
define('_MB_PUBLISHER_DISPLAY_ADMINLINK', 'Görüntüle \'Administrator İkonu\'?');
define('_MB_PUBLISHER_DISPLAY_SUMMARY', 'Görüntüle \'Makale özeti\'?');
define('_MB_PUBLISHER_DISPLAY_RATING', 'Görüntüle \'Makale Değerlendirmesi\'?');
define('_MB_PUBLISHER_DISPLAY_DATE_MAINITEM', 'Görüntüle Ana Öğedeki Tarih?');
define('_MB_PUBLISHER_DISPLAY_DATE_SUBITEM', 'Görüntüle Alt Öğedeki Tarih?');
define('_MB_PUBLISHER_ON', 'on');
define('_MB_PUBLISHER_TOTALHITS', 'hit');
