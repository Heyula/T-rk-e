<?php

declare(strict_types=1);

/**
 * Module: Publisher
 * Author: The SmartFactory <www.smartfactory.ca>
 * Licence: GNU
 */
define('_MD_PUBLISHER_ADD_FILE_INTRO', "Bu makaleye dosya eklemek için lütfen bu formu doldurun: '%s'.");
define('_MD_PUBLISHER_ADD_FILE_TITLE', 'Bir makaleye dosya ekleme');
define('_MD_PUBLISHER_ADMIN_PAGE', ':: Yönetim Bölümü ::');
define('_MD_PUBLISHER_MODIFY', 'Değiştir');
define('_MD_PUBLISHER_CANCEL', 'İptal et');
define('_MD_PUBLISHER_CATEGORY_EDIT', 'Kategoriyi düzenle');
define('_MD_PUBLISHER_CATEGORY_SUMMARY', 'Özet %s');
define('_MD_PUBLISHER_CATEGORY_SUMMARY_INFO', 'içindeki alt kategoriler %s.');
define('_MD_PUBLISHER_CLEAR', 'Temizle');
define('_MD_PUBLISHER_COMMENTS', 'Yorum(lar)');
//define('_MD_PUBLISHER_CREATE','Create article');
define('_MD_PUBLISHER_DATE', 'Tarih');
define('_MD_PUBLISHER_DATESUB', 'Yayınlandı');
define('_MD_PUBLISHER_DESCRIPTION', 'Açıklama');
define('_MD_PUBLISHER_DOWNLOAD_FILE', 'Bu dosyayı indir');
define('_MD_PUBLISHER_EDIT_ARTICLE', 'Bir makaleyi düzenleyin');
define('_MD_PUBLISHER_EMPTY', 'Bu kategorinin şu anda hiçbir makalesi veya alt kategorisi yok');
define('_MD_PUBLISHER_GOODDAY', 'Merhaba <strong>%s</strong>! ');
define('_MD_PUBLISHER_HITS', 'Hits');
define('_MD_PUBLISHER_HITSDETAIL', 'Bu makale okundu');
define('_MD_PUBLISHER_HOME', 'Anasayfa');
define('_MD_PUBLISHER_INDEX_CATEGORIES_SUMMARY', 'Kategoriler özeti');
define('_MD_PUBLISHER_INDEX_CATEGORIES_SUMMARY_INFO', 'İşte en iyi kategorilerin ve alt kategorilerinin bir listesi. İçindeki makaleleri görmek için bir kategori seçin.');
define('_MD_PUBLISHER_INDEX_ITEMS', 'Son yayınlanan makaleler');
define('_MD_PUBLISHER_INDEX_ITEMS_INFO', 'İşte son yayınlanan makalelerin bir listesi.');
define('_MD_PUBLISHER_ITEM', 'makale');
define('_MD_PUBLISHER_ITEM_RECEIVED_AND_PUBLISHED', 'Makaleniz gönderildi ve otomatik olarak yayınlandı. katkınız için teşekkürler!');
define('_MD_PUBLISHER_ITEM_RECEIVED_NEED_APPROVAL', 'Makaleniz gönderildi ve bir moderatör tarafından onaylandıktan sonra yayınlanacaktır.<br>Katkınız için teşekkürler!');
define('_MD_PUBLISHER_ITEMMODIFIED', 'Makale başarıyla değiştirildi!');
define('_MD_PUBLISHER_ITEMS', 'Makaleler');
define('_MD_PUBLISHER_ITEMS_INFO', 'İşte bu kategorideki makaleler.');
define('_MD_PUBLISHER_ITEMS_LINKS', 'Makaleler arasında gezinin');
define('_MD_PUBLISHER_ITEMS_TITLE', 'İçindeki makaleler %s');
define('_MD_PUBLISHER_LAST_SMARTITEM', 'Son yayınlanan makale');
define('_MD_PUBLISHER_NAME', 'Ad');
define('_MD_PUBLISHER_NEED_CATEGORY_ITEM', 'Bir makale oluşturmak için en az bir kategoride uygun izne sahip olmanız gerekir..');
define('_MD_PUBLISHER_NEXT_ITEM', 'Sonraki makale');
define('_MD_PUBLISHER_NO', 'Hayır');
define('_MD_PUBLISHER_NO_CAT_EXISTS', 'Üzgünüz, there&#8217s kategori yok //veya henüz tanımlanmış.<br>Lütfen site yöneticisiyle iletişime geçin ve ona bundan bahsedin.');
define('_MD_PUBLISHER_NO_CAT_PERMISSIONS', "Üzgünüz, bu alana erişmek için yeterli izniniz yok.");
define('_MD_PUBLISHER_NO_TOP_PERMISSIONS', 'Üzgünüz, görüntülenecek makale yok.');
define('_MD_PUBLISHER_NOCATEGORYSELECTED', 'Geçerli bir kategori seçmediniz!');
define('_MD_PUBLISHER_NOITEMSELECTED', 'Geçerli bir makale seçmediniz!');
define('_MD_PUBLISHER_ON', 'açık');
define('_MD_PUBLISHER_OTHER_ITEMS', 'Bu kategorideki diğer makaleler');
define('_MD_PUBLISHER_PAGE', 'Sayfa');
//define('_MD_PUBLISHER_PREVIEW','Preview');
define('_MD_PUBLISHER_PREVIOUS_ITEM', 'Önceki makale');
define('_MD_PUBLISHER_PRINTERFRIENDLY', 'Bu makaleyi yazıcı dostu bir biçimde yazdırın');
define('_MD_PUBLISHER_READS', 'Okunma');
define('_MD_PUBLISHER_RSSFEED', 'Beslemesi');
define('_MD_PUBLISHER_SENDSTORY', 'Bu makaleyi bir arkadaşına gönder');
define('_MD_PUBLISHER_SUB_CLONE', 'Bir makaleyi çoğaltma');
define('_MD_PUBLISHER_SUB_SMNAME', 'Makale Gönder');
define('_MD_PUBLISHER_SUB_SNEWNAME', 'Makale Gönder');
define('_MD_PUBLISHER_SUBMIT', 'Makale Gönder');
define('_MD_PUBLISHER_SUBMIT_ERROR', 'Bir hata oluştu. makaleniz gönderilmedi.');
define('_MD_PUBLISHER_TOTAL_SMARTITEMS', 'Toplam makale');
define('_MD_PUBLISHER_UPLOAD', 'Yükle');
//define('_MD_PUBLISHER_UPLOAD_FILE','Upload a file');
define('_MD_PUBLISHER_VIEW_MORE', 'Makalenin tamamını okuyun');
define('_MD_PUBLISHER_WHO_WHEN', 'Tarafından yayınlandı %s ile %s');
define('_MD_PUBLISHER_PRINT_CLOSE', 'Bu pencereyi kapat');
//added in publisher
define('_MD_PUBLISHER_VOTE_BAD', 'Kötü oy, lütfen tekrar deneyin!');
define('_MD_PUBLISHER_VOTE_ALREADY', 'Üzgünüz, bu öğeye zaten oy verdiniz!');
define('_MD_PUBLISHER_VOTE_THANKS', 'Oy verdiğin için teşekkürler!');
define('_MD_PUBLISHER_VOTE_VOTE', 'Oy');
define('_MD_PUBLISHER_VOTE_VOTES', 'Oylar');
define('_MD_PUBLISHER_VOTE_RATING', 'Değerlendirme');
define('_MD_PUBLISHER_VOTE_DISABLE', 'Oylar devre dışı!');
define('_MD_PUBLISHER_VOTE_OUTOF', 'Dışında');
define('_MD_PUBLISHER_ITEMS_SAME_AUTHOR', 'Aynı yazara ait makaleler');
define('_MD_PUBLISHER_TOTAL_ITEMS', 'Tüm makaleler: ');
define('_MD_PUBLISHER_TOTAL_HITS', 'Toplam hit: ');
define('_MD_PUBLISHER_NO_AUTHOR_ITEMS', 'Bu yazara ait hiçbir makale yok');
define('_MD_PUBLISHER_ARCHIVES', 'Makale Arşivleri');
define('_MD_PUBLISHER_ACTIONS', 'Hareketler');
define('_MD_PUBLISHER_PREVIOUSIMG', 'Önceki Resim');
define('_MD_PUBLISHER_NEXTIMG', 'Sonraki Resim');
define('_MD_PUBLISHER_CLOSE', 'Kapat');
define('_MD_PUBLISHER_ENLARGEIMG', 'Büyüt');
define('_MD_PUBLISHER_OF', ' kapalı ');
//1.04
define('_MD_PUBLISHER_ERROR_NO_PDF', 'XOOPS için TCPDF yüklü değil /class/libraries/vendor/tecnickcom/tcpdf/ <br> lütfen okuyun /docs/readme.txt veya nasıl edineceğinizi öğrenmek için Yardım sekmesine tıklayın!');
//Lio-MJ
define('_MD_PUBLISHER_READMORE', 'Devamını Oku...');
define('_MD_PUBLISHER_CATEGORY', 'Kategori');
define('_MD_PUBLISHER_POSTER', 'Tarafından yayınlandı by');
define('_MD_PUBLISHER_AUTHOR', 'Yazar');
define('_MD_PUBLISHER_TOTALHITS', 'hit');
define('_MD_PUBLISHER_ONECOMMENT', '1 yorum');
define('_MD_PUBLISHER_NO_COMMENTS', 'Yorum yok');

// ---------------- Contents ----------------
// Category
\define('_MA_PUBLISHER_CATEGORY', 'Kategori');
\define('_MA_PUBLISHER_CATEGORY_TITLE', 'Kategori başlığı');
\define('_MA_PUBLISHER_CATEGORY_DESC', 'Kategori açıklaması');
\define('_MA_PUBLISHER_CATEGORY_LIST', 'Kategori Listesi');
// Caption of Category
\define('_MA_PUBLISHER_CATEGORY_ID', 'Id');
\define('_MA_PUBLISHER_CATEGORY_NAME', 'İsim');
\define('_MA_PUBLISHER_CATEGORY_DESCRIPTION', 'Açıklama');
\define('_MA_PUBLISHER_CATEGORY_IMAGELIST', 'Resim listesi');
\define('_MA_PUBLISHER_CATEGORY_IMAGEUPLOAD', 'Resim yükleme');
\define('_MA_PUBLISHER_CATEGORY_CREATED', 'Oluşturuldu');
\define('_MA_PUBLISHER_CATEGORY_EDITED', 'Düzenlendi');
\define('_MA_PUBLISHER_CATEGORY_PUBLISHED', 'Yayınlanan');
\define('_MA_PUBLISHER_CATEGORY__RATINGS', '_derecelendirme');
\define('_MA_PUBLISHER_CATEGORY__VOTES', '_oy');
// Article
\define('_MA_PUBLISHER_ARTICLE', 'Makale');
\define('_MA_PUBLISHER_ARTICLE_DESC', 'Makale Açıklaması');
\define('_MA_PUBLISHER_ARTICLE_LIST', 'Makale Listesi');
// Caption of Article
\define('_MA_PUBLISHER_ARTICLE_ID', 'Id');
\define('_MA_PUBLISHER_ARTICLE_TITLE', 'Başlık');
\define('_MA_PUBLISHER_ARTICLE_SUMMARY', 'Özet');
\define('_MA_PUBLISHER_ARTICLE_DESCRIPTION', 'Açıklamalar');
\define('_MA_PUBLISHER_ARTICLE_IMAGE', 'Resim');
\define('_MA_PUBLISHER_ARTICLE_CREATED', 'Oluşturuldu');
\define('_MA_PUBLISHER_ARTICLE_EDITED', 'Düzenlendi');
\define('_MA_PUBLISHER_ARTICLE_PUBLISHED', 'Yayınlanan');
\define('_MA_PUBLISHER_ARTICLE_CATEGORY', 'Kategori');
\define('_MA_PUBLISHER_ARTICLE__RATINGS', '_derecelendirme');
\define('_MA_PUBLISHER_ARTICLE__VOTES', '_oy');
\define('_MA_PUBLISHER_ARTICLE__COMMENTS', '_yorumlar');
\define('_MA_PUBLISHER_INDEX_THEREARE', 'Toplam %s Makale var');
\define('_MA_PUBLISHER_INDEX_LATEST_LIST', 'Son Blog');
// Submit
\define('_MA_PUBLISHER_SUBMIT', 'Gönder');
// Form
\define('_MA_PUBLISHER_FORM_OK', 'Başarıyla kaydedildi');
\define('_MA_PUBLISHER_FORM_DELETE_OK', 'Başarıyla silindi');
\define('_MA_PUBLISHER_FORM_SURE_DELETE', "Silmek istediğinize emin misiniz: <b><span style='color : Red;'>%s </span></b>");
\define('_MA_PUBLISHER_FORM_SURE_RENEW', "Güncelleme yapacağına emin misin: <b><span style='color : Red;'>%s </span></b>");
\define('_MA_PUBLISHER_FORM_SURE_BROKEN', "Kırık link olarak bildireceğinize emin misiniz: <b><span style='color : Red;'>%s </span></b>");
\define('_MA_PUBLISHER_INVALID_PARAM', 'Geçersiz parametre');
// ---------------- Ratings ----------------
\define('_MA_PUBLISHER_RATING_CURRENT_1', 'Değerlendirme: %c / %m (%t toplam değerlendirme)');
\define('_MA_PUBLISHER_RATING_CURRENT_X', 'Değerlendirme: %c / %m (%t toplam değerlendirme)');
\define('_MA_PUBLISHER_RATING_CURRENT_SHORT_1', '%c (%t değerlendirme)');
\define('_MA_PUBLISHER_RATING_CURRENT_SHORT_X', '%c (%t derecelendirme)');
\define('_MA_PUBLISHER_RATING1', '1 ile 5');
\define('_MA_PUBLISHER_RATING2', '2 ile 5');
\define('_MA_PUBLISHER_RATING3', '3 ile 5');
\define('_MA_PUBLISHER_RATING4', '4 ile 5');
\define('_MA_PUBLISHER_RATING5', '5 ile 5');
\define('_MA_PUBLISHER_RATING_10_1', '1 ile 10');
\define('_MA_PUBLISHER_RATING_10_2', '2 ile 10');
\define('_MA_PUBLISHER_RATING_10_3', '3 ile 10');
\define('_MA_PUBLISHER_RATING_10_4', '4 ile 10');
\define('_MA_PUBLISHER_RATING_10_5', '5 ile 10');
\define('_MA_PUBLISHER_RATING_10_6', '6 ile 10');
\define('_MA_PUBLISHER_RATING_10_7', '7 ile 10');
\define('_MA_PUBLISHER_RATING_10_8', '8 ile 10');
\define('_MA_PUBLISHER_RATING_10_9', '9 ile 10');
\define('_MA_PUBLISHER_RATING_10_10', '10 ile 10');
\define('_MA_PUBLISHER_RATING_VOTE_BAD', 'Geçersiz oy');
\define('_MA_PUBLISHER_RATING_VOTE_ALREADY', 'Zaten oy verdiniz');
\define('_MA_PUBLISHER_RATING_VOTE_THANKS', 'Puanlama için teşekkürler');
\define('_MA_PUBLISHER_RATING_NOPERM', "Üzgünüz, öğeleri derecelendirme izniniz yok");
\define('_MA_PUBLISHER_RATING_LIKE', 'Beğen');
\define('_MA_PUBLISHER_RATING_DISLIKE', 'Beğenme');
\define('_MA_PUBLISHER_RATING_ERROR1', 'Hata: temel tablo güncellenemedi!');

\define('_MA_PUBLISHER_REACTION_LIKE', 'Beğen');
\define('_MA_PUBLISHER_REACTION_LOVE', 'Sevimli');
\define('_MA_PUBLISHER_REACTION_CARE', 'Özenli');
\define('_MA_PUBLISHER_REACTION_HAHA', 'Neşeli');
\define('_MA_PUBLISHER_REACTION_WOW', 'Harika!');
\define('_MA_PUBLISHER_REACTION_SAD', 'Üzgün');
\define('_MA_PUBLISHER_REACTION_ANGRY', 'Sinirli');

// Admin link
\define('_MA_PUBLISHER_ADMIN', 'Admin');
define('_MD_PUBLISHER_PDF', 'XOOPS için TCPDF yüklü /class/libraries/vendor/tecnickcom/tcpdf/');
// ---------------- End ----------------
