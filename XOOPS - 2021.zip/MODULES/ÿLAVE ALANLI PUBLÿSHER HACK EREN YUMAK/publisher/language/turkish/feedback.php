<?php

declare(strict_types=1);
/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * feedback plugin for xoops modules
 *
 * @copyright      module for xoops
 * @license        GPL 2.0 or later
 * @since          1.0
 * @min_xoops      2.5.9
 * @author         XOOPS - Website:<https://xoops.org>
 */
$moduleDirName      = \basename(\dirname(__DIR__, 2));
$moduleDirNameUpper = mb_strtoupper($moduleDirName);

define('CO_' . $moduleDirNameUpper . '_' . 'FB_FORM_TITLE', 'Geri bildirim gönder');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_RECIPIENT', 'Alıcı');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_NAME', 'Adınız');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_NAME_PLACEHOLER', 'Lütfen adınızı giriniz');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_SITE', 'Website');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_SITE_PLACEHOLER', 'Lütfen web sitenizi girin');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_MAIL', 'Email');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_MAIL_PLACEHOLER', 'Lütfen E-postanızı girin');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_TYPE', 'Geri bildirim türü');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_TYPE_SUGGESTION', 'Öneriler');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_TYPE_BUGS', 'Hatalar');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_TYPE_TESTIMONIAL', 'Referanslar');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_TYPE_FEATURES', 'Özellikler');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_TYPE_OTHERS', 'Çeşitli');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_TYPE_CONTENT', 'Geri bildirim içeriği');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_SEND_FOR', 'Modül için geri bildirim ');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_SEND_SUCCESS', 'Geri bildirim başarıyla gönderildi');
define('CO_' . $moduleDirNameUpper . '_' . 'FB_SEND_ERROR', 'Geri bildirim gönderilirken bir hata oluştu!');
