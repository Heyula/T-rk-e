<?php
/*
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * @copyright    XOOPS Project (https://xoops.org)
 * @license      GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * @package
 * @since
 * @author     XOOPS Development Team
 */

// Blocks & Groups Admin
define('_AM_TOPPAGE', 'Üst Sayfa');
define('_AM_ALLPAGES', 'Tüm Sayfalar');
define('_AM_TITLE', 'Başlık');
define('_AM_SIDE', 'Taraf');
define('_AM_WEIGHT', 'Sıra');
define('_AM_VISIBLE', 'Görünür');
define('_AM_VISIBLEIN', 'Görünür');
define('_AM_ACTION', 'Eylem');
define('_AM_LATESTNEWS_TITLE', 'Başlık');
define('_AM_LATESTNEWS_WEIGHT', 'Sırat');
define('_AM_BCACHETIME', 'Önbellek süresi');
define('_AM_LATESTNEWS_ACTION', 'Eyle');
define('_AM_ACTIVERIGHTS', 'Modül yönetim hakları');
define('_AM_ACCESSRIGHTS', 'Modül erişim hakları');
define('_AM_BADMIN', 'Blok yönetimi');
define('_AM_ADGS', 'Gruplar');
define('_AM_ALLMODULEPAGES', 'Gruplar');
define('_AM_SYSTEMLEVEL', '_AM_SYSTEMLEVEL');
define('_AM_ADMINBLOCK', '_AM_ADMINBLOCK');

define('_AM_BLOCKTAG1', '%s yazdıracak %s');
define('_AM_ADDBLOCK', 'reklam engelleme');
define('_AM_NOTSELNG', 'Not Sel');
