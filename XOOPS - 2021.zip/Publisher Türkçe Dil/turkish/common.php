<?php

declare(strict_types=1);

/**
 * Module: Publisher
 * Author: The SmartFactory <www.smartfactory.ca>
 * Licence: GNU
 */
define('_CO_PUBLISHER_MESSAGE_FILE_ERROR', 'Hata: Aşağıdaki nedenlerle yüklenen dosya depolanamıyor:<br>%s');
define('_CO_PUBLISHER_MESSAGE_WRONG_MIMETYPE', 'Hata: dosya türüne izin verilmiyor. Lütfen yeniden gönderin.');
define('_CO_PUBLISHER_ALLOWCOMMENTS', 'Makale yorumlanabilir mi?');
define('_CO_PUBLISHER_AUTHOR_ALIAS', 'Yazar takma adı');
define('_CO_PUBLISHER_AUTHOR_ALIAS_DSC', 'Posterin takma adını seçin, bu "anonim" yerine kullanılacak ve makalenin sahip kimliğini 0 olarak ayarlayacaktır.');
define('_CO_PUBLISHER_AVAILABLE_PAGE_WRAP', 'Eklenecek mevcut sayfalar');
define('_CO_PUBLISHER_AVAILABLE_PAGE_WRAP_DSC', 'İşte gövdeye sarmak için kullanılabilecek sayfalar. Sarmak istediğiniz sayfalara tıklayın. Yalnızca şu an için XOOPS düzenleyicisiyle çalışır. Başka bir düzenleyicideyseniz manuel olarak ekleyin.');
define('_CO_PUBLISHER_DATESUB', 'Yayınlanan');
define('_CO_PUBLISHER_DATESUB_DSC', 'Yayın tarihini seçin');
define('_CO_PUBLISHER_DATEEXPIRE', 'Son kullanma tarihi');
define('_CO_PUBLISHER_DATEEXPIRE_DSC', 'Bir son kullanma tarihi seçmek ister misiniz? Süresi dolduğunda makale artık gösterilmeyecek');
define('_CO_PUBLISHER_ITEM_META_DESCRIPTION', 'Meta Açıklaması');
define('_CO_PUBLISHER_ITEM_META_DESCRIPTION_DSC', 'Arama Motorlarına yardımcı olmak için bu makale için kullanmak istediğiniz meta açıklamayı özelleştirebilirsiniz. Kategori oluştururken bu alanı boş bırakırsanız, bu makalenin Özet alanı otomatik olarak doldurulacaktır.');
define('_CO_PUBLISHER_ITEM_META_KEYWORDS', 'Anahtar Kelimeler ');
define('_CO_PUBLISHER_ITEM_META_KEYWORDS_DSC', 'Arama Motorlarına yardımcı olmak için bu makale için kullanmak istediğiniz anahtar kelimeleri özelleştirebilirsiniz. Bir makale oluştururken bu alanı boş bırakırsanız, bu makalenin Özet alanındaki kelimelerle otomatik olarak doldurulur.');
define('_CO_PUBLISHER_ITEM_SHORT_URL', 'Kısa url');
define('_CO_PUBLISHER_ITEM_SHORT_URL_DSC', 'Bu modülün SEO özelliklerini kullanırken, bu makale için bir Kısa URL belirtebilirsiniz. Bu alan isteğe bağlıdır.');
//define('_CO_PUBLISHER_PERMISSIONS_ITEM', 'Permissions');
//define('_CO_PUBLISHER_PERMISSIONS_ITEM_DSC', 'Groups that will have permissions to see this item.');
define('_CO_PUBLISHER_SUBMITTED', 'Gönderilen');
define('_CO_PUBLISHER_PUBLISHED', 'Yayına Al');
define('_CO_PUBLISHER_OFFLINE', 'Çevrimdışı');
define('_CO_PUBLISHER_REJECTED', 'Reddedildi');
define('_CO_PUBLISHER_STATUS', 'Durum');
define('_CO_PUBLISHER_STATUS_DSC', 'Bu makalenin durumunu seçin');
define('_CO_PUBLISHER_UID', 'Poster adı');
define('_CO_PUBLISHER_UID_DSC', 'Posterin adını seçin');
define('_CO_PUBLISHER_WEIGHT', 'Önem');
define('_CO_PUBLISHER_ITEM_UPLOAD_FILE', 'Dosya yükleme');
define(
    '_CO_PUBLISHER_ITEM_UPLOAD_FILE_DSC',
    'Bu makaleye eklemek için bilgisayarınızdan bir dosya seçin. Makale oluşturulduktan sonra daha fazla dosya ekleyebileceksiniz. Makaleyi düzenleyin ve dosya ekle düğmesini görmek için sayfanın en altına gidin.<br><br> örneğin, bir Word belgesi veya bir Excel belgesi ekleyebilirsiniz. Hatta bir Flash dosyası yükleyebilirsiniz ve bu dosya doğrudan makalenize eklenecektir! '
);
//define('_CO_PUBLISHER_OPTIONS','Options');
define('_CO_PUBLISHER_DISPLAY_SUMMARY', 'Öğe sayfasında özeti görüntüle ?');
define('_CO_PUBLISHER_DOHTML', 'HTML etiketlerini etkinleştir');
define('_CO_PUBLISHER_DOIMAGE', 'Resimleri etkinleştir');
define('_CO_PUBLISHER_DOLINEBREAK', 'Satır sonunu etkinleştir');
define('_CO_PUBLISHER_DOSMILEY', 'Gülen yüz simgelerini etkinleştir');
define('_CO_PUBLISHER_DOXCODE', 'XOOPS kodlarını etkinleştir');
define('_CO_PUBLISHER_EDIT', 'Makaleyi düzenle');
define('_CO_PUBLISHER_CLONE', 'Çift Makale');
define('_CO_PUBLISHER_ADD_FILE', 'Dosya ekle');
define('_CO_PUBLISHER_DELETE', 'Makaleyi sil');
define('_CO_PUBLISHER_PDF', 'Bu makaleyi PDF formatında görüntüleyin');
define('_CO_PUBLISHER_PRINT', 'Makaleyi yazdır');
define('_CO_PUBLISHER_MAIL', 'Makale gönder ');
define('_CO_PUBLISHER_INTITEM', 'adresindeki bu makaleye bir göz atın %s');
define('_CO_PUBLISHER_INTITEMFOUND', 'İşte bulduğum ilginç bir makale %s');
define('_CO_PUBLISHER_POSTEDBY', 'Tarafından by %s on %s');
define('_CO_PUBLISHER_BODY', 'Makale İçeriği');
define('_CO_PUBLISHER_BODY_DSC', "Makalenin tam içeriği ana metin");
define('_CO_PUBLISHER_CATEGORY', 'Kategori');
define('_CO_PUBLISHER_CATEGORY_DSC', "Makalenin kategorisi.");
define('_CO_PUBLISHER_IMAGE_ITEM', 'Makalenin ana resimi');
define('_CO_PUBLISHER_IMAGE_ITEM_DSC', 'Makaleyi temsil eden resim');
define('_CO_PUBLISHER_IMAGE_UPLOAD', 'Resim yükle');
//define('_CO_PUBLISHER_IMAGE_UPLOAD_ITEM_DSC','Select an image on your computer. <br>This image will be uploaded to the site <br>and set as the article image.');
define('_CO_PUBLISHER_SUBCATEGORIES_INFO', 'içindeki alt kategoriler <em>%s</em> :');
define('_CO_PUBLISHER_SUMMARY', 'Makalenin Özet Metni');
define('_CO_PUBLISHER_SUMMARY_DSC', 'Bu özet bloklar, dizin ve kategori sayfaları için kullanılır. Makale içinde görüntülenmez.');
define('_CO_PUBLISHER_TITLE', 'Başlık');
define('_CO_PUBLISHER_SUBTITLE', 'Alt Başlık');
define('_CO_PUBLISHER_ERROR', 'Üzgünüz, bazı hatalar oluştu!');
define('_CO_PUBLISHER_SORTBY', 'Göre sırala');
define('_CO_PUBLISHER_ADD', 'Ekle');
define('_CO_PUBLISHER_REMOVE', 'Kaldır');
define('_CO_PUBLISHER_PREVIEW', 'Ön izleme');
define('_CO_PUBLISHER_CREATE', 'Oluştur');
define('_CO_PUBLISHER_CLEAR', 'Temizle');
define('_CO_PUBLISHER_CANCEL', 'İptal et');
define('_CO_PUBLISHER_IMAGE_ITEMS', 'Makale resimleri');
define('_CO_PUBLISHER_IMAGE_ITEMS_DSC', 'Lütfen bu makaleyle ilgili resimleri seçin');
define('_CO_PUBLISHER_IMAGE_PREVIEW', 'Resim Önizleme');
define('_CO_PUBLISHER_NOTIFY', 'Yayınlandığında bilgilendirilsin mi?');
define('_CO_PUBLISHER_FILEUPLOAD_ERROR', 'Dosya yüklenirken bir hata oluştu.');
define('_CO_PUBLISHER_FILEUPLOAD_SUCCESS', 'Dosya başarıyla yüklendi.');
define('_CO_PUBLISHER_NEW_FEATURE', 'Yeni özellik!');
define('_CO_PUBLISHER_TAB_MAIN', 'Main');
define('_CO_PUBLISHER_TAB_IMAGES', 'Resimler');
define('_CO_PUBLISHER_TAB_OTHERS', 'Diğerleri');
define('_CO_PUBLISHER_TAB_META', 'Meta veri');
define('_CO_PUBLISHER_TAB_PERMISSIONS', 'İzinler');
define('_CO_PUBLISHER_IMAGE_UPLOAD_NEW', 'Yeni resim yükle');
//define('_CO_PUBLISHER_IMAGE_UPLOADING','Uploading');
define('_CO_PUBLISHER_IMAGE_NICENAME', 'Resim adını yazın');
define('_CO_PUBLISHER_IMAGE_CAT_NONE', 'Resim kategorisi bulunamadı');
define('_CO_PUBLISHER_IMAGE_CAT_NOPERM', 'Bu resim kategorisini kullanma izniniz yok');
//30/04/2012
define('_CO_PUBLISHER_TAB_FILES', 'Dosyalar');
define('_CO_PUBLISHER_FILE', 'Dosyalar');
define('_CO_PUBLISHER_FILE_DESCRIPTION', 'Açıklama');
define('_CO_PUBLISHER_FILE_DESCRIPTION_DSC', 'Yüklenecek dosyanın açıklaması.');
define('_CO_PUBLISHER_FILE_NAME_DSC', 'Dosyayı tanımlamak için kullanılacak ad.');
define('_CO_PUBLISHER_FILE_STATUS', 'Dosya görünür mü? ');
define('_CO_PUBLISHER_FILE_STATUS_DSC', 'Hayır ı seçerseniz, dosya kullanıcı tarafından görünmeyecektir.');
define('_CO_PUBLISHER_FILE_TO_UPLOAD', 'Yüklenecek dosya:');
define('_CO_PUBLISHER_FILE_TYPE', 'Dosya tipi');
define('_CO_PUBLISHER_FILE_UPLOAD_ANOTHER', 'Tekrar yükle');
define('_CO_PUBLISHER_FILENAME', 'Dosya adı');
define('_CO_PUBLISHER_FILES_LINKED', 'Bu makaleye bağlı dosyalar');
//Added 30/05/2012
define('_CO_PUBLISHER_EDITFILE', 'Dosyayı düzenle');
define('_CO_PUBLISHER_DELETEFILE', 'Dosyayı sil');
//added 2017-05-16
define('_CO_PUBLISHER_BAD_TOKEN', 'Geçersiz - Hata , lütfen tekrar deneyin');

//2017-11-22

$moduleDirName      = \basename(\dirname(__DIR__, 2));
$moduleDirNameUpper = mb_strtoupper($moduleDirName);

define('CO_' . $moduleDirNameUpper . '_GDLIBSTATUS', 'GD kitaplığı desteği: ');
define('CO_' . $moduleDirNameUpper . '_GDLIBVERSION', 'GD Kitaplığı sürümü: ');
define('CO_' . $moduleDirNameUpper . '_GDOFF', "<span style='font-weight: bold;'>Hizmet dışı</span> (Küçük resim yok)");
define('CO_' . $moduleDirNameUpper . '_GDON', "<span style='font-weight: bold;'>Etkinleştirilmiş</span> (Küçük resimler mevcut)");
define('CO_' . $moduleDirNameUpper . '_IMAGEINFO', 'Sunucu durumu');
define('CO_' . $moduleDirNameUpper . '_MAXPOSTSIZE', 'İzin verilen maksimum gönderi boyutu (php.ini de post_max_size yönergesi): ');
define('CO_' . $moduleDirNameUpper . '_MAXUPLOADSIZE', 'İzin verilen maksimum yükleme boyutu (php.ini de upload_max_filesize yönergesi): ');
define('CO_' . $moduleDirNameUpper . '_MEMORYLIMIT', 'Bellek sınırı (php.ini de memory_limit yönergesi): ');
define('CO_' . $moduleDirNameUpper . '_METAVERSION', "<span style='font-weight: bold;'>Meta sürümü indirir:</span> ");
define('CO_' . $moduleDirNameUpper . '_OFF', "<span style='font-weight: bold;'>KAPALI</span>");
define('CO_' . $moduleDirNameUpper . '_ON', "<span style='font-weight: bold;'>AÇIK</span>");
define('CO_' . $moduleDirNameUpper . '_SERVERPATH', 'XOOPS dizinine giden sunucu yolu: ');
define('CO_' . $moduleDirNameUpper . '_SERVERUPLOADSTATUS', 'Sunucu yükleme durumu: ');
define('CO_' . $moduleDirNameUpper . '_SPHPINI', "<span style='font-weight: bold;'>PHP ini dosyasından alınan bilgiler:</span>");
define('CO_' . $moduleDirNameUpper . '_UPLOADPATHDSC', 'Not. Yükleme yolu *ZORUNLU*, yükleme klasörünüzün tam sunucu yolunu içerir.');

define('CO_' . $moduleDirNameUpper . '_PRINT', "<span style='font-weight: bold;'>Yazdır</span>");
define('CO_' . $moduleDirNameUpper . '_PDF', "<span style='font-weight: bold;'>PDF oluştur</span>");

define('CO_' . $moduleDirNameUpper . '_UPGRADEFAILED0', "Güncelleme başarısız oldu - alan yeniden adlandırılamadı '%s'");
define('CO_' . $moduleDirNameUpper . '_UPGRADEFAILED1', "Güncelleme başarısız oldu - yeni alanlar eklenemedi");
define('CO_' . $moduleDirNameUpper . '_UPGRADEFAILED2', "Güncelleme başarısız oldu - tablo yeniden adlandırılamadı '%s'");
define('CO_' . $moduleDirNameUpper . '_ERROR_COLUMN', 'Veritabanında sütun oluşturulamadı : %s');
define('CO_' . $moduleDirNameUpper . '_ERROR_BAD_XOOPS', 'Bu modül XOOPS gerektirir %s+ (%s Kurulmuş)');
define('CO_' . $moduleDirNameUpper . '_ERROR_BAD_PHP', 'Bu modül PHP sürümü gerektirir %s+ (%s Kurulmuş)');
define('CO_' . $moduleDirNameUpper . '_ERROR_TAG_REMOVAL', 'Etiketler, Etiket Modülünden kaldırılamadı');

define('CO_' . $moduleDirNameUpper . '_FOLDERS_DELETED_OK', 'Yükleme Klasörleri silindi');

// Error Msgs
define('CO_' . $moduleDirNameUpper . '_ERROR_BAD_DEL_PATH', 'Dizin %s silinemedi');
define('CO_' . $moduleDirNameUpper . '_ERROR_BAD_REMOVE', 'Silinemedi %s');
define('CO_' . $moduleDirNameUpper . '_ERROR_NO_PLUGIN', 'Eklenti yüklenemedi');

//Help
define('CO_' . $moduleDirNameUpper . '_DIRNAME', basename(dirname(__DIR__, 2)));
define('CO_' . $moduleDirNameUpper . '_HELP_HEADER', __DIR__ . '/help/helpheader.tpl');
define('CO_' . $moduleDirNameUpper . '_BACK_2_ADMIN', 'Yönetimine Geri Dön ');
define('CO_' . $moduleDirNameUpper . '_OVERVIEW', 'Genel Bakış');

//define('CO_' . $moduleDirNameUpper . '_HELP_DIR', __DIR__);

//help multi-page
define('CO_' . $moduleDirNameUpper . '_DISCLAIMER', 'Sorumluluk Reddi');
define('CO_' . $moduleDirNameUpper . '_LICENSE', 'Lisans');
define('CO_' . $moduleDirNameUpper . '_SUPPORT', 'Destek');

//Sample Data
\define('CO_' . $moduleDirNameUpper . '_' . 'LOAD_SAMPLEDATA', 'Örnek Verileri İçe Aktar (TÜM mevcut verileri siler)');
\define('CO_' . $moduleDirNameUpper . '_' . 'LOAD_SAMPLEDATA_CONFIRM', 'Örnek Verileri İçe Aktaracağınızdan emin misiniz? (TÜM mevcut verileri silecektir)');
\define('CO_' . $moduleDirNameUpper . '_' . 'LOAD_SAMPLEDATA_SUCCESS', 'Örnek Tarih başarıyla içe aktarıldı');
\define('CO_' . $moduleDirNameUpper . '_' . 'SAVE_SAMPLEDATA', 'Tabloları YAML ye Dışa Aktar');
\define('CO_' . $moduleDirNameUpper . '_' . 'SAVE_SAMPLEDATA_SUCCESS', 'Tabloları başarıyla YAML ye aktarıldı');
\define('CO_' . $moduleDirNameUpper . '_' . 'CLEAR_SAMPLEDATA', 'Örnek Verileri Temizle');
\define('CO_' . $moduleDirNameUpper . '_' . 'CLEAR_SAMPLEDATA_OK', 'Örnek Veriler temizlendi');
\define('CO_' . $moduleDirNameUpper . '_' . 'CLEAR_SAMPLEDATA_CONFIRM', 'Örnek Verileri Temizlediğinizden emin misiniz? (TÜM mevcut verileri silecektir) ');
\define('CO_' . $moduleDirNameUpper . '_' . 'EXPORT_SCHEMA', 'DB Şemasını YAML ye Aktar');
\define('CO_' . $moduleDirNameUpper . '_' . 'EXPORT_SCHEMA_SUCCESS', 'DB Şemasını YAML ye dışa aktarma başarılı oldu');
\define('CO_' . $moduleDirNameUpper . '_' . 'EXPORT_SCHEMA_ERROR', 'HATA: DB Şemasının YAML ye Dışa Aktarılması başarısız oldu');
\define('CO_' . $moduleDirNameUpper . '_' . 'SHOW_SAMPLE_BUTTON', 'Örnek Veriler Düğmesini Göster?');
\define('CO_' . $moduleDirNameUpper . '_' . 'SHOW_SAMPLE_BUTTON_DESC', 'Evet ise, "Örnek Veri Ekle" düğmesi Yönetici tarafından görülecektir. İlk kurulum için varsayılan olarak Evet tir.');
\define('CO_' . $moduleDirNameUpper . '_' . 'HIDE_SAMPLEDATA_BUTTONS', 'İçe Aktar düğmelerini gizle)');
\define('CO_' . $moduleDirNameUpper . '_' . 'SHOW_SAMPLEDATA_BUTTONS', 'İçe Aktar düğmelerini göster)');

\define('CO_' . $moduleDirNameUpper . '_' . 'CONFIRM', 'Teyit etmek');

//letter choice
define('CO_' . $moduleDirNameUpper . '_' . 'BROWSETOTOPIC', "<span style='font-weight: bold;'>Öğelere alfabetik olarak göz atın</span>");
define('CO_' . $moduleDirNameUpper . '_' . 'OTHER', 'Diğer');
define('CO_' . $moduleDirNameUpper . '_' . 'ALL', 'Tümü');

// block defines
define('CO_' . $moduleDirNameUpper . '_' . 'ACCESSRIGHTS', 'Erişim Hakları');
define('CO_' . $moduleDirNameUpper . '_' . 'ACTION', 'Eylem');
define('CO_' . $moduleDirNameUpper . '_' . 'ACTIVERIGHTS', 'Aktif Haklar');
define('CO_' . $moduleDirNameUpper . '_' . 'BADMIN', 'Blok Yönetimi ');
define('CO_' . $moduleDirNameUpper . '_' . 'BLKDESC', 'Açıklama');
define('CO_' . $moduleDirNameUpper . '_' . 'CBCENTER', 'Merkez Orta');
define('CO_' . $moduleDirNameUpper . '_' . 'CBLEFT', 'Orta Sol');
define('CO_' . $moduleDirNameUpper . '_' . 'CBRIGHT', 'Orta Sağ');
define('CO_' . $moduleDirNameUpper . '_' . 'SBLEFT', 'Sol');
define('CO_' . $moduleDirNameUpper . '_' . 'SBRIGHT', 'Sağ');
define('CO_' . $moduleDirNameUpper . '_' . 'SIDE', 'Hizalama');
define('CO_' . $moduleDirNameUpper . '_' . 'TITLE', 'Başlık');
define('CO_' . $moduleDirNameUpper . '_' . 'VISIBLE', 'Görünür');
define('CO_' . $moduleDirNameUpper . '_' . 'VISIBLEIN', 'İçinde Görünür');
define('CO_' . $moduleDirNameUpper . '_' . 'WEIGHT', 'Ağırlık');

define('CO_' . $moduleDirNameUpper . '_' . 'PERMISSIONS', 'İzinler');
define('CO_' . $moduleDirNameUpper . '_' . 'BLOCKS', 'Blok Yöneticisi');
define('CO_' . $moduleDirNameUpper . '_' . 'BLOCKS_DESC', 'Bloklar/Grup Yöneticisi');

define('CO_' . $moduleDirNameUpper . '_' . 'BLOCKS_MANAGMENT', 'Yönetim');
define('CO_' . $moduleDirNameUpper . '_' . 'BLOCKS_ADDBLOCK', 'Yeni bir blok ekle');
define('CO_' . $moduleDirNameUpper . '_' . 'BLOCKS_EDITBLOCK', 'Bir bloğu düzenle');
define('CO_' . $moduleDirNameUpper . '_' . 'BLOCKS_CLONEBLOCK', 'Bir bloğu klonla');

//myblocksadmin
define('CO_' . $moduleDirNameUpper . '_' . 'AGDS', 'Yönetici Grupları');
define('CO_' . $moduleDirNameUpper . '_' . 'BCACHETIME', 'Önbellek süresi');
define('CO_' . $moduleDirNameUpper . '_' . 'BLOCKS_ADMIN', 'Blok Yöneticisi');
define('CO_' . $moduleDirNameUpper . '_' . 'UPDATE_SUCCESS', 'Güncelleme başarılı');

//Template Admin
define('CO_' . $moduleDirNameUpper . '_' . 'TPLSETS', 'Şablon Yönetimi');
define('CO_' . $moduleDirNameUpper . '_' . 'GENERATE', 'Oluştur');
define('CO_' . $moduleDirNameUpper . '_' . 'FILENAME', 'Dosya adı');

//Menu
define('CO_' . $moduleDirNameUpper . '_' . 'ADMENU_MIGRATE', 'Taşıma');
define('CO_' . $moduleDirNameUpper . '_' . 'FOLDER_YES', 'Klasör "%s" mevcut');
define('CO_' . $moduleDirNameUpper . '_' . 'FOLDER_NO', 'Klasör "%s" mevcut değil. ile belirtilen klasörü oluşturun CHMOD 777.');
define('CO_' . $moduleDirNameUpper . '_' . 'SHOW_DEV_TOOLS', 'Geliştirme Araçlarını Göster Düğmesi?');
define('CO_' . $moduleDirNameUpper . '_' . 'SHOW_DEV_TOOLS_DESC', 'Evetse, "Taşı" Sekmesi ve diğer Geliştirme araçları Yönetici tarafından görülecektir.');
define('CO_' . $moduleDirNameUpper . '_' . 'ADMENU_FEEDBACK', 'Geri bildirim');
define('CO_' . $moduleDirNameUpper . '_' . 'MIGRATE_OK', 'Veritabanı geçerli şemaya taşındı.');
define('CO_' . $moduleDirNameUpper . '_' . 'MIGRATE_WARNING', 'Uyarı! Bu yalnızca geliştiriciler için tasarlanmıştır. Geçerli veritabanından şema dosyasını yazmayı onaylayın.');
define('CO_' . $moduleDirNameUpper . '_' . 'MIGRATE_SCHEMA_OK', 'Geçerli şema dosyası yazıldı');

//Latest Version Check
define('CO_' . $moduleDirNameUpper . '_' . 'NEW_VERSION', 'Yeni sürüm: ');

//Module Stats
define('CO_' . $moduleDirNameUpper . '_' . 'STATS_SUMMARY', 'Modül İstatistikleri');

//Preferences
define('CO_' . $moduleDirNameUpper . '_' . 'TRUNCATE_LENGTH', 'Uzun metin alanına kesilecek Karakter Sayısı');
define('CO_' . $moduleDirNameUpper . '_' . 'TRUNCATE_LENGTH_DESC', 'Uzun metin alanlarını kesmek için maksimum karakter sayısını ayarlayın');

