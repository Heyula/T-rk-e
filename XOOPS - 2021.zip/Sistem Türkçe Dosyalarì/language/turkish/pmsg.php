<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
//%%%%%%    File Name readpmsg.php  %%%%%
define('_PM_DELETED', 'Mesajlarınız Silindi');
define('_PM_PRIVATEMESSAGE', 'Özel Mesajlar');
define('_PM_INBOX', 'Gelen Kutusu');
define('_PM_FROM', 'Kimden');
define('_PM_YOUDONTHAVE', 'Hiç özel mesajınız yok');
define('_PM_FROMC', 'Kimden: ');
define('_PM_SENTC', 'Gönderilen: '); // The date of message sent
define('_PM_PROFILE', 'Profil');
// %s is a username
define('_PM_PREVIOUS', 'Önceki Mesaj');
define('_PM_NEXT', 'Sonraki Mesaj');
//%%%%%%    File Name pmlite.php    %%%%%
define('_PM_SORRY', 'Üzgünüm! Kayıtlı bir kullanıcı değilsiniz.');
define('_PM_REGISTERNOW', 'Şimdi üye Ol!');
define('_PM_GOBACK', 'Geri Dön');
define('_PM_USERNOEXIST', 'Seçilen kullanıcı veritabanında mevcut değil.');
define('_PM_PLZTRYAGAIN', 'Lütfen ismi kontrol edin ve yeniden deneyin.');
define('_PM_MESSAGEPOSTED', 'Mesajınız Yayınlandı');
define('_PM_CLICKHERE', 'Özel mesajlarınızı görüntülemek için buraya tıklayabilirsiniz.');
define('_PM_ORCLOSEWINDOW', 'Veya bu pencereyi kapatmak için buraya tıklayın.');
define('_PM_USERWROTE', '%s yazdı:');
define('_PM_TO', 'To: ');
define('_PM_SUBJECTC', 'Konu: ');
define('_PM_MESSAGEC', 'Mesaj: ');
define('_PM_CLEAR', 'Temizle');
define('_PM_CANCELSEND', 'Göndermekten Vazgeç');
define('_PM_SUBMIT', 'Gönder');
//%%%%%%    File Name viewpmsg.php  %%%%%
define('_PM_SUBJECT', 'Konu');
define('_PM_DATE', 'Tarih');
define('_PM_NOTREAD', 'Okunmadı');
define('_PM_SEND', 'Gönder');
define('_PM_DELETE', 'Sil');
define('_PM_REPLY', 'Cevap Ver');
define('_PM_PLZREG', 'Özel mesaj göndermek için lütfen önce kayıt olun!');
define('_PM_ONLINE', 'Online');
//XOOPS 2.5.2
define('_PM_SURE_TO_DELETE', 'Bu iletileri silmek istediğinizden emin misiniz?');
//XOOPS 2.5.5
define('_PM_READ', 'Zaten Okundu');
