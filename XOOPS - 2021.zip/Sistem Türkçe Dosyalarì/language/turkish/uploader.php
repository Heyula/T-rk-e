<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_ER_UP_MIMETYPELOAD', 'MIME türleri tanımı yüklenirken hata oluştu');
define('_ER_UP_FILENOTFOUND', 'Dosya bulunamadı');
define('_ER_UP_INVALIDFILESIZE', 'Geçersiz Dosya Boyutu');
define('_ER_UP_FILENAMEEMPTY', 'Dosya Adı Eksik');
define('_ER_UP_NOFILEUPLOADED', 'Dosya yüklenmedi');
define('_ER_UP_ERROROCCURRED', 'Beklenmeyen Tata #%s');
define('_ER_UP_UPLOADDIRNOTSET', 'Yükleme dizini ayarlanmadı');
define('_ER_UP_FAILEDOPENDIR', 'Dizin açılamadı: %s');
define('_ER_UP_FAILEDOPENDIRWRITE', 'Yazma izniyle dizin açılamadı: %s');
define('_ER_UP_FILESIZETOOLARGE', 'Dosya boyutu çok büyük (Maximum %u bytes): %u bytes');
define('_ER_UP_FILEWIDTHTOOLARGE', 'Dosya genişliği çok büyük (Maximum %u px): %u px');
define('_ER_UP_FILEHEIGHTTOOLARGE', 'Dosya yüksekliği çok büyük (Maximum %u px): %u px');
define('_ER_UP_MIMETYPENOTALLOWED', 'MIME türü dosya: %s is not allowed');
define('_ER_UP_FAILEDUPLOADFILE', 'Dosya yüklenemedi: %s');
define('_ER_UP_FAILEDFETCHIMAGESIZE', 'Resim boyutu %s, olarak güncellenmeli..');
define('_ER_UP_UNKNOWNFILETYPEREJECTED', "Yüklemeye çalıştığınız dosya bu site/sunucu tarafından desteklenmiyor.");
define('_ER_UP_ERRORSRETURNED', 'Dosya Yüklenirken Oluşan Hatalar: %s');
define('_ER_UP_INVALIDIMAGEFILE', 'Geçersiz resim dosyası');
define('_ER_UP_SUSPICIOUSREFUSED', 'Şüpheli resim yüklemesi reddedildi');
define('_ER_UP_INVALIDFILENAME', 'Geçersiz dosya adı');
define('_ER_UP_FAILEDSAVEFILE', 'Dosya kaydedilemedi %s');
define('_ER_UP_INISIZE', 'Yüklenen dosya, upload_max_filesize yönergesini aşıyor. php.ini');
define('_ER_UP_FORMSIZE', 'Yüklenen dosya, HTML formunda belirtilen MAX_FILE_SIZE yönergesini aşıyor');
define('_ER_UP_PARTIAL', 'Yüklenen dosya yalnızca kısmen yüklendi');
define('_ER_UP_NOFILE', 'Dosya yüklenmedi');
define('_ER_UP_NOTMPDIR', 'Geçici klasör eksik');
define('_ER_UP_CANTWRITE', 'Dosya sunucuya yazılamadı');
define('_ER_UP_EXTENSION', 'Dosya yükleme, uzantı tarafından durduruldu. phpinfo yu görüntüle()');
define('_ER_UP_UNKNOWN', 'Bilinmeyen yükleme hatası');
define('_ER_UP_INDEXNOTSET', 'Birden çok dosya getirilmeye çalışılıyor, dizin ayarlanmalıdır.');
