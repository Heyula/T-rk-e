<?php

define('_AM_XMF_MODULE_NOTFOUND','Lütfen yükleyin veya yeniden etkinleştirin %1$s modül. Minimum gerekli sürüm: %2$s');
define('_AM_XMF_MODULE_VERSION','Minimum %1$s modül sürümü gerekli: %2$s (mevcut versiyon %3$s)');
define('_AM_XMF_MODULE_INSTALLED', 'Modül \'%s\' Başarıyla Kuruldu!');
define('_AM_XMF_MODULE_NOT_INSTALLED', 'Modül \'%s\' Yüklenemedi!');

define('_DB_XMF_TABLE_IS_NOT_DEFINED','Tablo tanımlı değil');
