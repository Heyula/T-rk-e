<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_CM_TITLE', 'Başlık');
define('_CM_MESSAGE', 'Mesaj');
define('_CM_DOSMILEY', 'Smiley Simgelerini Etkinleştir');
define('_CM_DOHTML', 'HTML Etiketlerini Etkinleştir');
define('_CM_DOAUTOWRAP', 'Otomatik sarma hatları');
define('_CM_DOXCODE', 'XOOPS Kodlarını Etkinleştir');
define('_CM_REFRESH', 'Yenile');
define('_CM_PENDING', 'Beklemede');
define('_CM_HIDDEN', 'Gizli');
define('_CM_ACTIVE', 'Aktif');
define('_CM_STATUS', 'Durum');
define('_CM_POSTCOMMENT', 'Yorumu Yayınla');
define('_CM_REPLIES', 'Cevaplar');
define('_CM_PARENT', 'Konrol');
define('_CM_TOP', 'Yukarı');
define('_CM_BOTTOM', 'Aşşağı');
define('_CM_ONLINE', 'Aktif!');
define('_CM_POSTED', 'Yayınlanan'); // Posted date
define('_CM_UPDATED', 'Güncellendi');
define('_CM_THREAD', 'Konu');
define('_CM_POSTER', 'Yazar');
define('_CM_JOINED', 'Katıldı');
define('_CM_POSTS', 'Yorumlar');
define('_CM_FROM', 'İtibaren');
define('_CM_COMDELETED', 'Yorum (lar) silindi.');
define('_CM_COMDELETENG', 'Yorum silinemedi.');
define('_CM_DELETESELECT', 'Tüm alt yorumlarını sil?');
define('_CM_DELETEONE', 'Hayır, yalnızca bu yorumu sil');
define('_CM_DELETEALL', 'Evet hepsini sil');
define('_CM_THANKSPOST', 'Yorumlarınız için teşekkürler!');
define('_CM_NOTICE', "Yorumlar yazara aittir. İçeriklerinden sorumlu değiliz.");
define('_CM_COMRULES', 'Yorum Kuralları');
define('_CM_COMAPPROVEALL', 'Yorumlar her zaman onaylanır');
define('_CM_COMAPPROVEUSER', 'Kayıtlı kullanıcıların yorumları her zaman onaylanır');
define('_CM_COMAPPROVEADMIN', 'Tüm yorumların yönetici tarafından onaylanması gerekir');
define('_CM_COMANONPOST', 'Anonim yorumlara izin ver?');
define('_CM_COMNOCOM', 'Yorumları devre dışı bırak');
define('_CM_USER', 'Ad');
define('_CM_EMAIL', 'Email');
define('_CM_URL', 'Website');
