<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
//%%%%%%    File Name search.php    %%%%%
define('_SR_SEARCH', 'Arama');
define('_SR_PLZENTER', 'Lütfen gerekli tüm verileri girin!');
define('_SR_SEARCHRESULTS', 'Arama Sonuçları');
define('_SR_NOMATCH', 'Sorgunuz için Eşleşme Bulunamadı');
define('_SR_FOUND', 'Bulundu <strong>%s</strong> sorgu(lar)');
define('_SR_SHOWING', '(gösteriliyor %d - %d)');
define('_SR_ANY', 'Herhangi biri');
define('_SR_ALL', 'Tümü');
define('_SR_EXACT', 'Tam Eşleşme');
define('_SR_SHOWALLR', 'Tüm sonuçları göster');
define('_SR_NEXT', 'İleri >>');
define('_SR_PREVIOUS', '<< Geri');
define('_SR_KEYWORDS', 'Aranılan Kelime');
define('_SR_TYPE', 'Tür');
define('_SR_SEARCHIN', 'Ara');
define('_SR_KEYTOOSHORT', 'Anahtar kelimeler en az <strong>%s</strong> karakter olmalıdır');
define('_SR_KEYIGNORE', 'Anahtar kelimeler şundan daha kısa <strong>%s</strong> karakterler yok sayılacak');
define('_SR_SEARCHRULE', 'Arama Kuralları');
define('_SR_IGNOREDWORDS', 'Aşağıdaki kelimeler izin verilen minimum uzunluktan daha kısa (%u chars) ve aramanıza dahil edilmedi:');
