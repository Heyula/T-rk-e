<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MAIL_MSGBODY', 'Mesaj sayfasu ayarlanmadı.');
define('_MAIL_FAILOPTPL', 'Şablon dosyası açılamadı.');
define('_MAIL_FNAMENG', 'E-posta Adı ayarlanmadı.');
define('_MAIL_FEMAILNG', 'E-posta adresi ayarlanmadı.');
define('_MAIL_SENDMAILNG', 'Posta gönderilemedi %s.');
define('_MAIL_MAILGOOD', 'Posta gönderildi %s.');
define('_MAIL_SENDPMNG', 'Özel mesaj gönderilemedi %s.');
define('_MAIL_PMGOOD', 'Özel mesaj gönderildi %s.');
