<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
//%%%%%%        File Name user.php         %%%%%
define('_US_NOTREGISTERED', 'Kayıtlı değilsiniz? Kayıt için tıkla <a href="register.php">here</a>.');
define('_US_LOSTPASSWORD', 'Şifrenizi mi unuttunuz?');
define('_US_NOPROBLEM', 'Sorun değil. Hesabınız için kayıtlı olan e-posta adresini girmeniz yeterlidir..');
define('_US_YOUREMAIL', 'Mail Adresiniz: ');
define('_US_SENDPASSWORD', 'Şifremi Gönder');
define('_US_LOGGEDOUT', 'Çıkış Yaptınız');
define('_US_THANKYOUFORVISIT', 'Sitemizi ziyaret ettiğiniz için teşekkür ederiz!');
define('_US_INCORRECTLOGIN', 'Yanlış Giriş!');
define('_US_LOGGINGU', 'Giriş yaptığınız için teşekkürler, %s.');
// 2001-11-17 ADD
define('_US_NOACTTPADM', 'Seçilen kullanıcı devre dışı bırakıldı veya henüz etkinleştirilmedi.<br>Ayrıntılar için lütfen yöneticiyle iletişime geçin.');
define('_US_ACTKEYNOT', 'Aktivasyon anahtarı doğru değil!');
define('_US_ACONTACT', 'Seçilen hesap zaten etkinleştirildi!');
define('_US_ACTLOGIN', 'Hesabınız aktive edildi. Lütfen kayıtlı şifre ile giriş yapın.');
define('_US_NOPERMISS', 'Üzgünüz, bu eylemi gerçekleştirme izniniz yok!');
define('_US_SURETODEL', 'Hesabını silmek istediğinden emin misin?');
define('_US_REMOVEINFO', 'Bu işlem, tüm bilgilerinizi veritabanımızdan kaldıracaktır.');
define('_US_BEENDELED', 'Hesabınız Silinmiştir.');
define('_US_ACTFAILD', 'Aktivasyon başarısız!');
//%%%%%%        File Name register.php         %%%%%
define('_US_USERREG', 'Kullanıcı Kaydı');
define('_US_NICKNAME', 'Kullanıcı Adı');
define('_US_EMAIL', 'Email');
define('_US_ALLOWVIEWEMAIL', 'Diğer kullanıcıların e-posta adresimi görmesine izin ver');
define('_US_WEBSITE', 'Website');
define('_US_TIMEZONE', 'Saat Dilimi');
define('_US_AVATAR', 'Avatar');
define('_US_VERIFYPASS', 'Şifreyi Doğrula');
define('_US_SUBMIT', 'Gönder');
define('_US_USERNAME', 'Kullanıcı Adı');
define('_US_FINISH', 'Bitti');
define('_US_REGISTERNG', 'Yeni kullanıcı kaydedilemedi.');
define('_US_MAILOK', 'Ara sıra e-posta bildirimleri alın <br>yöneticilerden ve moderatörlerden?');
define('_US_DISCLAIMER', 'Feragatnameden Vazgeçme');
define('_US_IAGREE', 'Yukarıdakilere katılıyorum');
define('_US_UNEEDAGREE', 'Üzgünüz, kayıt olmak için feragatnamemizi kabul etmeniz gerekiyor.');
define('_US_NOREGISTER', 'Üzgünüz, şu anda yeni kullanıcı kayıtları için kapalıyız');
// %s is username. This is a subject for email
define('_US_USERKEYFOR', 'Yeni kullanıcı etkinleştirme anahtarı %s');
define('_US_YOURREGISTERED', 'Artık kayıtlısınız. Sağladığınız e-posta hesabına bir kullanıcı etkinleştirme anahtarı içeren bir e-posta gönderildi. Hesabınızı etkinleştirmek için lütfen e-postadaki talimatları izleyin. ');
define('_US_YOURREGMAILNG', 'Artık kayıtlısınız. Ancak, sunucumuzda meydana gelen dahili bir hata nedeniyle aktivasyon e-postasını e-posta hesabınıza gönderemedik. Verdiğimiz rahatsızlıktan dolayı özür dileriz, lütfen web yöneticisine durumu bildiren bir e-posta gönderin.');
define('_US_YOURREGISTERED2', 'Artık kayıtlısınız.  Lütfen hesabınızın yöneticiler tarafından etkinleştirilmesini bekleyin. Etkinleştirildiğinde bir e-posta alacaksınız. Bu biraz zaman alabilir, bu yüzden lütfen sabırlı olun.');
// %s is your site name
define('_US_NEWUSERREGAT', 'Adresinde yeni kullanıcı kaydı %s');
// %s is a username
define('_US_HASJUSTREG', '%s yeni kayıt oldu!');
define('_US_INVALIDMAIL', 'HATA: Geçersiz E-posta');
define('_US_EMAILNOSPACES', 'HATA: E-posta adresleri boşluk içermiyor.');
define('_US_INVALIDNICKNAME', 'HATA: Geçersiz Kullanıcı Adı');
define('_US_NICKNAMETOOLONG', 'Kullanıcı adı çok uzun %s karakterden daha kısa olmalıdır.');
define('_US_NICKNAMETOOSHORT', 'Kullanıcı adı çok kısa. %s Karakterden daha uzun olmalıdır.');
define('_US_NAMERESERVED', 'HATA: Kullanıcı Adı kullanımdadır.');
define('_US_NICKNAMENOSPACES', 'Kullanıcı Adında boşluk olamaz.');
define('_US_NICKNAMETAKEN', 'HATA: Kullanıcı adı başka bir kullanıcı tarafından alınmış.');
define('_US_EMAILTAKEN', 'HATA: E-posta adresi zaten kayıtlı.');
define('_US_ENTERPWD', 'HATA: Bir şifre girmelisiniz.');
define('_US_SORRYNOTFOUND', 'Üzgünüz, ilgili kullanıcı bilgisi bulunamadı.');
// %s is your site name
define('_US_NEWPWDREQ', 'Yeni Şifre Talebi %s');
define('_US_YOURACCOUNT', 'Adresindeki hesabınız %s');
define('_US_MAILPWDNG', 'mail_password: kullanıcı girişi güncellenemedi. Yöneticiyle İletişime Geçin');
// %s is a username
define('_US_PWDMAILED', 'için şifre %s Email olarak gönderildi.');
define('_US_CONFMAIL', 'için %s Onay Email i gönderildi.');
define('_US_ACTVMAILNG', 'adresine bildirim e-postası gönderilemedi %s');
define('_US_ACTVMAILOK', 'Bildirim e-postası %s gönderildi.');
//%%%%%%        File Name userinfo.php         %%%%%
define('_US_SELECTNG', 'Kullanıcı Seçilmedi! Lütfen geri dönün ve tekrar deneyin.');
define('_US_PM', 'PM');
define('_US_ICQ', 'ICQ');
define('_US_AIM', 'AIM');
define('_US_YIM', 'YIM');
define('_US_MSNM', 'MSNM');
define('_US_LOCATION', 'Lokasyon');
define('_US_OCCUPATION', 'Meslek');
define('_US_INTEREST', 'İlgi Alanları');
define('_US_SIGNATURE', 'İmza Alanı');
define('_US_EXTRAINFO', 'Extra Bilgi');
define('_US_EDITPROFILE', 'Profili Düzenle');
define('_US_LOGOUT', 'Çıkış');
define('_US_INBOX', 'Gelen Kutusu');
define('_US_MEMBERSINCE', 'Üyelik Tarihi');
define('_US_RANK', 'Rütbe');
define('_US_POSTS', 'Yorumlar/Forum Konuları');
define('_US_LASTLOGIN', 'Son Giriş');
define('_US_ALLABOUT', 'Hakkında her şey %s');
define('_US_STATISTICS', 'İstatistikler');
define('_US_MYINFO', 'Bilgilerim');
define('_US_BASICINFO', 'Temel bilgiler');
define('_US_MOREABOUT', 'Benim hakkımda daha fazla');
define('_US_SHOWALL', 'Tümünü Göster');
//%%%%%%        File Name edituser.php         %%%%%
define('_US_PROFILE', 'Profil');
define('_US_REALNAME', 'Greçek Ad');
define('_US_SHOWSIG', 'Her zaman imzamı ekle');
define('_US_CDISPLAYMODE', 'Yorumlardaki Görüntüleme Modu');
define('_US_CSORTORDER', 'Yorumlardaki Sıralama Düzeni');
define('_US_PASSWORD', 'Şifre');
define('_US_TYPEPASSTWICE', '(değiştirmek için iki kez yeni bir şifre yazın)');
define('_US_SAVECHANGES', 'Değişiklikleri Kaydet');
define('_US_NOEDITRIGHT', "Üzgünüz, bu kullanıcının bilgilerini düzenleme hakkınız yok.");
define('_US_PASSNOTSAME', 'Girilen iki şifre farklı.Aynı olmalılar.');
define('_US_PWDTOOSHORT', 'Üzgünüz, şifreniz en az <strong>%s</strong> karakter olmalıdır.');
define('_US_PROFUPDATED', 'Profiliniz Güncellendi!');
// removed in 2.5.9 define('_US_USECOOKIE', 'Store my user name in a cookie for 1 year');
define('_US_NO', 'No');
define('_US_DELACCOUNT', 'Hesabı Sil');
define('_US_MYAVATAR', 'Avatatım');
define('_US_UPLOADMYAVATAR', 'Avatar Yükle');
define('_US_MAXPIXEL', 'Max Pixels');
define('_US_MAXIMGSZ', 'Max Resim Boyutu (Bytes)');
define('_US_SELFILE', 'Dosya Seç');
define('_US_OLDDELETED', 'Eski avatarınız silinecek!');
define('_US_CHOOSEAVT', 'Mevcut listeden avatar seçin');
define('_US_PRESSLOGIN', 'Giriş yapmak için aşağıdaki butona basın');
define('_US_ADMINNO', 'Web yöneticileri grubundaki kullanıcı kaldırılamaz');
define('_US_GROUPS', 'Kullanıcı Grupları');
define('_US_REMEMBERME', 'Beni Hatırla');
// Welcoming emai/PM subject
define('_US_WELCOME_SUBJECT', 'Hoş Geldiniz %s');

//XOOPS 2.5.4
define('_US_SKYPE', 'Skype');
define('_US_FACEBOOK', 'Facebook');
//XOOPS 2.5.9
define('_US_USERALREADYACTIVE', 'Kullanıcı zaten etkin');
//XOOPS 2.5.11
define('_US_DESCRIPTIONMIN', 'Minimum gerekli uzunluk: %s');
define('_US_DESCRIPTIONMAX', 'Maksimum uzunluk: %s');
