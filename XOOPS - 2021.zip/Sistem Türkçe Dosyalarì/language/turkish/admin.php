<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AD_NORIGHT', 'Bu alana erişim izniniz yok');
define('_AD_ACTION', 'Eylem');
define('_AD_EDIT', 'Düzenle');
define('_AD_DELETE', 'Sil');
define('_AD_LASTTENUSERS', 'Son 10 kayıtlı kullanıcı');
define('_AD_NICKNAME', 'Kullanıcı Adı');
define('_AD_EMAIL', 'Email');
define('_AD_AVATAR', 'Avatar');
define('_AD_REGISTERED', 'Kayıtlı'); //Registered Date
// define('_AD_PRESSGEN','This is your first time to enter the administration section. Press the button below to proceed.');
define('_AD_LOGINADMIN', 'Oturum açılıyor..');
define('_AD_WARNINGINSTALL', 'UYARI: Sunucunuzda %s dizini var. <br>Lütfen güvenlik nedeniyle bu dizini kaldırın.');
define('_AD_WARNINGWRITEABLE', 'UYARI: Dosya %s sunucu tarafından yazılabilir. <br>Lütfen güvenlik nedeniyle bu dosyanın iznini değiştirin.<br> Unix de (444), Win32 de (read-only)');
define('_AD_WARNINGNOTWRITEABLE', 'UYARI: Dosya %s sunucu tarafından yazılamaz. <br>Lütfen bu klasörün iznini değiştirin.<br> Unix de (777), Win32 de (writable)');
define('_AD_WARNINGXOOPSLIBINSIDE', 'UYARI: Dosuya %s DocumentRoot! içinde <br>Güvenlik sebebi ile DocumentRoot. klasöründen taşınması tavsiye edilir.');
define('_AD_WARNING_OLD_PHP', 'UYARI: PHP sürümünü bir üst sürüme yükseltmeyi düşünün. Veya versiyon %s tavsiye edilir.Bu sürüm XOOPS un yeni sürümlerinde kullanılaktır.');
define('_AD_WARNING_NO_XML', 'Bu işlev için PHP XML Uzantısı gereklidir.');
