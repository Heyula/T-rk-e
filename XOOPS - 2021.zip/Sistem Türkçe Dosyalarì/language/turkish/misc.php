<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MSC_YOURNAMEC', 'Adınız: ');
define('_MSC_YOUREMAILC', 'Email Adresiniz: ');
define('_MSC_FRIENDNAMEC', 'Arkadaşınızın Adı: ');
define('_MSC_FRIENDEMAILC', 'Arkadaşınızın Email Adresi: ');
define('_MSC_RECOMMENDSITE', 'Bu siteyi bir arkadaşına tavsiye et');
// %s is your site name
define('_MSC_INTSITE', 'İlginç Site: %s');
define('_MSC_REFERENCESENT', 'Sitemizin referansı arkadaşınıza gönderilmiştir. teşekkürler!');
define('_MSC_ENTERYNAME', 'Lütfen adınızı giriniz');
define('_MSC_ENTERFNAME', 'lütfen arkadaşını gir\'Adı');
define('_MSC_ENTERFMAIL', 'lütfen arkadaşının\' email adresini gir');
define('_MSC_NEEDINFO', 'Gerekli bilgileri girmeniz gerekiyor!');
define('_MSC_INVALIDEMAIL1', 'Sağladığınız e-posta adresi geçerli bir adres değil.');
define('_MSC_INVALIDEMAIL2', 'Lütfen adresi kontrol edip tekrar deneyin.');
define('_MSC_AVAVATARS', 'Mevcut Avatarlar');
define('_MSC_SMILIES', 'Smilies');
define('_MSC_CLICKASMILIE', 'Mesajınıza eklemek için bir Smilie tıklayın.');
define('_MSC_CODE', 'Kod');
define('_MSC_EMOTION', 'Duygu');

define('_MSC_CLICK_TO_OPEN_IMAGE', 'Orijinal Resmi yeni bir pencerede görmek için tıklayın');
define('_MSC_RESIZED_IMAGE', 'Yeniden Boyutlandırılan Resim');
define('_MSC_ORIGINAL_IMAGE', 'Orijinal Resim');
