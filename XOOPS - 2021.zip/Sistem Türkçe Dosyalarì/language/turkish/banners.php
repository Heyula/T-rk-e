<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_BANNERS_MANAGEMENT', 'Reklam Yönetimi');
define('_BANNERS_WELCOMEBACK', 'Hoşgeldinizi: %s');
//define('_BANNERS_LOGGEDOUT','Logged out the advertisement panel');
define('_BANNERS_LOGOUT', 'Reklam Yönetiminden Çıkış');
define('_BANNERS_LOGIN_TITLE', 'Reklam İstatistikleri');
define('_BANNERS_LOGIN_LOGIN', 'Giriş :');
define('_BANNERS_LOGIN_INCORRECT', 'Yanlış kullanıcı adı ya da parola');
define('_BANNERS_LOGIN_PASS', 'Şifre :');
define('_BANNERS_LOGIN_INFO', 'Lütfen müşteri bilgilerinizi yazın');
define('_BANNERS_LOGIN_OK', 'OK');
define('_BANNERS_ID', 'Reklam ID:');
define('_BANNERS_TITLE', 'Akrif Reklamlar');
define('_BANNERS_URL', 'URL Değiştir:');
define('_BANNERS_NOTHINGFOUND', 'Reklam Bulunaması');
define('_BANNERS_NO', '#');
define('_BANNERS_FOW_IN', 'Aktif Reklamları Görüntüle: ');
define('_BANNERS_IMP_MADE', 'Imp. Yapılmış');
define('_BANNERS_IMP_TOTAL', 'Imp. Toplam');
define('_BANNERS_IMP_LEFT', 'Imp. Sol');
define('_BANNERS_CLICKS', 'Tıklamalar');
define('_BANNERS_PER_CLICKS', '% Tıklamalar');
define('_BANNERS_FUNCTIONS', 'Fonksiyonlar');
define('_BANNERS_STATS', 'Email İstatistikleri');
define('_BANNERS_SHOWBANNER', 'Reklamları Göster');
define('_BANNERS_SEND_STATS', 'Bu reklam için <a href=\'%s\' title=\'E-mail İstatistikleri\'/>Email İstatistikleri</a> Gönder');
define('_BANNERS_POINTS', 'Reklam URL <a href=\'%s\' title=\'\'>si</a>');
define('_BANNERS_UNLIMITED', 'Sınırsız');
define('_BANNERS_FINISHED', 'Süresi Dolmuş Reklamlar');
define('_BANNERS_STARTED', 'Başlangıç Tarihi');
define('_BANNERS_ENDED', 'Biriş Tarihi');
define('_BANNERS_MAIL_SUBJECT', 'Reklam İstatistikleri %s');
define('_BANNERS_MAIL_MESSAGE', 'Seçili reklam için mevcut istatistikler %s :\n\n\n
Müşteri Adı: %s\nBanner ID: %s\n
Reklam Resmi: %s\n
Reklam URL si: %s\n\n
Satın Alınan Gösterimler: %s\n
Yapılan Gösterimler: %s\n
Sol İzlenimler: %s\n
Alınan Tıklamalar: %s\n
Tıklama Yüzdesi: %f \n\n\n
Rapor Oluşturuldu on: %s');
define('_BANNERS_MAIL_NOT_OK', 'E-postanızı gönderirken bir hatayla karşılaştık. Lütfen bu sorunla ilgili olarak web yöneticisiyle iletişime geçin.');
define('_BANNERS_MAIL_OK', 'Seçili banner için mevcut Banner istatistikleri, hesabınızın e-posta adresine gönderildi.');
define('_BANNERS_MAIL_ERROR', 'Reklam ile ilişkilendirilmiş E-Posta adresi yok %s.<br>Lütfen Yönetici ile iletişime geçin');
define('_BANNERS_DBUPDATED', 'Öğe değiştirildi ve veritabanı güncellendi');
define('_BANNERS_DBERROR', 'Bir hata nedeniyle veritabanı güncellenmedi!');
define('_BANNERS_CHANGE', 'Değiştir');

define('_BANNERS_NO_LOGIN_DATA', 'Oturum açma verisi algılanmadı');
define('_BANNERS_NO_REFERER', 'Yönlendiren algılanmadı');
define('_BANNERS_NO_ID', 'Geçerli bir kimlik algılanmadı');
