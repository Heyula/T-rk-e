<?php
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_XO_ER_FILENOTFOUND','İstenen dosya: <b>%s</b> bulunamadı ');
define('_XO_ER_CLASSNOTFOUND','İstenen sınıf %s bulunamadı');
