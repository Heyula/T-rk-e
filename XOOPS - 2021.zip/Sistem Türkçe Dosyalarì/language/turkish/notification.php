<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// RMV-NOTIFY
// Text for various templates...
define('_NOT_NOTIFICATIONOPTIONS', 'Bildirim Seçenekleri');
define('_NOT_UPDATENOW', 'Şimdi Güncelle');
define('_NOT_UPDATEOPTIONS', 'Bildirim Seçeneklerini Güncelle');
define('_NOT_CLEAR', 'Temizle');
define('_NOT_CHECKALL', 'Tümünü Kontrol Et');
define('_NOT_MODULE', 'Modül');
define('_NOT_CATEGORY', 'Kategori');
define('_NOT_ITEMID', 'ID');
define('_NOT_ITEMNAME', 'Ad');
define('_NOT_EVENT', 'Olay');
define('_NOT_EVENTS', 'Olaylar');
define('_NOT_ACTIVENOTIFICATIONS', 'Bildirimler Aktif');
define('_NOT_NAMENOTAVAILABLE', 'İsim uygun değil');
// RMV-NEW : TODO: remove NAMENOTAVAILBLE above
define('_NOT_ITEMNAMENOTAVAILABLE', 'Öğe Adı Mevcut Değil');
define('_NOT_ITEMTYPENOTAVAILABLE', 'Öğe Türü Mevcut Değil');
define('_NOT_ITEMURLNOTAVAILABLE', 'Öğe URL si Kullanılamıyor');
define('_NOT_DELETINGNOTIFICATIONS', 'Bildirimleri Sil');
define('_NOT_DELETESUCCESS', 'Bildirimler başarıyla silindi.');
define('_NOT_UPDATEOK', 'Bildirim seçenekleri güncellendi');
define('_NOT_NOTIFICATIONMETHODIS', 'Bildirim yöntemi');
define('_NOT_EMAIL', 'Email');
define('_NOT_PM', 'Özel Mesaj');
define('_NOT_DISABLE', 'Kapalı');
define('_NOT_CHANGE', 'Değiştir');
define('_NOT_NOACCESS', 'Bu sayfaya erişim izniniz yok.');
// Text for module config options
define('_NOT_ENABLE', 'Açık');
define('_NOT_NOTIFICATION', 'Bildirim');
define('_NOT_CONFIG_ENABLED', 'Bildirimler Açık');
define('_NOT_CONFIG_ENABLEDDSC', 'Bu modül, kullanıcıların belirli olaylar meydana geldiğinde bilgilendirilmeyi seçmelerine olanak tanır. Bu özelliği etkinleştirmek için "evet"i seçin.');
define('_NOT_CONFIG_EVENTS', 'Belirli Olayları Etkinleştir');
define('_NOT_CONFIG_EVENTSDSC', 'Kullanıcılarınızın abone olabileceği bildirim etkinliklerini seçin.');
define('_NOT_CONFIG_ENABLE', 'Bildirimleri etkinleştir');
define('_NOT_CONFIG_ENABLEDSC', 'Bu modül, belirli olaylar meydana geldiğinde kullanıcıların bilgilendirilmelerini sağlar. Kullanıcılara bir Blokta (Blok stili), modül içinde (Satır içi stil) veya her ikisinde de bildirim seçenekleri sunulup sunulmayacağını seçin. Blok tarzı bildirim için, bu modül için Bildirim Seçenekleri bloğu etkinleştirilmelidir.');
define('_NOT_CONFIG_DISABLE', 'Bildirimi devre dışı bırak');
define('_NOT_CONFIG_ENABLEBLOCK', 'Yalnızca Blok stilini etkinleştir');
define('_NOT_CONFIG_ENABLEINLINE', 'Yalnızca Satır İçi stili etkinleştir');
define('_NOT_CONFIG_ENABLEBOTH', 'Bildirimi Etkinleştir (her iki stil)');
// For notification about comment events
define('_NOT_COMMENT_NOTIFY', 'Yorum Eklendi');
define('_NOT_COMMENT_NOTIFYCAP', 'Bu öğe için yeni bir yorum yayınlandığında bana haber ver.');
define('_NOT_COMMENT_NOTIFYDSC', 'Bu öğe için yeni bir yorum gönderildiğinde (veya onaylandığında) bildirim alın.');
define('_NOT_COMMENT_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE} Otomatik Bildir: Yorum eklendi {X_ITEM_TYPE}');
define('_NOT_COMMENTSUBMIT_NOTIFY', 'Yorum Gönderildi');
define('_NOT_COMMENTSUBMIT_NOTIFYCAP', 'Bu öğe için yeni bir yorum gönderildiğinde (onay beklerken) bana haber ver.');
define('_NOT_COMMENTSUBMIT_NOTIFYDSC', 'Bu öğe için yeni bir yorum gönderildiğinde (onay bekleniyor) bildirim alın.');
define('_NOT_COMMENTSUBMIT_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE} Otomatik Bildir: için gönderilen yorum {X_ITEM_TYPE}');
// For notification bookmark feature
// (Not really notification, but easy to do with this module)
define('_NOT_BOOKMARK_NOTIFY', 'Yer imi');
define('_NOT_BOOKMARK_NOTIFYCAP', 'Bu öğeye yer işareti koyun (bildirim yok).');
define('_NOT_BOOKMARK_NOTIFYDSC', 'Herhangi bir etkinlik bildirimi almadan bu öğeyi takip edin.');
// For user profile
// FIXME: These should be reworded a little...
define('_NOT_NOTIFYMETHOD', 'Bildirim Yöntemi<br> Örneğin, takip ettiğiniz bir forum vb, güncelleme bildirimlerini nasıl almak istersiniz??');
define('_NOT_METHOD_EMAIL', 'E-posta (profilimdeki adresi kullan)');
define('_NOT_METHOD_PM', 'Özel Mesaj');
define('_NOT_METHOD_DISABLE', 'Geçici olarak devre dışı bırak');
define('_NOT_NOTIFYMODE', 'Varsayılan Bildirim Modu');
define('_NOT_MODE_SENDALWAYS', 'Seçilen tüm güncellemeleri bana bildir');
define('_NOT_MODE_SENDONCE', 'Bana sadece bir kez haber ver');
define('_NOT_MODE_SENDONCEPERLOGIN', 'Beni bir kez bilgilendir ve tekrar giriş yapana kadar devre dışı bırak');
define('_NOT_NOTHINGTODELETE', 'Silinecek bir şey yok.');
//XOOPS 2.5.9
define('_NOT_RUSUREDEL', 'Bu Bildirimi silmek istediğinizden emin misiniz?');
