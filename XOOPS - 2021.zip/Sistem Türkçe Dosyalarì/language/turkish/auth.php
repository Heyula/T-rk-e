<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AUTH_MSG_AUTH_METHOD', 'Kullanıcı %s kimlik doğrulama yöntemi');
define('_AUTH_LDAP_EXTENSION_NOT_LOAD', 'PHP LDAP uzantısı yüklenmedi (php yapılandırma dosyanızı php.ini doğrulayın)');
define('_AUTH_LDAP_SERVER_NOT_FOUND', "Sunucuya bağlanılamıyor");
define('_AUTH_LDAP_USER_NOT_FOUND', 'Kullanıcı %s sunucu dizininde bulunamadı (%s) in %s');
define('_AUTH_LDAP_CANT_READ_ENTRY', "Giriş okunamıyor %s");
define('_AUTH_LDAP_XOOPS_USER_NOTFOUND', 'Üzgünüz, XOOPS veritabanında bağlantı için ilgili kullanıcı bilgisi bulunamadı: %s <br>' . 'Lütfen kullanıcı verilerinizi doğrulayın veya otomatik sağlamayı ayarlayın');
define('_AUTH_LDAP_START_TLS_FAILED', 'TLS bağlantısı açılamadı ');
