<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// more examples: http://php.net/manual/en/function.date.php
//
// Revision by TXMod Xoops - Added shot text: 30/06/2012
//
//%%%%%     Time Zone   %%%%
//define('_CAL_FORMAT',"Y-m-d");
define('_CAL_FORMAT', _SHORTDATESTRING);

//%%%%%     JQuery Calendar Time Zone   %%%%
define('_CAL_JQUERY_FORMAT', 'yy/mm/dd');
// Week Mini Text
define('_CAL_MIN_SUNDAY', 'Pzr');
define('_CAL_MIN_MONDAY', 'Pzt');
define('_CAL_MIN_TUESDAY', 'Sal');
define('_CAL_MIN_WEDNESDAY', 'Çrş');
define('_CAL_MIN_THURSDAY', 'Prş');
define('_CAL_MIN_FRIDAY', 'Cum');
define('_CAL_MIN_SATURDAY', 'Cmt');
// Week Short Text
define('_CAL_SHORT_SUNDAY', 'Pzr');
define('_CAL_SHORT_MONDAY', 'Pzt');
define('_CAL_SHORT_TUESDAY', 'Sal');
define('_CAL_SHORT_WEDNESDAY', 'Çrş');
define('_CAL_SHORT_THURSDAY', 'Prş');
define('_CAL_SHORT_FRIDAY', 'Cum');
define('_CAL_SHORT_SATURDAY', 'Cmt');
define('_CAL_SHORT_JANUARY', 'Ocak');
define('_CAL_SHORT_FEBRUARY', 'Şubat');
define('_CAL_SHORT_MARCH', 'Mart');
define('_CAL_SHORT_APRIL', 'Nisan');
define('_CAL_SHORT_MAY', 'Mayıs');
define('_CAL_SHORT_JUNE', 'Haziran');
define('_CAL_SHORT_JULY', 'Temmuz');
define('_CAL_SHORT_AUGUST', 'Ağustos');
define('_CAL_SHORT_SEPTEMBER', 'Eylül');
define('_CAL_SHORT_OCTOBER', 'Ekim');
define('_CAL_SHORT_NOVEMBER', 'Kasım');
define('_CAL_SHORT_DECEMBER', 'Aralık');
// Normal Text
define('_CAL_SUNDAY', 'Pazar');
define('_CAL_MONDAY', 'Pazartesi');
define('_CAL_TUESDAY', 'Salı');
define('_CAL_WEDNESDAY', 'Çarşamba');
define('_CAL_THURSDAY', 'Perşembe');
define('_CAL_FRIDAY', 'Cuma');
define('_CAL_SATURDAY', 'Cumartesi');
define('_CAL_JANUARY', 'Ocak');
define('_CAL_FEBRUARY', 'Şubat');
define('_CAL_MARCH', 'Mart');
define('_CAL_APRIL', 'Nisan');
define('_CAL_MAY', 'Mayıs');
define('_CAL_JUNE', 'Haziran');
define('_CAL_JULY', 'Temmuz');
define('_CAL_AUGUST', 'Ağustos');
define('_CAL_SEPTEMBER', 'Eylül');
define('_CAL_OCTOBER', 'Ekim');
define('_CAL_NOVEMBER', 'Kasım');
define('_CAL_DECEMBER', 'Aralık');
// Others
define('_CAL_TGL1STD', 'Haftanın ilk gününü aç/kapat');
define('_CAL_PREVYR', 'Önceki yıl (menü için basılı tutun)');
define('_CAL_PREVMNTH', 'Önceki ay (menü için basılı tutun)');
define('_CAL_GOTODAY', 'Bugüne git');
define('_CAL_NXTMNTH', 'Gelecek ay (menü için basılı tutun)');
define('_CAL_NEXTYR', 'Gelecek yıl (menü için basılı tutun)');
define('_CAL_SELDATE', 'Tarih Seç');
define('_CAL_DRAGMOVE', 'Taşımak için sürükleyin');
define('_CAL_TODAY', 'Bugün');
define('_CAL_DISPM1ST', 'Önce Pazartesiyi göster');
define('_CAL_DISPS1ST', 'Önce Pazar gününü göster');
