<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MA_USER_MORE', 'Kullanıcı ara');
define('_MA_USER_REMOVE', 'Seçilmemiş kullanıcıları kaldır');

//%%%%%%    File Name findusers.php     %%%%%
define('_MA_USER_ADD_SELECTED', 'Seçili kullanıcıları ekle');
define('_MA_USER_GROUP', 'Grup');
define('_MA_USER_LEVEL', 'Seviye');
define('_MA_USER_LEVEL_ACTIVE', 'Aktif');
define('_MA_USER_LEVEL_INACTIVE', 'Aktif değil');
define('_MA_USER_LEVEL_DISABLED', 'Engelli');
define('_MA_USER_RANK', 'Rütbe');
define('_MA_USER_FINDUS', 'Kullanıcı Bul');
define('_MA_USER_AVATAR', 'Avatar');
define('_MA_USER_REALNAME', 'Gerçek ad');
define('_MA_USER_REGDATE', 'Katılma Tarihi');
define('_MA_USER_EMAIL', 'Email');
define('_MA_USER_PREVIOUS', 'Önceki');
define('_MA_USER_NEXT', 'Sonraki');
define('_MA_USER_USERSFOUND', '%s kullanıcı (s) bulundu');
define('_MA_USER_ACTUS', 'Aktif Kullanıcılar: %s');
define('_MA_USER_INACTUS', 'Pasif Kullanıcılar: %s');
define('_MA_USER_NOFOUND', 'Kullanıcı bulunamadı');
define('_MA_USER_UNAME', 'Kullanıcı Adı');
define('_MA_USER_ICQ', 'ICQ Hesabı');
define('_MA_USER_AIM', 'AIM Hesabı');
define('_MA_USER_YIM', 'YIM Hesabı');
define('_MA_USER_MSNM', 'MSNM Hesabı');
define('_MA_USER_LOCATION', 'Lokasyon');
define('_MA_USER_OCCUPATION', 'Meslek');
define('_MA_USER_INTEREST', 'İlgi alanları');
define('_MA_USER_URLC', 'URL');
define('_MA_USER_SORT', 'Sıralama Şekli');
define('_MA_USER_ORDER', 'Sırala');
define('_MA_USER_LASTLOGIN', 'Son giriş');
define('_MA_USER_POSTS', 'Gönderi sayısı');
define('_MA_USER_ASC', 'Artan');
define('_MA_USER_DESC', 'Azalan');
define('_MA_USER_LIMIT', 'Sayfa başına kullanıcı sayısı');
define('_MA_USER_RESULTS', 'Arama Sonuçları');
define('_MA_USER_SHOWMAILOK', 'Gösterilecek kullanıcı türü');
define('_MA_USER_MAILOK', 'Yalnızca e-posta kabul eden kullanıcılar');
define('_MA_USER_MAILNG', 'Yalnızca e-posta kabul etmeyen kullanıcılar');
define('_MA_USER_BOTH', 'Hepsi');
define('_MA_USER_RANGE_LAST_LOGIN', 'Geçmiş giriş <span style=\'color:#ff0000;\'>X</span>günleri');
define('_MA_USER_RANGE_USER_REGDATE', 'Geçmiş kayıtlı <span style=\'color:#ff0000;\'>X</span>günler');
define('_MA_USER_RANGE_POSTS', 'Gönderiler');
define('_MA_USER_HASAVATAR', 'Avatar var');
define('_MA_USER_MODE_SIMPLE', 'Basit Mod');
define('_MA_USER_MODE_ADVANCED', 'Gelişmiş Mod');
define('_MA_USER_MODE_QUERY', 'Query Mod');
define('_MA_USER_QUERY', 'Query');
define('_MA_USER_SEARCHAGAIN', 'Tekrar ara');
define('_MA_USER_NOUSERSELECTED', 'Kullanıcı seçilmedi');
define('_MA_USER_USERADDED', 'Kullanıcılar eklendi');
define('_MA_USER_SENDMAIL', 'Email Gönder');

//2.5.4
define('_MA_USER_FACEBOOK', 'Facebook Link'); //TO DO
define('_MA_USER_SKYPE', 'Skype Link');//TO DO

