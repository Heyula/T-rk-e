<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PLEASEWAIT', 'Lütfen Bekleyin');
define('_FETCHING', 'Yükleniyor...');
define('_TAKINGBACK', 'Anasayfaya yönlendiriliyorsunuz....');
define('_LOGOUT', 'Çıkış');
define('_SUBJECT', 'Konu');
define('_MESSAGEICON', 'Mesaj Simgesi');
define('_COMMENTS', 'Yorumlar');
define('_POSTANON', 'Anonim Olarak Yayınla');
define('_DISABLESMILEY', 'Smiley devre dışı bırak');
define('_DISABLEHTML', 'HTML devre dışı');
define('_PREVIEW', 'Önizleme');
define('_GO', 'Git!');
define('_NESTED', 'İç içe');
define('_NOCOMMENTS', 'Yorum Yok');
define('_FLAT', 'Düz');
define('_THREADED', 'Genişletilmiş');
define('_OLDESTFIRST', 'Önce Eskiler');
define('_NEWESTFIRST', 'Önce Yeniler');
define('_MORE', 'devamı...');
define('_MULTIPAGE', 'Makale içeriğini sayfalara bölmek için <span color=red>[pagebreak]</span> etiketini kullanabilirsiniz.');
define('_IFNOTRELOAD', 'Sayfa otomatik olarak yeniden yüklenmezse, lütfen tıklayın <a href=\'%s\'>here</a>');
// Error messages issued by XoopsObject::cleanVars()
define('_XOBJ_ERR_REQUIRED', '%s gerekli');
define('_XOBJ_ERR_SHORTERTHAN', '%s daha kısa olamaz %d karakterden.');
// %%%%%%    File Name themeuserpost.php     %%%%%
define('_PROFILE', 'Profil');
define('_POSTEDBY', 'Tarafından');
define('_VISITWEBSITE', 'Siteyi ziyaret et');
define('_SENDPMTO', 'Özel Mesaj Gönder %s');
define('_SENDEMAILTO', 'Email gönder %s');
define('_ADD', 'Ekle');
define('_REPLY', 'Cevap ver');
define('_DATE', 'Tarih'); // Posted date
// %%%%%%    File Name admin_functions.php     %%%%%
define('_MAIN', 'Main');
define('_MANUAL', 'Manual');
define('_INFO', 'Bilgi');
define('_CPHOME', 'Kontrol Paneli Ana Sayfası');
define('_YOURHOME', 'Ana Sayfa');
// %%%%%%    File Name misc.php (who's-online popup)    %%%%%
define('_WHOSONLINE', 'Kimler Online');
define('_GUESTS', 'Misafirler');
define('_MEMBERS', 'Üyeler');
define('_ONLINEPHRASE', '<strong>%s</strong> kullanıcı(lar) çevrimiçi');
define('_ONLINEPHRASEX', '<strong>%s</strong> kullanıcı(lar) göz atıyor <strong>%s</strong>');
define('_CLOSE', 'Kapat'); // Close window
// %%%%%%    File Name module.textsanitizer.php     %%%%%
define('_QUOTEC', 'Alıntı:');
// %%%%%%    File Name admin.php     %%%%%
define('_NOPERM', 'Üzgünüz, bu alana erişim izniniz yok.');
// %%%%%        Common Phrases        %%%%%
define('_NO', 'Hayır');
define('_YES', 'Evet');
define('_EDIT', 'Düzenle');
define('_DELETE', 'Sil');
define('_SUBMIT', 'Gönder');
define('_MODULENOEXIST', 'Seçilen modül mevcut değil!');
define('_ALIGN', 'Hizala');
define('_LEFT', 'Sol');
define('_CENTER', 'Orta');
define('_RIGHT', 'Sağ');
define('_FORM_ENTER', 'Lütfen girin %s');
define('_MUSTWABLE', 'Dosya %s sunucu tarafından yazılabilir olmalı!'); // %s represents file name
// Module info
define('_PREFERENCES', 'Tercihler');
define('_VERSION', 'Versiyon');
define('_DESCRIPTION', 'Açıklama');
define('_AUTHOR', 'Yazar');
define('_CREDITS', 'Kredi');
define('_LICENCE', 'Lisans');
define('_ERRORS', 'Hatalar');
define('_NONE', 'Hiçbiri');
define('_ON', 'Açık');
define('_READS', 'Okunma');
define('_WELCOMETO', 'Hoşgeldiniz %s');
define('_SEARCH', 'Aramam');
define('_ALL', 'Hepsi');
define('_TITLE', 'Başlık');
define('_OPTIONS', 'Ayarlar');
define('_QUOTE', 'Alıntı');
define('_LIST', 'List');
define('_LOGIN', 'Kullanıcı Girişi');
define('_USERNAME', 'Kullanıcı Adı: ');
define('_PASSWORD', 'Şifre: ');
define('_SELECT', 'Seçim');
define('_IMAGE', 'Resim');
define('_SEND', 'Gönder');
define('_CANCEL', 'İptal');
define('_ASCENDING', 'Artan düzen');
define('_DESCENDING', 'Azalan düzen');
define('_BACK', 'Geri');
define('_NOTITLE', 'Başlık yok');
/**
 * Image manager
 */
define('_MD_ADDIMGCAT', 'Kategori Ekle');
define('_MD_IMGCATNAME', 'Kategori adı');
define('_MD_IMGCATRGRP', 'Resim yükleme yöneticisini kullanacak grupları seçin');
define('_MD_IMGCATWGRP', 'Resim yüklemesine izin verilen grupları seçin');
define('_MD_IMGCATWEIGHT', 'Görüntü yöneticisinde sırayı görüntüle');
define('_MD_IMGCATDISPLAY', 'Görüntüle');
define('_MD_IMGCATSTRTYPE', 'Resimler yükleniyor:');
define('_MD_STRTYOPENG', 'Bu işlem sonradan değiştirilemez!');
define('_MD_ASFILE', 'Dosya olarak depola (yükleme dizininde)');
define('_MD_INDB', "Veritabanında saklayın (ikili \"blob\" verileri olarak)");
define('_MD_IMGMAIN', 'Kategori');
define('_MD_EDITIMGCAT', 'Resim Ayarları');
define('_IMGMANAGER', 'Resim Yönetimi');
define('_NUMIMAGES', '%s resimler');
define('_ADDIMAGE', 'Resim Dosyası Ekle');
define('_IMAGENAME', 'Ad:');
define('_IMGMAXSIZE', 'İzin verilen maksimum boyut (bytes):');
define('_IMGMAXWIDTH', 'İzin verilen maksimum genişlik (pixels):');
define('_IMGMAXHEIGHT', 'İzin verilen maksimum yükseklik (pixels):');
define('_IMAGECAT', 'Kategori:');
define('_IMAGEFILE', 'Resim dosyası:');
define('_IMGWEIGHT', 'Görüntü yöneticisinde sırayı görüntüle:');
define('_IMGDISPLAY', 'Bu resmi göster?');
define('_IMAGEMIME', 'MIME türü:');
define('_FAILFETCHIMG', 'Yüklenen dosya alınamadı %s');
define('_FAILSAVEIMG', 'Resim %s veritabanına kaydedilemedi');
define('_NOCACHE', 'Önbellek Yok');
define('_CLONE', 'Clone');
/**
 * fineupload
 */
define('_UPLOAD', 'Yükle');
define('_SELECTFILES', 'Dosyaları seçin');
define('_DROPFILESHERE', 'Dosyaları buraya bırak');
define('_RETRY', 'Yeniden dene');
define('_OK', 'Tamam');
define('_FORMATPROGRESS', '{percent}% ile ilgili {total_size}');
define('_FAILUPLOAD', 'Yükleme başarısız!');
define('_WAITINGFORRESPONSE', 'İşlem Gerçekleşiyor...');
define('_PAUSED', 'Paused');
define('_PROCESSINGDROPPEDFILES', 'Bırakılan dosyaların işlemi gerçekleşiyor...');
define('_TYPEERROR', '{file} geçersiz bir uzantıya sahip. Geçerli uzantı(s): {extensions}!');
define('_SIZEERROR', '{file} çok büyük, maksimum dosya boyutu {sizeLimit}!');
define('_MINSIZEERROR', '{file} çok küçük, minimum dosya boyutu {minSizeLimit}!');
define('_EMPTYERROR', '{file} boş, lütfen onsuz dosyaları tekrar seçin!');
define('_NOFILESERROR', 'Yüklenecek dosya yok!');
define('_TOOMANYITEMSERROR', 'Çok fazla dosya ({netItems}) yüklenecekti.  dosya Sınırı {itemLimit}!');
define('_MAXHEIGHTIMAGEERROR', 'Resim çok uzun!');
define('_MAXWIDTHIMAGEERROR', 'Resim çok geniş!');
define('_MINHEIGHTIMAGEERROR', 'Resim yeterince uzun değil!');
define('_MINWIDTHIMAGEERROR', 'Resim yeterince geniş değil!');
define('_RETRYFAILTOOMANYITEMS', 'Yeniden deneme başarısız oldu - dosya sınırınıza ulaştınız!');
define('_ONLEAVE', 'Dosyalar yükleniyor, şimdi ayrılırsanız yükleme iptal edilecek!');
define('_UNSUPPORTEDBROWSERIOS8SAFARI', 'Kurtarılamaz hata - bu tarayıcı, iOS8 Safari deki ciddi hatalar nedeniyle herhangi bir dosya yüklemesine izin vermiyor.  Apple bu sorunları çözene kadar lütfen iOS8 Chrome u kullanın!');

// %%%%%    For xoopsform files %%%%%
define('_STARTSWITH', 'İle başlar');
define('_ENDSWITH', 'ile biter');
define('_MATCHES', 'Karşılaştırma');
define('_CONTAINS', 'İçerik');
define('_REQUIRED', 'Gerekli');
// %%%%%%    File Name commentform.php     %%%%%
define('_REGISTER', 'Kayıt olmak');
// %%%%%%    File Name xoopscodes.php     %%%%%
define('_SIZE', 'Boyut'); // font size
define('_FONT', 'Font'); // font family
define('_COLOR', 'Renk'); // font color
define('_EXAMPLE', 'ÖRNEK');
define('_ENTERURL', 'Eklemek istediğiniz bağlantının URL sini girin:');
define('_ENTERWEBTITLE', 'Web sitesi başlığını girin:');
define('_ENTERIMGURL', 'Eklemek istediğiniz resmin URL sini girin.');
define('_ENTERIMGPOS', 'Şimdi, resmin konumunu girin.');
define('_IMGPOSRORL', '\'R\' veya \'r\' sağ konumda, \'L\' veya \'l\' sol konumda, veya boş bırakın.');
define('_ERRORIMGPOS', 'HATA! Resmin konumunu girin.');
define('_ENTEREMAIL', 'Eklemek istediğiniz e-posta adresini girin.');
define('_ENTERCODE', 'Eklemek istediğiniz kodları girin.');
define('_ENTERQUOTE', 'Alıntı yapmak istediğiniz metni girin.');
define('_ENTERTEXTBOX', 'Lütfen metin kutusuna metin girin.');
define('_ALLOWEDCHAR', 'İzin verilen maksimum karakter uzunluğu: ');
define('_CURRCHAR', 'Mevcut karakter uzunluğu: ');
define('_PLZCOMPLETE', 'Lütfen konu ve mesaj alanlarını doldurunuz.');
define('_MESSAGETOOLONG', 'Mesajınız çok uzun.');
/**
 * xoops smilie
 */
define('_AM_ADDSMILE', ' Yeni bir smilie ekle');
define('_AM_SMILECODE', 'Code');
define('_AM_SMILEEMOTION', 'Açıklama');
define('_AM_DISPLAYF', 'Formda göster');
// %%%%%        TIME FORMAT SETTINGS   %%%%%
define('_SECOND', '1 saniye');
define('_SECONDS', '%s saniye');
define('_MINUTE', '1 dakika');
define('_MINUTES', '%s dakika');
define('_HOUR', '1 saat');
define('_HOURS', '%s saat');
define('_DAY', '1 gün');
define('_DAYS', '%s gün');
define('_WEEK', '1 hafta');
define('_MONTH', '1 ay');
define('_DATESTRING', 'Y/n/j G:i:s');
//define('_MEDIUMDATESTRING', 'Y/n/j G:i');
define('_MEDIUMDATESTRING', 'm/d/Y G:i');
//define('_SHORTDATESTRING','n/j/Y');
define('_SHORTDATESTRING', 'm/d/Y');
/**
 * The following characters are recognized in the format string:
 * a - 'am' or 'pm'
 * A - 'AM' or 'PM'
 * d - day of the month, 2 digits with leading zeros; i.e. '01' to '31'
 * D - day of the week, textual, 3 letters; i.e. 'Fri'
 * F - month, textual, long; i.e. 'January'
 * h - hour, 12-hour format; i.e. '01' to '12'
 * H - hour, 24-hour format; i.e. '00' to '23'
 * g - hour, 12-hour format without leading zeros; i.e. '1' to '12'
 * G - hour, 24-hour format without leading zeros; i.e. '0' to '23'
 * i - minutes; i.e. '00' to '59'
 * j - day of the month without leading zeros; i.e. '1' to '31'
 * l (lowercase 'L') - day of the week, textual, long; i.e. 'Friday'
 * L - boolean for whether it is a leap year; i.e. '0' or '1'
 * m - month; i.e. '01' to '12'
 * n - month without leading zeros; i.e. '1' to '12'
 * M - month, textual, 3 letters; i.e. 'Jan'
 * s - seconds; i.e. '00' to '59'
 * S - English ordinal suffix, textual, 2 characters; i.e. 'th','nd'
 * t - number of days in the given month; i.e. '28' to '31'
 * T - Timezone setting of this machine; i.e. 'MDT'
 * U - seconds since the epoch
 * w - day of the week, numeric, i.e. '0' (Sunday) to '6' (Saturday)
 * Y - year, 4 digits; i.e. '1999'
 * y - year, 2 digits; i.e. '99'
 * z - day of the year; i.e. '0' to '365'
 * Z - timezone offset in seconds (i.e. '-43200' to '43200')
 */
// %%%%%        LANGUAGE SPECIFIC SETTINGS   %%%%%
define('_CHARSET', 'UTF-8');
define('_LANGCODE', 'tr');
// change 0 to 1 if this language is a multi-bytes language
define('XOOPS_USE_MULTIBYTES', '0');
/**
 * Additions to 2.4.0
 **/
define('_RESET', 'Reset');
define('_RE', 'Re:');
/**
 * Additions to 2.5.5
 **/
define('_DBDATESTRING', 'Y-m-d');
define('_DBTIMESTRING', 'H:i:s');
define('_DBTIMESTAMPSTRING', 'Y-m-d H:i:s');

//2.5.8

//define('_XOBJ_ERR_INVALID_EMAIL', 'Invalid Email');
//define('_XOBJ_ERR_INVALID_ENUMERATION', 'Invalid Enumeration');

//XOOPS 2.5.9
define('_AM_MODULEADMIN_MISSING','Hata: ModuleAdmin sınıfı eksik. Lütfen ModuleAdmin Sınıfını /Frameworks içine kurun (bakınız /docs/readme.txt)');
define('_MD_MESSAGEC', 'Mesaj:');


//XOOPS 2.5.11
define('_PRINT', 'Yazdır');
define('_PDF', 'PDF');
define('_OFF', 'Kapalı');
