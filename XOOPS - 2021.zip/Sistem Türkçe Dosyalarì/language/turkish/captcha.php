<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_CAPTCHA_CAPTION', 'Onay Kodu');
define('_CAPTCHA_INVALID_CODE', 'Geçersiz onay kodu!');
define('_CAPTCHA_TOOMANYATTEMPTS', 'Çok fazla deneme yaptınız!');
define('_CAPTCHA_MAXATTEMPTS', 'Deneyebileceğiniz maksimum deneme sayısı: %d');
// For image mode
define('_CAPTCHA_RULE_IMAGE', 'Resimdeki harfleri girin');
define('_CAPTCHA_RULE_CASESENSITIVE', 'Kod büyük/küçük harfe duyarlıdır');
define('_CAPTCHA_RULE_CASEINSENSITIVE', 'Kod büyük/küçük harfe duyarsızdır');
define('_CAPTCHA_REFRESH', 'Yeterince net değilse resmi yenilemek için tıklayın.');
// For text mode
define('_CAPTCHA_RULE_TEXT', 'İfadenin sonucunu girin');

/**
 * Error defines
 */
define('_CAPTCHA_LOADFILEERROR', 'Hata: Yüklenme sırasında %u dosya dizininde %s sorun meydana geldi %s. ');
