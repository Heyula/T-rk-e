<?php
/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * xmcontent module
 *
 * @copyright       XOOPS Project (https://xoops.org)
 * @license         GNU GPL 2 (http://www.gnu.org/licenses/old-licenses/gpl-2.0.html)
 * @author          Mage Gregory (AKA Mage)
 */
// all
define('_AM_XMCONTENT_ACTION', 'Eyle');
define('_AM_XMCONTENT_ADD', 'Ekle');
define('_AM_XMCONTENT_CLONE', 'Klonla');
define('_AM_XMCONTENT_CONTENT_COPY', 'Kopyala: ');
define('_AM_XMCONTENT_DEL', 'Sil');
define('_AM_XMCONTENT_EDIT', 'Düzenle');
define('_AM_XMCONTENT_NO', 'Hayır');
define('_AM_XMCONTENT_REDIRECT_SAVE', 'Başarıyla kaydedildi');
define('_AM_XMCONTENT_YES', 'Evet');
define('_AM_XMCONTENT_VIEW', 'Detayları göster');

// index
define('_MA_XMCONTENT_INDEXCONFIG_XMDOC_WARNINGNOTINSTALLED', 'xmdoc modülünü kurmadınız, içeriğinize doküman eklemek istiyorsanız bu modül gereklidir.');
define('_MA_XMCONTENT_INDEXCONFIG_XMDOC_WARNINGNOTACTIVATE', 'xmcontent tercihlerinde xmdoc kullanımını etkinleştirmelisiniz (belge eklemek istiyorsanız) ');
define('_MA_XMCONTENT_INDEXCONFIG_XMSOCIAL_WARNINGNOTINSTALLED', 'xmsocial modülünü yüklemediniz, içeriği derecelendirmek veya sosyal medya eklemek istiyorsanız bu modül gereklidir');
define('_MA_XMCONTENT_INDEXCONFIG_XMSOCIAL_WARNINGNOTACTIVATE', 'Tercihlerde xmsocial kullanımını etkinleştirmelisiniz (içeriği derecelendirmek istiyorsanız)');
define('_MA_XMCONTENT_INDEXCONFIG_XMSOCIAL_WARNINGNOTACTIVATESOCIAL', 'Modül tercihlerinde xmsocial kullanımını aktif hale getirmelisiniz (eğer sosyal medya eklemek istiyorsanız) ');

// content
define('_AM_XMCONTENT_CONTENT_ADD', 'İçerik Ekle');
define('_AM_XMCONTENT_CONTENT_CSS', 'CSS Dosyası');
define('_AM_XMCONTENT_CONTENT_DESCRIPTION', 'Meta Açıklaması');
define('_AM_XMCONTENT_CONTENT_DESCRIPTION_DSC', 'Meta açıklama etiketi, sonuçları görüntülemek için arama motorlarına bir açıklama sağlar. .');
define('_AM_XMCONTENT_CONTENT_DOCOMMENT', 'Yorumları Görüntüle');
define('_AM_XMCONTENT_CONTENT_DOMAIL', 'Posta simgesini görüntüle');
define('_AM_XMCONTENT_CONTENT_DOPDF', 'Pdf simgesini görüntüle');
define('_AM_XMCONTENT_CONTENT_DOPRINT', 'Yazdırma simgesini görüntüleyin');
define('_AM_XMCONTENT_CONTENT_DORATING', 'Derecelendirmeyi görüntüle');
define('_AM_XMCONTENT_CONTENT_DOSOCIAL', 'Sosyal simgeleri görüntüle');
define('_AM_XMCONTENT_CONTENT_DOTITLE', 'Başlığı göster');
define('_AM_XMCONTENT_CONTENT_GROUPSVIEW', 'Bu içeriği görüntüleyebilecek grupları seçin');
define('_AM_XMCONTENT_CONTENT_GROUPSEDIT', 'Bu içeriği düzenleyebilecek grupları seçin');
define('_AM_XMCONTENT_CONTENT_INFORMATION', 'Bilgiler');
define('_AM_XMCONTENT_CONTENT_KEYWORD', 'Anahtar Kelimeler');
define('_AM_XMCONTENT_CONTENT_KEYWORD_DSC', 'Anahtar kelimeler meta etiketi, haberinizin içeriğini temsil eden bir dizi anahtar kelimedir. Aralarına virgül koyarak anahtar kelimeleri yazın. (Ör. XOOPS, PHP, mySQL, portal sistemi).');
define('_AM_XMCONTENT_CONTENT_LIST', 'İçerik listesi');
define('_AM_XMCONTENT_CONTENT_LOGO', 'Logo dosyası');
define('_AM_XMCONTENT_CONTENT_MAINDISPLAY', 'Ana sayfada görüntüleniyor');
define('_AM_XMCONTENT_CONTENT_PATH', 'Dosyalar şurada: %s');
define('_AM_XMCONTENT_CONTENT_STATUS', 'Status');
define('_AM_XMCONTENT_CONTENT_STATUS_A', 'Aktif');
define('_AM_XMCONTENT_CONTENT_STATUS_NA', 'Kapalı');
define('_AM_XMCONTENT_CONTENT_SUREDEL', 'Bu içeriği silmek istediğinizden emin misiniz? %s');
define('_AM_XMCONTENT_CONTENT_SURECLONE', 'Bu içeriği klonladığınızdan emin misiniz? %s');
define('_AM_XMCONTENT_CONTENT_TEMPLATE', 'Template dosyası');
define('_AM_XMCONTENT_CONTENT_TEXT', "Yazı");
define('_AM_XMCONTENT_CONTENT_TEXT_DESC', "Use the delimiter <span style='color:orange'>[break_dsc]</span> to define the size of the short description.<br> The short description is used in the homepage of the module
<br><br>Use the delimiter <span style='color:orange'>[pageid=X]</span> to include another xmcontent page in this page. <span style='color:orange'>X</span><br>is the page id<br>
<span style='color:red'>Important:</span> Cascading inclusions (page 1 which includes page 2 which includes page 3) does not work. Inclusions in the short description on the module index page do not work.");
define('_AM_XMCONTENT_CONTENT_TIPS', 'You use the xlanguage module for your website. <br>For the [break_dsc] tag to work correctly you must place it in each of the translations. The same goes for the [pageid = X] tag.');
define('_AM_XMCONTENT_CONTENT_TITLE', 'Başlık');
define('_AM_XMCONTENT_CONTENT_UPLOAD', 'Yükle');
define('_AM_XMCONTENT_CONTENT_UPLOADSIZE', 'Maximum boyut: %s kB');
define('_AM_XMCONTENT_CONTENT_WEIGHT', 'Sıralama');

// permission
define('_AM_XMCONTENT_PERMISSION_VIEW', 'İzinleri görüntüle');
define('_AM_XMCONTENT_PERMISSION_VIEW_DSC', 'Aşağıdaki içeriği görebilecek grupları seçin');
define('_AM_XMCONTENT_PERMISSION_EDIT', 'İzinleri değiştir');
define('_AM_XMCONTENT_PERMISSION_EDIT_DSC', 'Aşağıdaki içeriği değiştirebilecek grupları seçin');

// error
define('_AM_XMCONTENT_ERROR_CONTENT', 'Veritabanında içerik yok');
define('_AM_XMCONTENT_ERROR_WEIGHT', 'Sıralama için bir sayı olmalıdır');
define('_AM_XMCONTENT_ERROR_INCLUDE', 'Bu sayfa %s eklenemedi!');
