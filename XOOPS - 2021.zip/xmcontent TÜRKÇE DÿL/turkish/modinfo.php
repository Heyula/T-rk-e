<?php
/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 * xmcontent module
 *
 * @copyright       XOOPS Project (https://xoops.org)
 * @license         GNU GPL 2 (http://www.gnu.org/licenses/old-licenses/gpl-2.0.html)
 * @author          Mage Gregory (AKA Mage)
 */
// The name of this module
define('_MI_XMCONTENT_NAME', 'İçerik');
define('_MI_XMCONTENT_DESC', 'İçerik Modülü');

// Admin menu
define('_MI_XMCONTENT_MENU_HOME', 'Anasayfa');
define('_MI_XMCONTENT_MENU_HOME_DESC', 'Anasayfaya Dön');
define('_MI_XMCONTENT_MENU_CONTENT', 'İçerikler');
define('_MI_XMCONTENT_MENU_CONTENT_DESC', 'İçerik Listesi');
define('_MI_XMCONTENT_MENU_PERMISSION', 'İzinler');
define('_MI_XMCONTENT_MENU_ABOUT', 'Hakkında');
define('_MI_XMCONTENT_MENU_ABOUT_DESC', 'Bu modül hakkında');
define('_MI_XMCONTENT_MENU_HELP', 'Yardım');
define('_MI_XMCONTENT_MENU_HELP_DESC', 'Modül yardımı');

// Block
define('_MI_XMCONTENT_BLOCK_DEFAULT', 'İçerik');
define('_MI_XMCONTENT_BLOCK_DEFAULT_DESC', 'Bir içeriği görüntüle');

// Pref.
define('_MI_XMCONTENT_PREF_HEAD_REWRITE',"<span style='font-size: large; font-weight: bold;'>URL Yeniden Yazma</span>");
define('_MI_XMCONTENT_PREF_REWRITE','URL Yeniden Yazmayı Kullan ?');
define('_MI_XMCONTENT_PREF_REWRITE_DESC','Tüm modül için URL Yeniden Yazmasını etkinleştirin');
define('_MI_XMCONTENT_PREF_REWRITE_NAME','URL de görünen ad');
define('_MI_XMCONTENT_PREF_REWRITE_NAME_DESC','.htaccess dosyasındaki ad aynı olmalıdır');
define('_MI_XMCONTENT_PREF_HEAD_INDEX', "<span style='font-size: large; font-weight: bold;'>Index</span>");
define('_MI_XMCONTENT_PREF_COLUMNCONTENT', 'İçerik Görünümü için sütun sayısı');
define('_MI_XMCONTENT_PREF_COLUMNCONTENT_DESC', 'Dizinde görüntülenebilecek içerik sayısı: 1, 2, 3 veya 4 sütun');
define('_MI_XMCONTENT_PREF_CONTENTINDEX', 'Dizin sayfasında görüntülenecek içerik');
define('_MI_XMCONTENT_PREF_CONTENTINDEX_ALL', 'Tüm İçerikler');
define('_MI_XMCONTENT_PREF_CONTENTINDEX_DESC', 'Görüntülenecek içeriği seçin. Tüm içeriği görüntülemek için modülü güncellemeniz gerekir.!');
define('_MI_XMCONTENT_PREF_HEADER', 'Başlık dizin sayfası');
define('_MI_XMCONTENT_PREF_HEADER_DESC', 'Dizin sayfasında gösterilecek HTML kodlarını ayarlayın ');
define('_MI_XMCONTENT_PREF_FOOTER', 'Altbilgi dizin sayfası ');
define('_MI_XMCONTENT_PREF_FOOTER_DESC', 'Dizin sayfasında gösterilecek HTML kodlarını ayarlayın');
define('_MI_XMCONTENT_PREF_INDEXPERPAGE', 'Dizin görünümünde sayfa başına öğe sayısı');
define('_MI_XMCONTENT_PREF_HEAD_OPTIONS', "<span style='font-size: large; font-weight: bold;'>Ayarlar</span>");
define('_MI_XMCONTENT_PREF_CSS', 'İçeriğe göre kişiselleştirilmiş bir css dosyası kullanın');
define('_MI_XMCONTENT_PREF_CSS_DESC', 'Bu seçenek etkinleştirilirse, bir içeriğe özel bir css ekleyebilirsiniz.');
define('_MI_XMCONTENT_PREF_TEMPLATE', 'İçeriğe göre kişiselleştirilmiş bir şablon dosyası kullanın ');
define('_MI_XMCONTENT_PREF_TEMPLATE_DESC', 'Bu seçenek etkinleştirilirse, bir içeriğe özel bir şablon ekleyebilirsiniz.');
define('_MI_XMCONTENT_PREF_XMDOC', 'Belge eklemek için xmdoc modülünü kullanın');
define('_MI_XMCONTENT_PREF_XMSOCIAL', 'İçeriği derecelendirmek için xmsocial modülünü kullanın');
define('_MI_XMCONTENT_PREF_XMSOCIALSOCIAL', 'Sosyal ağlar için paylaşım bağlantılarını görüntülemek için xmsocial modülünü kullanın');
define('_MI_XMCONTENT_PREF_WARNING', 'Kullanıcının dahil edilen içeriğe erişimi yoksa uyarı mesajı');
define('_MI_XMCONTENT_PREF_WARNING_DESC', 'The message is used to inform the user that he does not have access to certain pages included in the main page (inclusion with the delimiter <span style="color:orange">[pageid=X]</span>. If you don\'t want a message, leave this field blank.');
define('_MI_XMCONTENT_PREF_WARNING_DEFAULT', 'Tüm sayfaya erişiminiz yok!');
define('_MI_XMCONTENT_PREF_INCLUDE', 'Bir sayfa eklenemiyorsa bir hata mesajı göster');
define('_MI_XMCONTENT_PREF_INCLUDE_DESC', 'If a page cannot be included with the delimiter <span style="color:orange">[pageid=X]</span> (non-existent page, id error, ...), an error message appears at the bottom of the main page (only for administrators).');
define('_MI_XMCONTENT_PREF_HEAD_ADMIN', "<span style='font-size: large; font-weight: bold;'>Administration</span>");
define('_MI_XMCONTENT_PREF_EDITOR', 'Yazı Editörü');
define('_MI_XMCONTENT_PREF_ADMINPERPAGE', 'Yönetici görünümünde sayfa başına öğe sayısı');
