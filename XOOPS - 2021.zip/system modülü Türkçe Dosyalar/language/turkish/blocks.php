<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// Blocks
define('_MB_SYSTEM_ADMENU', 'Yönetim Menüsü');
define('_MB_SYSTEM_RNOW', 'Şimdi üye Ol!');
define('_MB_SYSTEM_LPASS', 'Kayıp Şifre?');
define('_MB_SYSTEM_SEARCH', 'Arama');
define('_MB_SYSTEM_ADVS', 'Gelişmiş Arama');
define('_MB_SYSTEM_VACNT', 'Hesabı Görüntüle');
define('_MB_SYSTEM_EACNT', 'Hesabı Düzenle');
// RMV-NOTIFY
define('_MB_SYSTEM_NOTIF', 'Bildirimler');
define('_MB_SYSTEM_LOUT', 'Çıkış Yap');
define('_MB_SYSTEM_INBOX', 'Gelen Kutusu');
define('_MB_SYSTEM_SUBMS', 'Gönderilen Haberler');
define('_MB_SYSTEM_WLNKS', 'Bekleyen Bağlantılar');
define('_MB_SYSTEM_BLNK', 'Bozuk Bağlantılar');
define('_MB_SYSTEM_MLNKS', 'Değiştirilmiş Bağlantılar');
define('_MB_SYSTEM_WDLS', 'Bekleyen Dosyalar');
define('_MB_SYSTEM_BFLS', 'Bozuk Dosyalar');
define('_MB_SYSTEM_MFLS', 'Değiştirilmiş Dosyalar');
define('_MB_SYSTEM_TDMDOWNLOADS', 'İndirmeler Bekleniyor');
define('_MB_SYSTEM_EXTGALLERY', 'Bekleyen Fotoğraflar');
define('_MB_SYSTEM_SMARTSECTION', 'Makaleler');
define('_MB_SYSTEM_HOME', 'AnaSayfa'); // link to home page in main menu block
define('_MB_SYSTEM_RECO', 'Bizi Tavsiye Edin');
define('_MB_SYSTEM_PWWIDTH', 'Açılır Pencere Genişliği');
define('_MB_SYSTEM_PWHEIGHT', 'Açılır Pencere Yüksekliği');
define('_MB_SYSTEM_LOGO', 'Logo resmi %s dizininde bulunuyor');  // %s is your root image directory name
define('_MB_SYSTEM_COMPEND', 'Yorumlar');
//define('_MB_SYSTEM_LOGGEDINAS',"Logged in as");
define('_MB_SYSTEM_SADMIN', 'Yönetici gruplarını göster');
define('_MB_SYSTEM_SPMTO', 'Özel Mesaj Gönder %s');
define('_MB_SYSTEM_SEMTO', 'Email gönder %s');
define('_MB_SYSTEM_DISPLAY', 'Göster %s Üyeyi');
define('_MB_SYSTEM_DISPLAYA', 'Üye avatarlarını göster');
define('_MB_SYSTEM_NODISPGR', 'Derecesi olan kullanıcıları gösterme:');
define('_MB_SYSTEM_DISPLAYC', 'Göster %s Yorumu');
define('_MB_SYSTEM_SECURE', 'Güvenli giriş');
define('_MB_SYSTEM_NUMTHEME', '%s temalar');
define('_MB_SYSTEM_THSHOW', 'Ekran görüntüsünü göster');
define('_MB_SYSTEM_THWIDTH', 'Ekran görüntüsü genişliği');
define('_MB_SYSTEM_REMEMBERME', 'Beni hatırla');
//2.5.8
define('_MB_SYSTEM_BLOCK_HEIGHT', 'Blok Yüksekliği (lines)');
