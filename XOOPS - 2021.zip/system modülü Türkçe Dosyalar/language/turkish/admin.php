<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license             GNU GPL 2 (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Main
define('_AM_SYSTEM_CONFIG', 'Sistem Yapılandırması');
define('_AM_SYSTEM_CPANEL', 'Kontrol Paneli');
define('_AM_SYSTEM_UPDATE', 'Güncelle');
define('_AM_SYSTEM_GOTOMODULE', 'Modüle Git');
define('_AM_SYSTEM_HELP', 'Yardım');
define('_AM_SYSTEM_HELP_VIEW', 'Yardımı Görüntüle');
define('_AM_SYSTEM_HELP_HIDE', 'Yardımı Gizle');
define('_AM_SYSTEM_TIPS', 'İpuçları');
define('_AM_SYSTEM_SECTION', 'Bölüm');
define('_AM_SYSTEM_DESC', 'Açıklama');
define('_AM_SYSTEM_GO', 'Bu bölüme erişim');
define('_AM_SYSTEM_STATUS', 'Durum bölümünü değiştir');
define('_AM_SYSTEM_LOADING', 'Yükleniyor');
define('_AM_SYSTEM_ALL', 'Tümü');
define('_AM_SYSTEM_TIPS_MAIN', '<ul><li>Sistem modülünün bölümlerini etkinleştirin veya devre dışı bırakın veya yalnızca ona erişin.</li></ul>');
define('_AM_SYSTEM_AVATAR_INFO', "<ul><li><span class='bold red'>%s</span> avatarlar.</li></ul>");
define('_AM_SYSTEM_BANNER_INFO', "<ul><li><span class='bold red'>%s</span> reklamlar.</li></ul>");
define('_AM_SYSTEM_COMMENT_INFO', "<ul><li><span class='bold red'>%s</span> yorumlar.</li></ul>");
define('_AM_SYSTEM_GROUP_INFO', "<ul><li><span class='bold red'>%s</span> grouplar.</li></ul>");
define('_AM_SYSTEM_IMG_INFO', "<ul><li><span class='bold red'>%s</span> resimler.</li></ul>");
define('_AM_SYSTEM_SMILIES_INFO', "<ul><li><span class='bold red'>%s</span> smilies.</li></ul>");
define('_AM_SYSTEM_RANKS_INFO', "<ul><li><span class='bold red'>%s</span> kullanıcı rütbeleri.</li></ul>");
define('_AM_SYSTEM_USERS_INFO', "<ul><li><span class='bold red'>%s</span> kullanıcılar.</li></ul>");
// Admin Module Names and description
define('_AM_SYSTEM_ADGS', 'Gruplar');
define('_AM_SYSTEM_ADGS_DESC', 'Kullanıcılar ve gruplar için modül erişim izinlerini yönetin.');
define('_AM_SYSTEM_BANS', 'Reklamlar');
define('_AM_SYSTEM_BANS_DESC', 'XOOPS reklam afişi özelliğini yönetin.');
define('_AM_SYSTEM_BLOCKS', 'Bloklar');
define('_AM_SYSTEM_BLOCKS_DESC', 'Bloklar, modül içeriğini herhangi bir sayfada görüntüleyebilir. Blokları buradan yönetin.');
define('_AM_SYSTEM_MODULES', 'Modüller');
define('_AM_SYSTEM_MODULES_DESC', 'XOOPS modüllerini kurun ve kaldırın.');
define('_AM_SYSTEM_SMLS', 'Smilies');
define('_AM_SYSTEM_SMLS_DESC', 'İnsanların gönderilerde ve yorumlarda kullanması için özel ifadeleri gizleyin, değiştirin ve ekleyin.');
define('_AM_SYSTEM_RANK', 'Kullanıcı Sıralamaları');
define('_AM_SYSTEM_RANK_DESC', 'Kullanıcılar ve moderatörler için adlandırılmış sıralamaları düzenleyin ve oluşturun.');
define('_AM_SYSTEM_USER', 'Kullanıcılar');
define('_AM_SYSTEM_USER_DESC', 'Kullanıcıları manuel olarak ekleyin, kullanıcı profillerini düzenleyin ve şifreleri değiştirin.');
define('_AM_SYSTEM_PREF', 'Tercihler');
define('_AM_SYSTEM_PREF_DESC', 'XOOPS web siteniz için genel tercihleri değiştirin.');
define('_AM_SYSTEM_MLUS', 'E-posta Kullanıcıları');
define('_AM_SYSTEM_MLUS_DESC', 'Buradan bir kullanıcıya veya birçok kullanıcıya e-posta veya özel mesaj gönderin.');
define('_AM_SYSTEM_IMAGES', 'Resim Yönetimi');
define('_AM_SYSTEM_IMAGES_DESC', 'Resim yöneticisi için kategoriler oluşturun ve resimleri buraya yükleyin.');
define('_AM_SYSTEM_AVATARS', 'Avatarlar');
define('_AM_SYSTEM_AVATARS_DESC', 'Kullanıcıların profillerinde görüntülemeleri için özel avatarlar yükleyin.');
define('_AM_SYSTEM_TPLSETS', 'Şablonlar');
define('_AM_SYSTEM_TPLSETS_DESC', 'Modül şablonlarını diskteki dosyaları düzenlemeden doğrudan düzenleyin.');
define('_AM_SYSTEM_COMMENTS', 'Yorumlar');
define('_AM_SYSTEM_COMMENTS_DESC', 'Birçok modül, kullanıcıların yorum göndermesine izin verir. Bunları buradan silebilir veya düzenleyebilirsiniz.');
define('_AM_SYSTEM_FILEMANAGER', 'Dosya Yöneticisi');
define('_AM_SYSTEM_FILEMANAGER_DESC', 'XOOPS dosya yöneticisi.');
define('_AM_SYSTEM_MAINTENANCE', 'Bakım onarım');
define('_AM_SYSTEM_MAINTENANCE_DESC', 'Veritabanı tabloları, önbellek klasörleri ve oturum tablosu için bakım araçları.');
// Messages
define('_AM_SYSTEM_DBUPDATED', 'Veritabanı Başarıyla Güncellendi!');
define('_AM_SYSTEM_DBERROR', 'Bazı hatalar nedeniyle veritabanı güncellenmedi!');
define('_AM_SYSTEM_NOTACTIVE', 'Bu bölüm aktif değil!');
// Group permission phrases
define('_MD_AM_PERMADDNG', 'Could not add %s permission to %s for group %s');
define('_MD_AM_PERMADDOK', 'Added %s permission to %s for group %s');
define('_MD_AM_PERMRESETNG', 'Modül için grup izni sıfırlanamadı %s');
define('_MD_AM_PERMADDNGP', 'Tüm üst öğeler seçilmelidir.');
define('_AM_SYSTEM_UNINSTALL', 'Kaldır');

//2.5.7
define('_AM_SYSTEM_USAGE', 'Kullanım');
define('_AM_SYSTEM_ACTIVE', 'Aktif');
