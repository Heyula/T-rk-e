<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Manager
define('_AM_SYSTEM_COMMENTS_NAV_MANAGER', 'Yorum Yönetimi');
define('_AM_SYSTEM_COMMENTS_NAV_MAIN', 'Liste');
define('_AM_SYSTEM_COMMENTS_NAV_PURGE', 'Temizle');
// Nav
define('_AM_SYSTEM_COMMENTS_MODULE_ADMIN', 'Modül Yönetimi');
// Tips
define('_AM_SYSTEM_COMMENTS_NAV_TIPS', '
<ul>
<li>Tüm modülleriniz için yorumları yönetin.</li>
<li>Temizleme ile yorumları kolayca silin.</li>
</ul>');
// Form
define('_AM_SYSTEM_COMMENTS_FORM_LIST_COMMENTS', 'Yorumları Listele');
define('_AM_SYSTEM_COMMENTS_FORM_ALL_MODS', 'Tüm modüller');
define('_AM_SYSTEM_COMMENTS_FORM_ALL_STATUS', 'Herhangi bir durum');
define('_AM_SYSTEM_COMMENTS_FORM_PURGE', 'Temizle');
define('_AM_SYSTEM_COMMENTS_FORM_PURGE_DATE_AFTER', 'Bu tarihten sonra (herhangi bir tarih için boş bırakın)');
define('_AM_SYSTEM_COMMENTS_FORM_PURGE_DATE_BEFORE', 'Bu tarihten önce (herhangi bir tarih için boş bırakın)');
define('_AM_SYSTEM_COMMENTS_FORM_PURGE_GROUPS', 'Gruplar');
define('_AM_SYSTEM_COMMENTS_FORM_PURGE_USER', 'Kullanıcı adı');
define('_AM_SYSTEM_COMMENTS_FORM_PURGE_STATUS', 'Durum');
define('_AM_SYSTEM_COMMENTS_FORM_PURGE_MODULES', 'Modüller');
// Tab
define('_AM_SYSTEM_COMMENTS_TITLE', 'Başlık');
define('_AM_SYSTEM_COMMENTS_POSTED', 'Yazar');
define('_AM_SYSTEM_COMMENTS_IP', 'IP');
define('_AM_SYSTEM_COMMENTS_MODULE', 'Modül');
define('_AM_SYSTEM_COMMENTS_STATUS', 'Durum');
define('_AM_SYSTEM_COMMENTS_ACTION', 'Eylem');
define('_AM_SYSTEM_COMMENTS_VIEW', 'Yoruma bakın');
define('_AM_SYSTEM_COMMENTS_NO_COMMENTS', 'Yorum yok');
define('_AM_SYSTEM_COMMENTS_COMMENTS_FOUND', '%s yorum(lar) bulundu.');
//XOOPS 2.5.9
define('_MP_DELETECOUNT', 'Gruptaki üye sayısı çok fazla ( > 4,000) ');
