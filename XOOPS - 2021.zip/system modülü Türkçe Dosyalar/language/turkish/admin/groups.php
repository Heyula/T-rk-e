<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// %%%%%%    Admin Module Name  AdminGroup     %%%%%
//Nav
define('_AM_SYSTEM_GROUPS_NAV_MANAGER', 'Grup Yöneticisi');
define('_AM_SYSTEM_GROUPS_NAV_LIST', 'Grup Listesi');
define('_AM_SYSTEM_GROUPS_NAV_ADD', 'Yeni bir grup ekle');
define('_AM_SYSTEM_GROUPS_NAV_EDIT', 'Grubu düzenle');
define('_AM_SYSTEM_GROUPS_NAV_DELETE', 'Grubu sil');
// Tips
define('_AM_SYSTEM_GROUPS_NAV_TIPS_1', '<ul><li>Yeni izinlerle bir grup oluşturun.</li><li>Değişiklik izinler için grubu düzenleyin.</li></ul>');
define('_AM_SYSTEM_GROUPS_NAV_TIPS_2', '<ul><li>Bu grup için izin değiştirin veya oluşturun, tüm değişiklikler bu grubun kullanıcılarını etkileyecektir.</li></ul>');
//Infos
define('_AM_SYSTEM_GROUPS_ACCESSRIGHTS', 'Modül Erişim Hakları');
define('_AM_SYSTEM_GROUPS_ACTION', 'Eylem');
define('_AM_SYSTEM_GROUPS_ACTIVERIGHTS', 'Modül Yönetici Hakları');
define('_AM_SYSTEM_GROUPS_ADD', 'Yeni bir grup ekle');
define('_AM_SYSTEM_GROUPS_BLOCKRIGHTS', 'Erişim Haklarını Engelle');
define('_AM_SYSTEM_GROUPS_CUSTOMBLOCK', 'Özel Blok');
define('_AM_SYSTEM_GROUPS_DELETE', 'Grubu sil');
define('_AM_SYSTEM_GROUPS_DESCRIPTION', 'Grup Açıklaması');
define('_AM_SYSTEM_GROUPS_EDIT', 'Grubu düzenle');
define('_AM_SYSTEM_GROUPS_ERROR_DELETE', 'Bu grubu kaldıramazsınız');
define('_AM_SYSTEM_GROUPS_ID', 'ID');
define('_AM_SYSTEM_GROUPS_NAME', 'Grup ismi');
define('_AM_SYSTEM_GROUPS_NB_USERS_BY_GROUPS', 'Gruba göre kullanıcı sayısı');
define('_AM_SYSTEM_GROUPS_NB_USERS_BY_GROUPS_USERS', '%s kullanıcı(lar)');
define('_AM_SYSTEM_GROUPS_SUREDEL', 'Bu grubu silmek istediğinizden emin misiniz??');
define('_AM_SYSTEM_GROUPS_SYSTEMRIGHTS', 'Sistem Yöneticisi hakları');
define('_AM_SYSTEM_GROUPS_DBUPDATED', _AM_SYSTEM_DBUPDATED);
