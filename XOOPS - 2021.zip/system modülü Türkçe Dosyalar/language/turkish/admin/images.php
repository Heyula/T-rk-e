<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_IMAGES_MANAGER', 'Resim Yöneticisi');
define('_AM_SYSTEM_IMAGES_MAIN', 'Ana Bölüm');
define('_AM_SYSTEM_IMAGES_IMGLIST', 'Resim Listesi');
// Main
define('_AM_SYSTEM_IMAGES_ADDCAT', 'Kategori Ekle');
define('_AM_SYSTEM_IMAGES_ADDIMG', 'Resim Ekle');
define('_AM_SYSTEM_IMAGES_MULTIUPLOAD', 'Çoklu Yükleme');
define('_AM_SYSTEM_IMAGES_EDITIMG', 'Resim Düzenle');
define('_AM_SYSTEM_IMAGES_CATLIST', 'Kategori Listesi');
define('_AM_SYSTEM_IMAGES_NOCAT', 'Kategori Yok');
define('_AM_SYSTEM_IMAGES_NAME', 'Ad');
define('_AM_SYSTEM_IMAGES_NBIMAGES', 'Resimler');
define('_AM_SYSTEM_IMAGES_MAXSIZE', 'Max boyut');
define('_AM_SYSTEM_IMAGES_MAXWIDTH', 'Max uzunluk');
define('_AM_SYSTEM_IMAGES_MAXHEIGHT', 'Max genişlik');
define('_AM_SYSTEM_IMAGES_DISPLAY', 'Görünüm');
define('_AM_SYSTEM_IMAGES_ACTIONS', 'Eylemler');
define('_AM_SYSTEM_IMAGES_VIEW', 'Görüntüle');
define('_AM_SYSTEM_IMAGES_INDB', ' Veritabanında saklayın (ikili "blob" verisi olarak)');
define('_AM_SYSTEM_IMAGES_ASFILE', ' Dosya olarak depola (yükleme dizininde)<br>');
define('_AM_SYSTEM_IMAGES_IMGCATNAME', 'Kategori Adı:');
define('_AM_SYSTEM_IMAGES_IMGCATRGRP', 'Resim yöneticisi kullanımı için grupları seçin:<br><br><span style="font-weight: normal;">Bunlar, resimleri seçmek için resim yöneticisini kullanmasına izin verilen ancak yükleme yapmayan gruplardır. Web yöneticisinin otomatik erişimi vardır.</span>');
define('_AM_SYSTEM_IMAGES_IMGCATWGRP', 'Resim yüklemesine izin verilen grupları seçin:<br><br><span style="font-weight: normal;">Tipik kullanım, moderatör ve yönetici grupları içindir.</span>');
define('_AM_SYSTEM_IMAGES_IMGCATDISPLAY', 'Bu kategori gösterilsin mi?');
define('_AM_SYSTEM_IMAGES_IMGCATSTRTYPE', 'Resimler yükleniyor:');
define('_AM_SYSTEM_IMAGES_STRTYOPENG', 'Bu sonradan değiştirilemez!');
define('_AM_SYSTEM_IMAGES_IMGCATWEIGHT', 'Resim yöneticisinde sırayı görüntüle:');
define('_AM_SYSTEM_IMAGES_OFF', 'Resim yöneticisinde göster');
define('_AM_SYSTEM_IMAGES_ON', 'Resim yöneticisinde görüntülenmiyor');
define('_AM_SYSTEM_IMAGES_URL', 'Resim URL sini göster');
// Messages
define('_AM_SYSTEM_IMAGES_RUDELIMG', 'Bu resim dosyasını silmek istediğinizden emin misiniz?');
define('_AM_SYSTEM_IMAGES_FAILSAVE', 'Bu resim %s veri tabanına kaydedilemedi');
define('_AM_SYSTEM_IMAGES_RUDELIMGCAT', 'Bu kategoriyi ve tüm resim dosyalarını silmek istediğinizden emin misiniz?');
define('_AM_SYSTEM_IMAGES_FAILDEL', 'Bu resim %s veritabanından silinemedi');
define('_AM_SYSTEM_IMAGES_FAILDELCAT', 'Bu kategori %s veritabanından silinemedi');
define('_AM_SYSTEM_IMAGES_FAILUNLINK', 'Bu resim %s veritabannından silinemedi');
define("_AM_SYSTEM_IMAGES_SCATDELNG","Bu kategori silinemiyor");
// Tips
define('_AM_SYSTEM_IMAGES_TIPS', '<ul><li>Resim kategorilerini ve kullanıcı izinlerini yönetin</li></ul>');
