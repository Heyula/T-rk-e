<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license             GNU GPL 2 (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_AVATAR_MANAGER', 'Avatar Yönetimi');
define('_AM_SYSTEM_AVATAR_MAIN', 'Anabölüm');
define('_AM_SYSTEM_AVATAR_SYSTEM', 'Sistem Avatarları');
define('_AM_SYSTEM_AVATAR_CUSTOM', 'Özel Avatarlar');
define('_AM_SYSTEM_AVATAR_ADD', 'Avatar Ekle');
define('_AM_SYSTEM_AVATAR_EDIT', 'Avatar Düzenle');
define('_AM_SYSTEM_AVATAR_DELETE', 'Avatar Sil');
// Main
define('_AM_SYSTEM_AVATAR_MULTIUPLOAD', 'Çoklu Yüklemeler');
// Infos
define('_AM_SYSTEM_AVATAR_ERROR', 'Hatalar');
define('_AM_SYSTEM_AVATAR_USERS', 'Bu avatarı kullanan kullanıcılar');
define('_AM_SYSTEM_AVATAR_USE_FILE', 'Dosyaları seçin: %s');
define('_AM_SYSTEM_AVATAR_UPLOAD', 'Yükle:');
// Messages
define('_AM_SYSTEM_AVATAR_FAILDEL', 'Veri tabanından %s avatar silinemedi');
define('_AM_SYSTEM_AVATAR_SUREDEL', 'Bu avatar resmini silmek istediğinizden emin misiniz?');
// Tips
define('_AM_SYSTEM_AVATAR_TIPS', "
<ul id='newsticker' class='newsticker'>
<li>Tüm Sistem veya Özel avatarları yönetin</li>
<li>Site üyeleri isteğe bağlı olarak avatar adı verilen kendi çevrimiçi kişiliklerini oluşturabilir.<br>Bu seçenek Sistem Kullanıcısı tercihlerinden kapatılabilir.</li>
</ul>");
