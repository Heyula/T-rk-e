<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
define('_AM_SYSTEM_MAILUSERS_AMIFCHECKD', 'Bu işaretlenirse, yukarıdakilerin tümü artı özel mesajlaşma yok sayılır');
define('_AM_SYSTEM_MAILUSERS_EMAIL', 'Email');
define('_AM_SYSTEM_MAILUSERS_GROUPIS', ' - Grup:');
define('_AM_SYSTEM_MAILUSERS_DAY', ' - Son Giriş günler önce:');
define('_AM_SYSTEM_MAILUSERS_IDLEMORE', 'daha fazla X');
define('_AM_SYSTEM_MAILUSERS_IDLELESS', 'daha az X');
define('_AM_SYSTEM_MAILUSERS_DATE', ' - Son giriş tarihi:');
define('_AM_SYSTEM_MAILUSERS_LASTLOGMAX', 'önce');
define('_AM_SYSTEM_MAILUSERS_LASTLOGMIN', 'sonra');
define('_AM_SYSTEM_MAILUSERS_REGDATE', ' - Kayıt Tarihi:');
define('_AM_SYSTEM_MAILUSERS_REGDMIN', 'önce');
define('_AM_SYSTEM_MAILUSERS_REGDMAX', 'sonra');
define('_AM_SYSTEM_MAILUSERS_INACTIVE', 'Yalnızca etkin olmayan kullanıcılara mesaj gönder');
define('_AM_SYSTEM_MAILUSERS_MAILOK', 'Yalnızca bildirim mesajlarını kabul eden kullanıcılara mesaj gönder');
define('_AM_SYSTEM_MAILUSERS_OPTIONAL', 'İsteğe bağlı değer');
define('_AM_SYSTEM_MAILUSERS_LIST', 'Kullanıcılara Mesaj Gönder');
define('_AM_SYSTEM_MAILUSERS_MAILBODY', 'Anabölüm');
define('_AM_SYSTEM_MAILUSERS_MAILFNAME', 'İsimden (yalnızca e-posta)');
define('_AM_SYSTEM_MAILUSERS_MAILFMAIL', 'E-postadan (yalnızca e-posta)');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS', 'Faydalı Etiketler:');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS1', '{X_UID} kullanıcı kimliğini yazdırır');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS2', '{X_UNAME} kullanıcı adını yazdırır');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS3', '{X_UEMAIL} kullanıcı e-postasını yazdırır');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS4', '{X_UACTLINK} kullanıcı aktivasyon bağlantısını yazdırır');
define('_AM_SYSTEM_MAILUSERS_MAILSUBJECT', 'Konu');
define('_AM_SYSTEM_MAILUSERS_MANAGER', 'Kullanıcı Mesajı Yöneticisi');
define('_AM_SYSTEM_MAILUSERS_SENDNEXT', 'İleri');
define('_AM_SYSTEM_MAILUSERS_NOUSERMATCH', 'Eşleşen kullanıcı yok');
define('_AM_SYSTEM_MAILUSERS_PM', 'Özel Mesaj');
define('_AM_SYSTEM_MAILUSERS_SENDCOMP', 'Mesaj gönderme tamamlandı.');
define('_AM_SYSTEM_MAILUSERS_SENDTO', 'Gönderildi');
define('_AM_SYSTEM_MAILUSERS_SENDTOUSERS', 'olan kullanıcılara mesaj gönder:');
define('_AM_SYSTEM_MAILUSERS_SENDTOUSERS2', 'Gönderildi:');
define('_AM_SYSTEM_MAILUSERS_SENT', 'Gönderilen Kullanıcılar');
define('_AM_SYSTEM_MAILUSERS_SENTNUM', '%s - %s (toplam: %s kullanıcılar)');
define('_AM_SYSTEM_MAILUSERS_TIMEFORMAT', '(Format yyyy-mm-dd, optional)');

//XOOPS 2.5.11
define('_AM_SYSTEM_MAILUSERS_MAILTAGS5', '{X_NAME} boşsa adı veya kullanıcı adı yazdıracak');