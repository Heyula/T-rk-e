<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
//%%%%%%        Admin Module Name  Banners         %%%%%
define('_AM_SYSTEM_BANNERS_DBUPDATED', _AM_SYSTEM_DBUPDATED);
//Nav
define('_AM_SYSTEM_BANNERS_NAV_MANAGER', 'Afiş Yönetimi');
define('_AM_SYSTEM_BANNERS_NAV_MAIN', 'Afişler ve müşteri listesi');
define('_AM_SYSTEM_BANNERS_NAV_EDITBNR', 'Afiş Düzenle');
define('_AM_SYSTEM_BANNERS_NAV_DELETEBNR', 'Afişi Sil');
define('_AM_SYSTEM_BANNERS_NAV_DELETEFINISHBNR', 'Afiş Bitiminde Sil');
define('_AM_SYSTEM_BANNERS_NAV_ADDBNR', 'Yeni Afiş Ekle');
define('_AM_SYSTEM_BANNERS_NAV_EDITADVCLI', 'Müşteri Reklamlarını Düzenle');
define('_AM_SYSTEM_BANNERS_NAV_ADDNWCLI', 'Yeni Müşteri Ekle');
define('_AM_SYSTEM_BANNERS_NAV_DELETECLI', 'Müşteriyi Sil');
define('_AM_SYSTEM_BANNERS_CURACTBNR', 'Mevcut Aktif Afişler');
define('_AM_SYSTEM_BANNERS_BANNERID', 'Afiş ID');
define('_AM_SYSTEM_BANNERS_IMPRESION', 'Gösterimler');
define('_AM_SYSTEM_BANNERS_IMPLEFT', 'Imp. Sol');
define('_AM_SYSTEM_BANNERS_CLICKS', 'Tıklamalar');
define('_AM_SYSTEM_BANNERS_NCLICKS', '% Tıklamalar');
define('_AM_SYSTEM_BANNERS_CLINAME', 'Müşteri Adı');
define('_AM_SYSTEM_BANNERS_FUNCTION', 'Fonksiyonlar');
define('_AM_SYSTEM_BANNERS_UNLIMIT', 'Sınırsız');
define('_AM_SYSTEM_BANNERS_VIEW', 'Afişi Görüntüle');
define('_AM_SYSTEM_BANNERS_EDIT', 'Düzenle');
define('_AM_SYSTEM_BANNERS_DELETE', 'Sil');
define('_AM_SYSTEM_BANNERS_FINISHBNR', 'Bitmiş Afişler');
define('_AM_SYSTEM_BANNERS_IMPD', 'Imp.');
define('_AM_SYSTEM_BANNERS_STARTDATE', 'Başlama Tarihi');
define('_AM_SYSTEM_BANNERS_ENDDATE', 'Bitiş Tarihi');
define('_AM_SYSTEM_BANNERS_ADVCLI', 'Reklam Müşterileri');
define('_AM_SYSTEM_BANNERS_ACTIVEBNR', 'Aktif Afişler');
define('_AM_SYSTEM_BANNERS_CONTNAME', 'Kişi Adı');
define('_AM_SYSTEM_BANNERS_CONTMAIL', 'Email Adresi');
define('_AM_SYSTEM_BANNERS_CLINAMET', 'Müşteri Adı:');
define('_AM_SYSTEM_BANNERS_ADDNWBNR', 'Yeni Afiş Ekle');
define('_AM_SYSTEM_BANNERS_IMPPURCHT', 'Satın Alınan Gösterimler:');
define('_AM_SYSTEM_BANNERS_IMGURLT', 'Resim URL:');
define('_AM_SYSTEM_BANNERS_CLICKURLT', 'Tıklandığındaki URL:');
define('_AM_SYSTEM_BANNERS_ADDBNR', 'Afiş Ekle');
define('_AM_SYSTEM_BANNERS_ADDNWCLI', 'Yeni Müşteri Ekle');
define('_AM_SYSTEM_BANNERS_CONTNAMET', 'İletişim Adı:');
define('_AM_SYSTEM_BANNERS_CONTMAILT', 'İletişim Email:');
define('_AM_SYSTEM_BANNERS_CLILOGINT', 'Müşteri Girişi:');
define('_AM_SYSTEM_BANNERS_CLIPASST', 'Müşteri Şifresi:');
define('_AM_SYSTEM_BANNERS_ADDCLI', 'Müşteri Ekle');
define('_AM_SYSTEM_BANNERS_DELEBNR', 'Afiş Sil');
define('_AM_SYSTEM_BANNERS_SUREDELE', 'Bu Afişi silmek istediğinizden emin misiniz?');
define('_AM_SYSTEM_BANNERS_NO', 'Hayır');
define('_AM_SYSTEM_BANNERS_YES', 'Evet');
define('_AM_SYSTEM_BANNERS_EDITBNR', 'Afiş Düzenle');
define('_AM_SYSTEM_BANNERS_ADDIMPT', 'Daha Fazla Gösterim Ekle:');
define('_AM_SYSTEM_BANNERS_PURCHT', 'Satın alındı:');
define('_AM_SYSTEM_BANNERS_MADET', 'Yapılmış:');
define('_AM_SYSTEM_BANNERS_CHGBNR', 'Afişi Değiştir');
define('_AM_SYSTEM_BANNERS_DELEADC', 'Müşteri Reklamını Sil');
define('_AM_SYSTEM_BANNERS_SUREDELCLI', 'Müşteriyi silmek üzeresiniz <strong>%s</strong> aynı zamanda tüm afişleri!!!');
define('_AM_SYSTEM_BANNERS_NOBNRRUN', "Müşterinin şu anda çalışan herhangi bir afişi yok.");
define('_AM_SYSTEM_BANNERS_WARNING', 'UYARI!!!');
define('_AM_SYSTEM_BANNERS_ACTBNRRUN', 'Bu müşteri, sitemizde çalışan aşağıdaki AKTİF AFİŞ lere sahip:');
define('_AM_SYSTEM_BANNERS_SUREDELBNR', 'Bu Müşteriyi ve TÜM Afişleri silmek istediğinizden emin misiniz?');
define('_AM_SYSTEM_BANNERS_EDITADVCLI', 'Müşteri Reklamını Düzenle');
define('_AM_SYSTEM_BANNERS_EXTINFO', 'Extra Bilgi:');
define('_AM_SYSTEM_BANNERS_CHGCLI', 'Müşteriyi Değiştir');
define('_AM_SYSTEM_BANNERS_USEHTML', 'Use HTML code?');
define('_AM_SYSTEM_BANNERS_CODEHTML', 'Enter HTML code:');
// Tips
define('_AM_SYSTEM_BANNERS_NAV_TIPS', '
<ul>
<li>Kategori, afiş ve müşeteri ekleyin, değiştirin ve güncelleyin .</li>
</ul>
');
