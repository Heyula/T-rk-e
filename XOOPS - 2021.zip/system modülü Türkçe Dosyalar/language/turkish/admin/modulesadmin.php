<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_MODULES_ADMIN', 'Modül Yöneticisi');
define('_AM_SYSTEM_MODULES_LIST', 'Modül Listesi');
define('_AM_SYSTEM_MODULES_TOINSTALL', 'Modül Yükle');
define('_AM_SYSTEM_MODULES_VALIDATE', 'Değişiklikleri doğrula');
define('_AM_SYSTEM_MODULES_SUBMITRES', 'Sonucu Gönder');
// Messages
define('_AM_SYSTEM_MODULES_RUSUREINS', 'Bu modülü kurmak için aşağıdaki düğmeye basın');
define('_AM_SYSTEM_MODULES_RUSUREUNINS', 'Bu modülü kaldırmak istediğinizden emin misiniz?');
define('_AM_SYSTEM_MODULES_RUSUREUPD', 'Bu modülü güncellemek için aşağıdaki düğmeye basın');
define('_AM_SYSTEM_MODULES_BTOMADMIN', 'XOOPS Modül Yönetimi');
define('_AM_SYSTEM_MODULES_INSTALLING', 'Yükle ');
define('_AM_SYSTEM_MODULES_DEACTIVATE', 'Devre dışı bırak ');
define('_AM_SYSTEM_MODULES_ACTIVATE', 'Etkinleştir ');
define('_AM_SYSTEM_MODULES_UPDATING', 'Güncelle ');
// Main
define('_AM_SYSTEM_MODULES_INSTALL', 'Yükle');
define('_AM_SYSTEM_MODULES_UNINSTALL', 'Sil');
define('_AM_SYSTEM_MODULES_UPDATE', 'Güncelle');
define('_AM_SYSTEM_MODULES_VIEWLARGE', 'Geniş Görünüm');
define('_AM_SYSTEM_MODULES_VIEWLINE', 'Çizgi Görünümü');
// %s represents module name
define('_AM_SYSTEM_MODULES_FAILINS', 'Yüklenemiyor %s.');
define('_AM_SYSTEM_MODULES_FAILACT', 'Etkinleştirilemiyor %s.');
define('_AM_SYSTEM_MODULES_FAILDEACT', 'Devre dışı bırakılamıyor %s.');
define('_AM_SYSTEM_MODULES_FAILUPD', 'Güncellenemiyor %s.');
define('_AM_SYSTEM_MODULES_FAILUNINS', 'Kaldırılamıyor %s.');
define('_AM_SYSTEM_MODULES_FAILORDER', 'Yeniden sıralanamadı %s.');
define('_AM_SYSTEM_MODULES_FAILWRITE', 'Ana menüye yazılamıyor.');
define('_AM_SYSTEM_MODULES_ALEXISTS', 'Modül %s zaten var.');
define('_AM_SYSTEM_MODULES_ERRORSC', 'Hata(lar):');
define('_AM_SYSTEM_MODULES_OKINS', 'Modül %s başarıyla yüklendi.');
define('_AM_SYSTEM_MODULES_OKACT', 'Modül %s başarıyla etkinleştirildi.');
define('_AM_SYSTEM_MODULES_OKDEACT', 'Modül %s başarıyla devre dışı bırakıldı.');
define('_AM_SYSTEM_MODULES_OKUPD', 'Modül %s başarıyla güncellendi.');
define('_AM_SYSTEM_MODULES_OKUNINS', 'Modül %s başarıyla kaldırıldı.');
define('_AM_SYSTEM_MODULES_OKORDER', 'Modül %s başarıyla değiştirildi.');
define('_AM_SYSTEM_MODULES_MODULE', 'Modül');
define('_AM_SYSTEM_MODULES_VERSION', 'Versiyon');
define('_AM_SYSTEM_MODULES_LASTUP', 'Son Güncelleme');
define('_AM_SYSTEM_MODULES_DEACTIVATED', 'Devre Dışı');
define('_AM_SYSTEM_MODULES_ACTION', 'Eylem');
define('_AM_SYSTEM_MODULES_MENU', 'Menu');
define('_AM_SYSTEM_MODULES_HIDE', 'Gizli');
define('_AM_SYSTEM_MODULES_SHOW', 'Göster');
define('_AM_SYSTEM_MODULES_DUPEN', 'Modüller tablosunda yinelenen giriş!');
define('_AM_SYSTEM_MODULES_DEACTED', 'Seçilen modül devre dışı bırakıldı. Artık modülü güvenle kaldırabilirsiniz.');
define('_AM_SYSTEM_MODULES_ACTED', 'Seçilen modül etkinleştirildi!');
define('_AM_SYSTEM_MODULES_UPDTED', 'Seçilen modül güncellendi!');
define('_AM_SYSTEM_MODULES_SYSNO', 'Sistem modülü devre dışı bırakılamaz.');
define('_AM_SYSTEM_MODULES_STRTNO', 'Bu modül, varsayılan başlangıç sayfanız olarak ayarlanmıştır. Lütfen başlangıç modülünü tercihlerinize göre değiştirin.');
define('_AM_SYSTEM_MODULES_ORDER', 'Düzem');
define('_AM_SYSTEM_MODULES_ORDER0', '(0 = gizli)');
define('_AM_SYSTEM_MODULES_ACTIVE', 'Aktif');
define('_AM_SYSTEM_MODULES_INACTIVE', 'Etkin Değil');
define('_AM_SYSTEM_MODULES_NOTINSTALLED', 'Yüklü değil');
define('_AM_SYSTEM_MODULES_NOCHANGE', 'Değişiklik Yok');
define('_AM_SYSTEM_MODULES_SUBMIT', 'Gönder');
define('_AM_SYSTEM_MODULES_CANCEL', 'İptal Et');
define('_AM_SYSTEM_MODULES_DBUPDATE', _AM_SYSTEM_DBUPDATED);
define('_AM_SYSTEM_MODULES_LISTUPBLKS', 'Aşağıdaki bloklar güncellenecektir.<br>İçeriğinin (şablon ve seçenekler) üzerine yazılabileceği blokları seçin.<br>');
define('_AM_SYSTEM_MODULES_NEWBLKS', 'Yeni Bloklar');
define('_AM_SYSTEM_MODULES_DEPREBLKS', 'Kullanımdan Kaldırılan Bloklar');
// Logger
define('_AM_SYSTEM_MODULES_TABLE_RESERVED', '%s ayrılmış bir tablo!');
define('_AM_SYSTEM_MODULES_CREATE_TABLES', 'Tablo oluşturuluyor...');
define('_AM_SYSTEM_MODULES_TABLE_CREATED', 'Tablo %s oluşturuldu');
define('_AM_SYSTEM_MODULES_INSERT_DATA', '&nbsp;&nbsp; Tabloya eklenen veriler %s');
define('_AM_SYSTEM_MODULES_INSERT_DATA_FAILD', 'Eklenemedi %s veritabanına.');
define('_AM_SYSTEM_MODULES_INSERT_DATA_DONE', 'Modül verileri başarıyla eklendi.');
define('_AM_SYSTEM_MODULES_MODULEID', ' Modül ID: %s');
define('_AM_SYSTEM_MODULES_SQL_FOUND', 'SQL dosyası şurada bulundu: %s ');
define('_AM_SYSTEM_MODULES_SQL_NOT_FOUND', 'SQL dosyası bulunamadı %s');
define('_AM_SYSTEM_MODULES_SQL_NOT_CREATE', 'HATA: Oluşturulamadı %s ');
define('_AM_SYSTEM_MODULES_SQL_NOT_VALID', '%s geçerli bir SQL değil!');
define('_AM_SYSTEM_MODULES_GROUP_ID', ' Grup ID: %s ');
define('_AM_SYSTEM_MODULES_NAME', ' Ad: ');
define('_AM_SYSTEM_MODULES_VALUE', ' Değer: ');
// Templates
define('_AM_SYSTEM_MODULES_TEMPLATES_ADD', 'Şablon ekleme...');
define('_AM_SYSTEM_MODULES_TEMPLATES_DELETE', 'Şablonları silme...');
define('_AM_SYSTEM_MODULES_TEMPLATES_UPDATE', 'Şablonları güncelleme...');
define('_AM_SYSTEM_MODULES_TEMPLATE_ID', 'Şablon ID: %s ');
define('_AM_SYSTEM_MODULES_TEMPLATE_ADD_DATA', 'Şablon %s veritabanına eklendi');
define('_AM_SYSTEM_MODULES_TEMPLATE_ADD_ERROR', 'HATA: Şablon eklenemedi %s veritabanına.');
define('_AM_SYSTEM_MODULES_TEMPLATE_COMPILED', 'Şablon %s derlendi ');
define('_AM_SYSTEM_MODULES_TEMPLATE_COMPILED_FAILED', 'HATA: Başarısız derleme şablonu %s ');
define('_AM_SYSTEM_MODULES_TEMPLATE_DELETE_DATA', 'Şablon %s veritabanından silindi. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_DELETE_DATA_FAILD', 'Hata: Şablon %s veritabanından silinemedi. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_INSERT_DATA', 'Şablon %s veritabanına eklendi. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_RECOMPILE', 'Şablon %s yeniden derlendi');
define('_AM_SYSTEM_MODULES_TEMPLATE_RECOMPILE_FAILD', 'HATA: Şablon %s yeniden derleme başarısız');
define('_AM_SYSTEM_MODULES_TEMPLATE_RECOMPILE_ERROR', 'HATA: Şablon yeniden derlenemedi %s ');
define('_AM_SYSTEM_MODULES_TEMPLATE_DELETE_OLD_ERROR', 'HATA: Eski şablon silinemedi %s. Bu dosyanın güncellemesi iptal ediliyor. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_UPDATE', 'Şablon %s Güncellendi. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_UPDATE_ERROR', 'HATA: Şablon %s güncellenemedi. ');
// Blocks
define('_AM_SYSTEM_MODULES_BLOCKS_ADD', 'Blok Ekle...');
define('_AM_SYSTEM_MODULES_BLOCKS_DELETE', 'Blok siliniyor...');
define('_AM_SYSTEM_MODULES_BLOCKS_REBUILD', 'Blok Yeniden oluşturuluyor...');
define('_AM_SYSTEM_MODULES_BLOCK_ID', ' Blok ID: %s ');
define('_AM_SYSTEM_MODULES_BLOCK_ACCESS', 'Blok erişim hakkı eklendi');
define('_AM_SYSTEM_MODULES_BLOCK_ACCESS_ERROR', 'Hata: Blok erişim hakkı eklenemedi');
define('_AM_SYSTEM_MODULES_BLOCK_ADD', 'Blok %s eklendi ');
define('_AM_SYSTEM_MODULES_BLOCK_ADD_ERROR', 'Hata: Blok %s Veritabanına eklenemedi! ');
define('_AM_SYSTEM_MODULES_BLOCK_ADD_ERROR_DATABASE', 'Vetitabanı Hatası: %s ');
define('_AM_SYSTEM_MODULES_BLOCK_CREATED', 'Blok %s oluşturuldu ');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE', 'Blok %s silindi. ');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE_DATA', 'Blok şablonu %s veritabanından silindi. ');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE_ERROR', 'Hata: Blok silinemedi %s');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE_TEMPLATE_ERROR', 'Hata: Blok şablonu %s veritabanından silinemedi');
define('_AM_SYSTEM_MODULES_BLOCK_DEPRECATED', 'Blok şablonu %s kullanımdan kaldırıldı ');
define('_AM_SYSTEM_MODULES_BLOCK_DEPRECATED_ERROR', 'Hata: Kullanımdan kaldırılan blok şablonu veritabanından kaldırılamadı.  ');
define('_AM_SYSTEM_MODULES_BLOCK_UPDATE', 'Blok %s güncellendi. ');
// Configs
define('_AM_SYSTEM_MODULES_GONFIG_ID', 'Yapılandırma ID: %s');
define('_AM_SYSTEM_MODULES_MODULE_DATA_ADD', 'Modül yapılandırma verileri ekleme...');
define('_AM_SYSTEM_MODULES_MODULE_DATA_DELETE', 'Modül yapılandırma seçeneklerini silme...');
define('_AM_SYSTEM_MODULES_MODULE_DATA_UPDATE', 'Modül verileri güncellendi.');
define('_AM_SYSTEM_MODULES_CONFIG_ADD', ' Yapılandırma seçeneği eklendi');
define('_AM_SYSTEM_MODULES_CONFIG_DATA_ADD', ' Yapılandırma %s veritabanına eklendi');
define('_AM_SYSTEM_MODULES_CONFIG_DATA_ADD_ERROR', ' HATA: Yapılandırma eklenemedi %s veritabanına. ');
define('_AM_SYSTEM_MODULES_GONFIG_DATA_DELETE', 'Veritabanından silinen yapılandırma verileri. ');
define('_AM_SYSTEM_MODULES_CONFIG_DATA_DELETE_ERROR', 'Hata: Veritabanından yapılandırma verileri silinemedi');
// Access
define('_AM_SYSTEM_MODULES_GROUP_SETTINGS_ADD', 'Grup haklarını ayarlanıyor...');
define('_AM_SYSTEM_MODULES_GROUP_PERMS_DELETE_ERROR', 'HATA: Grup izinleri silinemedi ');
define('_AM_SYSTEM_MODULES_GROUP_PERMS_DELETED', 'Grup izinleri silindi ');
define('_AM_SYSTEM_MODULES_ACCESS_ADMIN_ADD', 'Grup Kimliği için yönetici erişim hakkı eklendi %s');
define('_AM_SYSTEM_MODULES_ACCESS_ADMIN_ADD_ERROR', 'HATA: Grup için yönetici erişim hakkı eklenemedi ID %s');
define('_AM_SYSTEM_MODULES_ACCESS_USER_ADD_ERROR', 'Grup Kimliği için kullanıcı erişim hakkı eklendi: %s');
define('_AM_SYSTEM_MODULES_ACCESS_USER_ADD_ERROR_ERROR', 'HATA: Grup Kimliği için kullanıcı erişim hakkı eklenemedi: %s');
// execute module specific install script if any
define('_AM_SYSTEM_MODULES_FAILED_EXECUTE', 'Çalıştırılamadı %s');
define('_AM_SYSTEM_MODULES_FAILED_SUCESS', '%s başarıyla yürütüldü.');
define('_AM_SYSTEM_MODULES_DELETE_ERROR', 'HATA: Silinemedi %s');
define('_AM_SYSTEM_MODULES_UPDATE_ERROR', 'HATA: Güncellenemedi %s');
define('_AM_SYSTEM_MODULES_DELETE_MOD_TABLES', 'Modül tablolarını siliniyor...');
define('_AM_SYSTEM_MODULES_COMMENTS_DELETE', 'Yorumlar Siliniyor...');
define('_AM_SYSTEM_MODULES_COMMENTS_DELETE_ERROR', 'HATA: Yorumlar silinemedi');
define('_AM_SYSTEM_MODULES_COMMENTS_DELETED', 'Yorumlar silindi');
define('_AM_SYSTEM_MODULES_NOTIFICATIONS_DELETE', 'Bildirimleri siliniyor...');
define('_AM_SYSTEM_MODULES_NOTIFICATIONS_DELETE_ERROR', 'HATA: Bildirimler silinemedi');
define('_AM_SYSTEM_MODULES_NOTIFICATIONS_DELETED', 'Bildirimler silindi');
define('_AM_SYSTEM_MODULES_TABLE_DROPPED', 'Tablo %s kaldırıldı!');
define('_AM_SYSTEM_MODULES_TABLE_DROPPED_ERROR', 'HATA: Tablo kaldırılamadı %s');
define('_AM_SYSTEM_MODULES_TABLE_DROPPED_FAILDED', 'HATA: Tabloyu kaldırma izini verilmiyor  %s !');
// Tips
define('_AM_SYSTEM_MODULES_TIPS', '<ul>
<li>Yeni bir modül kurarsanız, modül tercihlerini, blokları ve kullanıcı izinlerini ayarlamayı unutmayın!</li>
<li>Modülü Ana Menü bloğuna gizlemek için sırayı 0 olarak ayarlayın</li>
<li>Güvenlik sorunlarından kaçınmak ve web sitenizi güvende tutmak için kullanılmayan modül dosyalarını sunucunuzdan silin.</li>
<li>Modüllerin sırasını değiştirmek için (Menüye yansıtılacaktır), modülleri istediğiniz yerleşime sürükleyip bırakmanız yeterlidir.</li>
</ul>');
define('_AM_SYSTEM_MODULES_CONFIRM_TIPS', '<ul>
<li>Doğrulamak için tüm değişiklikleri kontrol edin.</li>
</ul>');
// 2.5.7
define('_AM_SYSTEM_MODULES_INSTALL_TESTDATA', 'Test Verilerini Ekle');
// 2.5.8
define('_AM_SYSTEM_MODULES_INSTALL_MORE', 'Daha fazla modül kurun');
