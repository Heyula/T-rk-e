<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_BLOCKS_ADMIN', 'Blok Yönetimi');
define('_AM_SYSTEM_BLOCKS_MANAGMENT', 'Yönet');
define('_AM_SYSTEM_BLOCKS_ADDBLOCK', 'Yeni bir blok ekle');
define('_AM_SYSTEM_BLOCKS_EDITBLOCK', 'Blok Düzenle');
define('_AM_SYSTEM_BLOCKS_CLONEBLOCK', 'Bloğu Klonla');
// Forms
define('_AM_SYSTEM_BLOCKS_CUSTOM', 'Özel Blok');
define('_AM_SYSTEM_BLOCKS_TYPES', 'Tüm Türler');
define('_AM_SYSTEM_BLOCKS_GENERATOR', 'Modüller');
define('_AM_SYSTEM_BLOCKS_GROUP', 'Guruplar');
define('_AM_SYSTEM_BLOCKS_SVISIBLEIN', 'Sayfa');
define('_AM_SYSTEM_BLOCKS_DISPLAY', 'Görünür Olacak Blok ');
define('_AM_SYSTEM_BLOCKS_HIDE', 'Gizli Olacak Blok ');
define('_AM_SYSTEM_BLOCKS_CLONE', 'Klonma');
define('_AM_SYSTEM_BLOCKS_SIDELEFT', 'Sol');
define('_AM_SYSTEM_BLOCKS_SIDETOPLEFT', 'Sol Üst');
define('_AM_SYSTEM_BLOCKS_SIDETOPCENTER', 'Üst Orta');
define('_AM_SYSTEM_BLOCKS_SIDETOPRIGHT', 'Üst Sağ');
define('_AM_SYSTEM_BLOCKS_SIDERIGHT', 'Sağ');
define('_AM_SYSTEM_BLOCKS_SIDEBOTTOMLEFT', 'Alt Sol');
define('_AM_SYSTEM_BLOCKS_SIDEBOTTOMCENTER', 'Alt Orta');
define('_AM_SYSTEM_BLOCKS_SIDEBOTTOMRIGHT', 'Alt Sağ');

define('_AM_SYSTEM_BLOCKS_SIDEFOOTERLEFT', 'Footer Sol');
define('_AM_SYSTEM_BLOCKS_SIDEFOOTERCENTER', 'Footer Orta');
define('_AM_SYSTEM_BLOCKS_SIDEFOOTERRIGHT', 'Footer Sağ');

define('_AM_SYSTEM_BLOCKS_ADD', 'Blok Ekle');
define('_AM_SYSTEM_BLOCKS_MANAGE', 'Blokları Yönet');
define('_AM_SYSTEM_BLOCKS_NAME', 'Adı');
define('_AM_SYSTEM_BLOCKS_TYPE', 'Blok Pozisyonu');
define('_AM_SYSTEM_BLOCKS_SBLEFT', 'Yan Blok - Sol');
define('_AM_SYSTEM_BLOCKS_SBRIGHT', 'Yan Blok - Sağ');
define('_AM_SYSTEM_BLOCKS_CBLEFT', 'Orta Blok - Sol');
define('_AM_SYSTEM_BLOCKS_CBRIGHT', 'Orta Blok - Sağ');
define('_AM_SYSTEM_BLOCKS_CBCENTER', 'Orta Blok - Orta');
define('_AM_SYSTEM_BLOCKS_CBBOTTOMLEFT', 'Orta Blok - Alt Sol');
define('_AM_SYSTEM_BLOCKS_CBBOTTOMRIGHT', 'Orta Blok - Alt Sağ');

define('_AM_SYSTEM_BLOCKS_CBFOOTERLEFT', 'Footer Blok - Sol');
define('_AM_SYSTEM_BLOCKS_CBFOOTERCENTER', 'Footer Blok - Orta');
define('_AM_SYSTEM_BLOCKS_CBFOOTERRIGHT', 'Footer Blok - Sağ');

define('_AM_SYSTEM_BLOCKS_CBBOTTOM', 'Orta Blok - Alt');
define('_AM_SYSTEM_BLOCKS_WEIGHT', 'Sıra');
define('_AM_SYSTEM_BLOCKS_VISIBLE', 'Görünür');
define('_AM_SYSTEM_BLOCKS_VISIBLEIN', 'Şurada Görünür');
define('_AM_SYSTEM_BLOCKS_TOPPAGE', 'Anasayfada');
define('_AM_SYSTEM_BLOCKS_ALLPAGES', 'Tüm Sayfalarda');
define('_AM_SYSTEM_BLOCKS_UNASSIGNED', 'Atanmamış');
define('_AM_SYSTEM_BLOCKS_TITLE', 'Başlık');
define('_AM_SYSTEM_BLOCKS_CONTENT', 'İçerik');
define('_AM_SYSTEM_BLOCKS_USEFULTAGS', 'Faydalı Etiketler:');
define('_AM_SYSTEM_BLOCKS_BLOCKTAG', '%s yazdıracak %s');
define('_AM_SYSTEM_BLOCKS_CTYPE', 'İçerik Türü');
define('_AM_SYSTEM_BLOCKS_HTML', 'HTML');
define('_AM_SYSTEM_BLOCKS_PHP', 'PHP Script');
define('_AM_SYSTEM_BLOCKS_AFWSMILE', 'Otomatik Biçim (smilies Etkin)');
define('_AM_SYSTEM_BLOCKS_AFNOSMILE', 'Otomatik Biçim (smilies Devre Dışı)');
define('_AM_SYSTEM_BLOCKS_BCACHETIME', 'Önbellek ömrü');
define('_AM_SYSTEM_BLOCKS_CUSTOMHTML', 'Özel Blok (HTML)');
define('_AM_SYSTEM_BLOCKS_CUSTOMPHP', 'Özel Blok (PHP)');
define('_AM_SYSTEM_BLOCKS_CUSTOMSMILE', 'Özel Blok (Otomatik Biçim + smilies)');
define('_AM_SYSTEM_BLOCKS_CUSTOMNOSMILE', 'Özel Blok (Otomatik Biçim)');
define('_AM_SYSTEM_BLOCKS_EDITTPL', 'Şablonu Düzenle');
define('_AM_SYSTEM_BLOCKS_OPTIONS', 'Ayarlar');
define('_AM_SYSTEM_BLOCKS_DRAG', 'Bloğu sürükleyin veya sıralayın');
// Messages
define('_AM_SYSTEM_BLOCKS_DBUPDATED', _AM_SYSTEM_DBUPDATED);
define('_AM_SYSTEM_BLOCKS_RUSUREDEL', 'Bu bloğu silmek istediğinizden emin misiniz? <div class="bold">%s</div>');
define('_AM_SYSTEM_BLOCKS_SYSTEMCANT', 'Sistem blokları silinemez!');
define('_AM_SYSTEM_BLOCKS_MODULECANT', 'Bu blok doğrudan silinemez! Bu bloğu devre dışı bırakmak istiyorsanız, modülü devre dışı bırakın.');
// Tips
define('_AM_SYSTEM_BLOCKS_TIPS', '<ul>
<li>Sürükle ve bırak ile kolayca yan veya sıra konumunu değiştirebilirsiniz, üzerine tıklayın <img class="tooltip" src="%s" alt="' . _AM_SYSTEM_BLOCKS_DRAG . '" title="' . _AM_SYSTEM_BLOCKS_DRAG . '" /> bu resim ve sitenizi tam istediğiniz gibi ayarlayın</li>
<li>Yeni bir özel blok ekle</li>
<li>Tek tıkla bloğu çevrimiçi veya çevrimdışı olarak ayarlayın <img class="tooltip" width="16" src="%s" alt="' . _AM_SYSTEM_BLOCKS_DISPLAY . '" title="' . _AM_SYSTEM_BLOCKS_DISPLAY . '"/> or <img class="tooltip" width="16" src="%s" alt="' . _AM_SYSTEM_BLOCKS_HIDE . '" title="' . _AM_SYSTEM_BLOCKS_HIDE . '" /></li>
</ul>');

define('_AM_SYSTEM_BLOCKS_FOOTER_LEFT', 'Footer Sol');
define('_AM_SYSTEM_BLOCKS_FOOTER_CENTER', 'Footer Orta');
define('_AM_SYSTEM_BLOCKS_FOOTER_RIGHT', 'Footer Sağ');
