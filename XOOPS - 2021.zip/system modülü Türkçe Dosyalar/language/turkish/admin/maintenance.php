<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (https://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
//Nav
define('_AM_SYSTEM_MAINTENANCE_NAV_MANAGER', 'Bakım Onarım');
define('_AM_SYSTEM_MAINTENANCE_NAV_LIST', 'Tam Bakım');
define('_AM_SYSTEM_MAINTENANCE_NAV_DUMP', 'Temizle');
define('_AM_SYSTEM_MAINTENANCE_SESSION', 'Oturumlar tablosunu boşaltın');
define('_AM_SYSTEM_MAINTENANCE_SESSION_OK', 'Oturum bakımı : OK');
define('_AM_SYSTEM_MAINTENANCE_SESSION_NOTOK', 'Oturum bakımı : Hata');
define('_AM_SYSTEM_MAINTENANCE_AVATAR', 'Kullanılmayan özel avatarları temizle');
define('_AM_SYSTEM_MAINTENANCE_CACHE', 'Önbellek klasörünü temizle');
define('_AM_SYSTEM_MAINTENANCE_CACHE_OK', 'Önbellek bakımı : OK');
define('_AM_SYSTEM_MAINTENANCE_CACHE_NOTOK', 'Önbellek bakımı : Hata');
define('_AM_SYSTEM_MAINTENANCE_TABLES', 'Tablolar Bakımı');
define('_AM_SYSTEM_MAINTENANCE_TABLES_OK', 'Tablolar Bakımı : OK');
define('_AM_SYSTEM_MAINTENANCE_TABLES_NOTOK', 'Tablolar Bakımı : Hata');
define('_AM_SYSTEM_MAINTENANCE_QUERY_DESC', 'Tablolarınızı Optimize Edin, Kontrol Edin, Onarın ve Analiz Edin');
define('_AM_SYSTEM_MAINTENANCE_QUERY_OK', 'Veritabanını koru : OK');
define('_AM_SYSTEM_MAINTENANCE_QUERY_NOTOK', 'Veritabanını koru : Error');
define('_AM_SYSTEM_MAINTENANCE_CHOICE1', 'Tabloları optimize et)');
define('_AM_SYSTEM_MAINTENANCE_CHOICE2', 'Tabloları kontrol edin');
define('_AM_SYSTEM_MAINTENANCE_CHOICE3', 'Tabloları Onarın');
define('_AM_SYSTEM_MAINTENANCE_CHOICE4', 'Tabloları Analiz Et');
define('_AM_SYSTEM_MAINTENANCE_TABLES_DESC', 'ANALİZ TABLOSU, bir tablonun anahtar dağıtımını analiz eder ve saklar. Analiz sırasında tablo bir okuma kilidi ile kilitlenir.<br>
KONTROL TABLOSU bir tablo veya tablolarda hata olup olmadığını kontrol eder.<br>
Kullanılmayan alanı geri almak ve veri dosyasını birleştirmek için TABLOYU OPTIMIZE ET.<br>
REPAIR TABLE, muhtemelen bozuk bir tabloyu onarır.');
define('_AM_SYSTEM_MAINTENANCE_RESULT', 'Sonuç');
define('_AM_SYSTEM_MAINTENANCE_RESULT_NO_RESULT', 'Sonuç Yok');
define('_AM_SYSTEM_MAINTENANCE_RESULT_CACHE', 'Önbelleği Temizleme Görevi');
define('_AM_SYSTEM_MAINTENANCE_RESULT_SESSION', 'Oturum Tablosu Temizleme Görevi');
define('_AM_SYSTEM_MAINTENANCE_RESULT_QUERY', 'Veritabanı Görevi');
define('_AM_SYSTEM_MAINTENANCE_RESULT_AVATAR', 'Kullanılmayan avatarları temizle görevi');
define('_AM_SYSTEM_MAINTENANCE_ERROR_MAINTENANCE', 'NBakım için seçenek yok');
define('_AM_SYSTEM_MAINTENANCE_TABLES1', 'Tablolar');
define('_AM_SYSTEM_MAINTENANCE_TABLES_OPTIMIZE', 'Optimize');
define('_AM_SYSTEM_MAINTENANCE_TABLES_CHECK', 'Kontrol Et');
define('_AM_SYSTEM_MAINTENANCE_TABLES_REPAIR', 'Onar');
define('_AM_SYSTEM_MAINTENANCE_TABLES_ANALYZE', 'Analiz');
//Dump
define('_AM_SYSTEM_MAINTENANCE_DUMP', 'Temizle');
define('_AM_SYSTEM_MAINTENANCE_DUMP_TABLES_OR_MODULES', 'Tabloları veya modülleri seçin');
define('_AM_SYSTEM_MAINTENANCE_DUMP_DROP', "Dökümde DROP TABLE IF EXISTS 'tablolar' komutunu ekleyin");
define('_AM_SYSTEM_MAINTENANCE_DUMP_OR', 'OR');
define('_AM_SYSTEM_MAINTENANCE_DUMP_AND', 'AND');
define('_AM_SYSTEM_MAINTENANCE_DUMP_ERROR_TABLES_OR_MODULES', 'Tabloları veya modülleri seçmelisiniz');
define('_AM_SYSTEM_MAINTENANCE_DUMP_NO_TABLES', 'Tablo Yok');
define('_AM_SYSTEM_MAINTENANCE_DUMP_TABLES', 'Tablolar');
define('_AM_SYSTEM_MAINTENANCE_DUMP_STRUCTURES', 'Yapılar');
define('_AM_SYSTEM_MAINTENANCE_DUMP_NB_RECORDS', 'Kayıt sayısı');
define('_AM_SYSTEM_MAINTENANCE_DUMP_FILE_CREATED', 'Dosya oluşturuldu');
define('_AM_SYSTEM_MAINTENANCE_DUMP_RESULT', 'Sonuç');
define('_AM_SYSTEM_MAINTENANCE_DUMP_RECORDS', 'kayıt(lar)');
// Tips
define('_AM_SYSTEM_MAINTENANCE_TIPS', '<ul>
<li>XOOPS Kurulumunuzun basit bir bakımını yapabilirsiniz: önbelleğinizi ve oturum tablonuzu temizleyin ve tablolarınızın bakımını yapın</li>
</ul>');
