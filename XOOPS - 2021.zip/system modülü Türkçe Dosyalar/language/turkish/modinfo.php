<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// Module Info
// The name of this module
define('_MI_SYSTEM_NAME', 'Sistem');
// A brief description of this module
define('_MI_SYSTEM_DESC', 'Sitenin temel ayarlarının yönetim bölümü.');
// Names of blocks for this module (Not all module has blocks)
define('_MI_SYSTEM_BNAME2', 'Kullanıcı Menüsü');
define('_MI_SYSTEM_BNAME3', 'Giriş Yap');
define('_MI_SYSTEM_BNAME4', 'Ara');
define('_MI_SYSTEM_BNAME5', 'Bekleyen Yorumlar');
define('_MI_SYSTEM_BNAME6', 'Ana Menü');
define('_MI_SYSTEM_BNAME7', 'Site Bilgisi');
define('_MI_SYSTEM_BNAME8', 'Kimler Online');
define('_MI_SYSTEM_BNAME9', 'En iyi Posterler');
define('_MI_SYSTEM_BNAME10', 'Yeni Üyeler');
define('_MI_SYSTEM_BNAME11', 'Son Yorumlar');
// RMV-NOTIFY
define('_MI_SYSTEM_BNAME12', 'Bildirim Ayarları');
define('_MI_SYSTEM_BNAME13', 'Temalar');
// Names of admin menu items
define('_MI_SYSTEM_ADMENU1', 'Reklamlar');
define('_MI_SYSTEM_ADMENU2', 'Bloklar');
define('_MI_SYSTEM_ADMENU3', 'Gruplar');
define('_MI_SYSTEM_ADMENU5', 'Modüller');
define('_MI_SYSTEM_ADMENU6', 'Tercihler');
define('_MI_SYSTEM_ADMENU7', 'Smilies');
define('_MI_SYSTEM_ADMENU9', 'Kullanıcı Rütbeleri');
define('_MI_SYSTEM_ADMENU10', 'Üye Düzenle');
define('_MI_SYSTEM_ADMENU11', 'E-posta Kullanıcıları');
define('_MI_SYSTEM_ADMENU12', 'Kullanıcıları Bul');
define('_MI_SYSTEM_ADMENU13', 'Resimler');
define('_MI_SYSTEM_ADMENU14', 'Avatars');
define('_MI_SYSTEM_ADMENU15', 'Şablonlar');
define('_MI_SYSTEM_ADMENU16', 'Yorumlar');
//Preference
define('_MI_SYSTEM_PREFERENCE_BREAK_GENERAL', 'Genel Ayarlar');
define('_MI_SYSTEM_PREFERENCE_TIPS', 'Çevrimiçi yardım?');
define('_MI_SYSTEM_PREFERENCE_TIPS_DSC', 'Bu size ipuçları ve çevrimiçi yardım sağlar');
define('_MI_SYSTEM_PREFERENCE_ICONS', 'İkonlar');
define('_MI_SYSTEM_PREFERENCE_BREADCRUMB', 'Breadcrumb');
define('_MI_SYSTEM_PREFERENCE_BREAK_ACTIVE', 'Aktif Bölüm');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_AVATARS', 'Aktif Avatarlar');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_BANNERS', 'Aktif Reklamlar');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_BLOCKSADMIN', '');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_COMMENTS', 'Aktif Yorumlar');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_FILEMANAGER', 'Aktif Dosya Yöneticisi');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_GROUPS', '');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_IMAGES', 'Aktif Resim Yöneticisi');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_MAILUSERS', 'Aktif E-posta Kullanıcıları');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_MODULESADMIN', '');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_PREFERENCES', '');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_SMILIES', 'Aktif Smilies');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_TPLSETS', '');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_USERRANK', 'Active Kullanıcı Rütbeleri');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_USERS', 'Aktif Kullanıcılar');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_MAINTENANCE', 'Aktif Bakım');
define('_MI_SYSTEM_PREFERENCE_BREAK_PAGER', 'Yönetimde görüntülenecek satır sayısı');
define('_MI_SYSTEM_PREFERENCE_AVATARS_PAGER', 'Sayfa başına gösterilecek avatar sayısı');
define('_MI_SYSTEM_PREFERENCE_BANNERS_PAGER', 'Sayfa başına gösterilecek banner sayısı');
define('_MI_SYSTEM_PREFERENCE_COMMENTS_PAGER', 'Sayfa başına görüntülenecek yorum sayısı');
define('_MI_SYSTEM_PREFERENCE_GROUPS_PAGER', 'Sayfa başına görüntülenecek grup sayısı');
define('_MI_SYSTEM_PREFERENCE_IMAGES_PAGER', 'Sayfa başına görüntülenecek resim sayısı');
define('_MI_SYSTEM_PREFERENCE_SMILIES_PAGER', 'Sayfa başına gösterilecek ifade sayısı');
define('_MI_SYSTEM_PREFERENCE_USERRANKS_PAGER', 'Sayfa başına görüntülenecek Rütbe sayısı');
define('_MI_SYSTEM_PREFERENCE_USERS_PAGER', 'Sayfa başına gösterilecek kullanıcı sayısı');
define('_MI_SYSTEM_PREFERENCE_BREAK_EDITOR', 'Editör Ayarları');
define('_MI_SYSTEM_PREFERENCE_BLOCKS_EDITOR', 'Bloklar için Editör:');
define('_MI_SYSTEM_PREFERENCE_BLOCKS_EDITOR_DSC', '');
define('_MI_SYSTEM_PREFERENCE_COMMENTS_EDITOR', 'Yorumlar için Editör:');
define('_MI_SYSTEM_PREFERENCE_COMMENTS_EDITOR_DSC', '');
define('_MI_SYSTEM_PREFERENCE_GENERAL_EDITOR', 'Tüm modüller için Editör:');
define('_MI_SYSTEM_PREFERENCE_GENERAL_EDITOR_DSC', '');
define('_MI_SYSTEM_PREFERENCE_ANONPOST', '');
define('_MI_SYSTEM_PREFERENCE_REDIRECT', '');
define('_MI_SYSTEM_PREFERENCE_JQUERY_THEME', 'jQuery teması (Seçme Site Bozulur)');
