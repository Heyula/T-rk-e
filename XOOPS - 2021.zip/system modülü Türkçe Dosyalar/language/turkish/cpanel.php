<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MD_AM_VRSN', 'Versiyon');
define('_MD_AM_FINDUSER', 'Üye Ara');
define('_MD_CPANEL_NEWS', 'Haberler');
define('_MD_CPANEL_NEWS_DESC', 'XOOPS geliştirme haberleri');
define('_MD_CPANEL_PROJECT', 'Proje');
define('_MD_CPANEL_PROJECT_DESC', 'XOOPS Proje website');
define('_MD_CPANEL_COMMUNITY', 'Topluluk');
define('_MD_CPANEL_COMMUNITY_DESC', 'XOOPS Resmi Web sitesi');
define('_MD_CPANEL_LOCAL', 'Yerel Destek');
define('_MD_CPANEL_LOCAL_DESC', 'XOOPS Sertifikalı Yerel Destek web siteleri');
define('_MD_CPANEL_OVERVIEW', 'Sistem Görünümü');
define('_MD_CPANEL_PHPEXTENSIONS', 'Yüklenen PHP uzantıları');
define('_MD_CPANEL_VERSION', '%s Versiyon');
define('_MD_CPANEL_QUICKLINKS', 'Hızlı Linkler');
define('_MD_CPANEL_SITE_ADMINISTRATION', '%s Yönetim');
// for help page
define('_MD_CPANEL_HELPCENTER', 'XOOPS Yardım Merkezine Hoş Geldiniz');
